import java.lang.Math;

public class MBR{
    double[] min_value;
    double[] max_value;

    MBR(double[] min_value,double[] max_value){
        this.min_value = min_value;
        this.max_value = max_value;
    }

    MBR(double[] value){
    	this.min_value = value;
    	this.max_value = value;
    }

    MBR(int dimension){
        this.min_value = new double[dimension];
        this.max_value = new double[dimension];
        for(int i = 0 ; i < dimension; i++)
            this.max_value[i] = 1.0;
    }

    public boolean isPoint(){
        for (int i = 0; i < this.min_value.length ; i++) {
            if(this.min_value[i] != this.max_value[i])
                return false;
        }
        return true;
    }

    public MBR leftRegion(double median_value, int dimension){
        double[] min = new double[this.min_value.length];
        double[] max = new double[this.max_value.length];
        for(int i = 0 ; i < min.length; i++)
            max[i] = this.max_value[i];

    	MBR temp = new MBR(min, max);
    	temp.max_value[dimension] = median_value;
    	return temp;
    }

    public MBR rightRegion(double median_value, int dimension){
    	double[] min = new double[this.min_value.length];
        double[] max = new double[this.max_value.length];
        for(int i = 0 ; i < min.length; i++)
            max[i] = this.max_value[i];

        MBR temp = new MBR(min, max);
    	temp.min_value[dimension] = median_value;
    	return temp;
    }

    public double distance(DataPoint d){
        double ans = 0.0;
        for(int i = 0 ; i < d.size(); i++){
            double delta = 0.0;
            if(d.getValueAtDimension(i) < min_value[i]){
                delta = min_value[i] - d.getValueAtDimension(i);
            }else if(d.getValueAtDimension(i) > max_value[i]){
                delta = d.getValueAtDimension(i) - max_value[i];
            }
            ans += Math.pow( delta,2);
        } 
        ans = Math.sqrt(ans);
        return ans;
    }

    public DataPoint getPoint(){
        return new DataPoint(this.min_value);
    }

    public double[] getMinValue(){
        return this.min_value;
    }

    public double[] getMaxValue(){
        return this.max_value;
    }

    public boolean isEqual(MBR mbr){
        double[] mbr_min_value = mbr.getMinValue();
        double[] mbr_max_value = mbr.getMaxValue();
        for(int i = 0; i < this.min_value.length; i++){
            if(this.min_value[i] != mbr_min_value[i])
                return false;
            if(this.max_value[i] != mbr_max_value[i])
                return false;
        }
        return true;
    }

    public boolean isContained(MBR mbr){
     double[] mbr_min_value = mbr.getMinValue();
        double[] mbr_max_value = mbr.getMaxValue();
        for(int i = 0; i < this.min_value.length; i++){
            if(this.min_value[i] > mbr_min_value[i])
                return false;
            if(this.max_value[i] < mbr_max_value[i])
                return false;
        }
        return true;   
    }

    public String toString(){
        String answer = "MBR(";
        for(int i = 0 ; i < this.min_value.length; i++){
            answer += min_value[i] + "," + max_value[i] + ",";
        }
        answer += ")";
        return answer;
    }
    // public static void main(String[] args) {
    //     MBR temp = new MBR({0.0,0.0}, {1.0,1.0})
    // }
}