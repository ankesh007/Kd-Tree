#!/bin/bash
javac assgn.java; java assgn $1
