import java.util.*;

public class ArrayComparator implements Comparator<DataPoint>{
    private int dimension = 0;
    private DataPoint query_point = null;

    public ArrayComparator(int dimension) {
        this.dimension = dimension;
    }

    public ArrayComparator(DataPoint query_point){
        this.query_point = query_point;
    }

    public int compare(DataPoint d1, DataPoint d2) {
        if (this.query_point == null) {
            double temp = d1.getValueAtDimension(dimension) - d2.getValueAtDimension(dimension);
            int ans = 0;
            if(temp > 0){
                return 1;
            }else if(temp < 0){
                return -1;
            }
            return ans;
        } else{
           double temp = d1.distance(query_point) - d2.distance(query_point);
            if(temp == 0.0){
                int size = query_point.size();
                for(int i = 0 ; i < size; i++){
                    if(d1.getValueAtDimension(i) > d2.getValueAtDimension(i)){
                        return 1;
                    }else if(d1.getValueAtDimension(i) < d2.getValueAtDimension(i)){
                        return -1;
                    }
                }
            }else if(temp > 0){
                return 1;
            }else{
                return -1;
            }
            return 0;
        }
    }
}