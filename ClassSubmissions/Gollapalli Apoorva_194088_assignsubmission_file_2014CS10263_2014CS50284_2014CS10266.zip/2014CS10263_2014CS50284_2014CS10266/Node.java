public class Node{
    boolean is_leaf;
    double comparing_value;
    int level;
    DataPoint datapoint;
    Node left_node, right_node;
    MBR maximum_bounding_rectangle;

    Node(DataPoint datapoint, int level){
    	this.is_leaf = true;
    	this.level = level;
    	this.datapoint = datapoint;
    	this.left_node = null;
    	this.right_node = null;
    	this.maximum_bounding_rectangle = new MBR(datapoint.getValue());
    }

    Node(double comparing_value,int level, MBR maximum_bounding_rectangle){
        this.is_leaf = false;
        this.comparing_value = comparing_value;
        this.level = level;
        this.maximum_bounding_rectangle = maximum_bounding_rectangle;
    }

    public void setMBR(MBR maximum_bounding_rectangle){
        this.maximum_bounding_rectangle = maximum_bounding_rectangle;
    }

    public MBR getMBR(){
        return this.maximum_bounding_rectangle;
    }

    public double comparingValue(){
        return this.comparing_value;
    }

    public int level(){
        return this.level;
    }

    public void setLevel(int level){
    	this.level = level;
    }

    public boolean isLeaf(){
        return this.is_leaf;
    }

    public void makeLeaf(){
        this.is_leaf = true;
    }

    public DataPoint getDataPoint(){
        return this.datapoint;
    }

    public void setDataPoint(DataPoint datapoint){
        makeLeaf();
        this.datapoint = datapoint;
    }

    public Node getLeftNode(){
        return left_node;
    }

    public Node getRightNode(){
        return right_node;
    }

    public void setLeftNode(Node left_node){
        this.left_node = left_node;
    }

    public void setRightNode(Node right_node){
        this.right_node = right_node;
    }
}