import java.util.*;
public class KDTree{
    Node root;
    int max_dimension;

    KDTree(int max_dimension){
        this.max_dimension = max_dimension;
        this.root = null;
    }

    public void populate(ArrayList<DataPoint> dataset,MBR maximum_desicion_boundary){
        // System.out.println(maximum_desicion_boundary.toString());
    	this.root =  populateRec(dataset, maximum_desicion_boundary, 0);
    }

    public Node populateRec(ArrayList<DataPoint> dataset,MBR maximum_desicion_boundary,int level){
        
        if(dataset.size() == 0){
            return null;
        }
        if(dataset.size() == 1){
        	Node root = new Node(dataset.get(0), level);
        	return root;
        }
        
        int comparing_dimension = level % max_dimension;

        double median_value = median(dataset, comparing_dimension);
        Node root = new Node(median_value, level, maximum_desicion_boundary);
        // System.out.println(root.getMBR().toString());

        MBR leftMBR = maximum_desicion_boundary.leftRegion(median_value, comparing_dimension);
        MBR rightMBR = maximum_desicion_boundary.rightRegion(median_value, comparing_dimension);
        // System.out.println(leftMBR.toString());
        // System.out.println(rightMBR.toString());
        ArrayList<DataPoint> left_dataset = new ArrayList<DataPoint>();
        ArrayList<DataPoint> right_dataset = new ArrayList<DataPoint>();

        

        for(int i = 0 ; i < dataset.size(); i++){
        	if(dataset.get(i).getValueAtDimension(comparing_dimension) < median_value){
        		left_dataset.add(dataset.get(i));
        	}else{
        		right_dataset.add(dataset.get(i));
        	}
        }

        if(left_dataset.size() == 0){
            for(int i = 0 ; i < (right_dataset.size() / 2); i++){
                left_dataset.add(right_dataset.remove(i));
            }
        }

        if(right_dataset.size() == 0){
            for(int i = 0 ; i < (left_dataset.size() / 2); i++){
                right_dataset.add(left_dataset.remove(i));
            }
        }


        root.setLeftNode(populateRec(left_dataset, leftMBR, level + 1));
        root.setRightNode(populateRec(right_dataset, leftMBR, level + 1));

        return root;

    }

    public double median(ArrayList<DataPoint> dataset, int comparing_dimension){
        int dimension = comparing_dimension;
    	Collections.sort(dataset, new ArrayComparator(comparing_dimension));
    	double median_value;
    	int size = dataset.size();
    	if(size % 2 == 0){
    		median_value = (dataset.get(size / 2).getValueAtDimension(comparing_dimension) + dataset.get((size / 2) - 1).getValueAtDimension(comparing_dimension))/2;
    	}else{
    		median_value = dataset.get(size / 2).getValueAtDimension(comparing_dimension);
    	}

    	return median_value;
    }

    public ArrayList<MBR> getChildren(MBR mbr){
        ArrayList<MBR> list_of_children = new ArrayList<MBR>();
        Node temp = getChildren(this.root, mbr);
        if(temp != null){
            list_of_children.add(temp.getLeftNode().getMBR());
            list_of_children.add(temp.getRightNode().getMBR());
            }
        return list_of_children;
    }

    public Node getChildren(Node root,MBR mbr){
        // System.out.println("getChildren : "+root.getMBR().toString() + "--" + mbr.toString());
        if(root.getMBR().isEqual(mbr)){
            return root;
        }
        if( root.getLeftNode() != null && root.getLeftNode().getMBR().isContained(mbr)){
            // System.out.println("Left");
            return getChildren(root.getLeftNode(), mbr);
        }else if(root.getRightNode() != null){
            // System.out.println("Right");
            return getChildren(root.getRightNode(), mbr);
        }
        return null;
    }

    public void print(Node root){

    	if(root == null){
    		System.out.print("-");
    	}
    	else{

	    	if(root.isLeaf()){
	    		root.getDataPoint().print();
                // System.out.println("MBR IS A POINT : " + root.getMBR().isPoint() + " " + root.getMBR().toString());
	    	}else{
		    	System.out.println(root.comparingValue() + "(level : " + root.level()+"," +root.getMBR().toString() + ")");
		    	System.out.print("left Node : ");
		    	print(root.getLeftNode());
		    	System.out.print("Right Node : ");
		    	print(root.getRightNode());
		    }
	    }
    }
}

