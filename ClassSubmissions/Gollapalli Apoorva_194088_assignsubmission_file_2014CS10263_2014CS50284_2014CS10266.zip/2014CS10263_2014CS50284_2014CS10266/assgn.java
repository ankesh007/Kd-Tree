import java.util.*;
import java.io.*;
import java.math.*;

public class assgn{
    public static void main(String[] args) {

        //part2();

        ArrayList<DataPoint> dataset = new ArrayList<DataPoint>();
        int max_dimesions = 0;
        int size_of_dataset = 0;
        String fileName = args[0];
        String line = null;

        try{
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            line = bufferedReader.readLine();
            String[] temp = line.split(" ");
            max_dimesions = Integer.parseInt(temp[0]);
            size_of_dataset = Integer.parseInt(temp[1]);
            while((line = bufferedReader.readLine()) != null){
                temp = line.split(" ");
                double[] temp_data = new double[max_dimesions];
                for(int i = 0 ; i < max_dimesions; i++)
                    temp_data[i] = Double.parseDouble(temp[i]);
                dataset.add(new DataPoint(temp_data));
            }

            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" +fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println("Error reading file '" + fileName + "'");                  
        }

        KDTree kdtree = new KDTree(max_dimesions);
        MBR master_MBR = new MBR(max_dimesions);

        // System.out.println(master_MBR.toString());


        kdtree.populate(dataset, master_MBR);
        // kdtree.print(kdtree.root);
        System.out.println("0");

        Scanner input = new Scanner(System.in);
        line = input.nextLine();
        
        String[] check =  line.split(" ");
        fileName = check[0];
        int no_of_neighbours = Integer.parseInt(check[1]); 
        
        ArrayList<DataPoint> query_point_set = new ArrayList<DataPoint>();
        int qp_max_dimesions = 0;
        int qp_no_of_query_points = 0;
        
        try{
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            line = bufferedReader.readLine();
            String[] temp = line.split(" ");
            qp_max_dimesions = Integer.parseInt(temp[0]);
            qp_no_of_query_points = Integer.parseInt(temp[1]);
            while((line = bufferedReader.readLine()) != null){
                temp = line.split(" ");
                double[] temp_data = new double[max_dimesions];
                for(int i = 0 ; i < max_dimesions; i++)
                    temp_data[i] = Double.parseDouble(temp[i]);
                query_point_set.add(new DataPoint(temp_data));
            }

            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" +fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println("Error reading file '" + fileName + "'");                  
        }

        try{
            
            File fout = new File("result.txt");
            FileOutputStream fos = new FileOutputStream(fout);
         
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
         
            for (int i = 0; i < qp_no_of_query_points; i++) {
                DataPoint[] KNN_answer = KNNAlgorithmn(kdtree, query_point_set.get(i), no_of_neighbours,max_dimesions);
                DataPoint[] seq = sequential_scan(dataset, query_point_set.get(i), no_of_neighbours);
                for(int j = 0 ; j < no_of_neighbours; j++){
                    bw.write(KNN_answer[j].toString());
                    bw.newLine();
                }
            }
            System.out.println("1");
            bw.close();
        
        }catch(Exception e){
            e.printStackTrace();
            System.out.println(e);
        }    
    }


    public static void part1(int max_dimesions){
        ArrayList<DataPoint> dataset = generate_random_query_sets(100000, max_dimesions, 0.0, 1.0);
        KDTree kdtree = new KDTree(max_dimesions);
        MBR master_MBR = new MBR(max_dimesions);
        kdtree.populate(dataset, master_MBR);
        long startTime = System.nanoTime();
        ArrayList<DataPoint> query_point_set = generate_random_query_sets(100,max_dimesions,0.0,1.0);
        for (int i = 0; i < 100; i++) {
            DataPoint[] KNN_answer = KNNAlgorithmn(kdtree, query_point_set.get(i), 20,max_dimesions);
        }
        long endTime   = System.nanoTime();
        long totalTime = (endTime - startTime)/1000000000;
        System.out.println("Dimesions : " + max_dimesions + " Avg time per query (KNN) : " + (totalTime / 100));

        startTime = System.nanoTime();        
        for (int i = 0; i < 100; i++) {
            DataPoint[] sequential = sequential_scan(dataset, query_point_set.get(i), 20);
        }
        endTime   = System.nanoTime();
        totalTime = (endTime - startTime)/1000000000;
        System.out.println("Dimesions : " + max_dimesions + " Avg time per query (sequential_scan) : " + (totalTime / 100));
        
        double totalRatio = 0.0;
        for (int i = 0; i < 100; i++) {
            DataPoint[] KNN_answer = KNNAlgorithmn(kdtree, query_point_set.get(i), 100,max_dimesions);
            DataPoint second_closest = KNN_answer[1]; 
            DataPoint hundredth_closest = KNN_answer[99];
            double ratio = (second_closest.distance(query_point_set.get(i)) / hundredth_closest.distance(query_point_set.get(i)));
            totalRatio += ratio;
        }
        System.out.println("Dimesions : " + max_dimesions + " Avg distance per query(100 Neighbours) : " + (totalRatio / 100));

    }

    public static void part2(){
        int[] dimensions_array = {2,3,5,10,15,20};
        for(int i = 0 ; i < dimensions_array.length; i++){
            part1(dimensions_array[i]);
        }
    }    

    public static ArrayList<DataPoint> generate_random_query_sets(int no_of_examples,int K, double rangeMin, double rangeMax){
        ArrayList<DataPoint> random_query_sets = new ArrayList<DataPoint>();
        Random generator = new Random();
        for(int i = 0;i < no_of_examples; i++){
            double[] answer = new double[K];
            for (int j = 0; j < K; j++ ) {
                answer[j]=rangeMin + (rangeMax - rangeMin) * generator.nextDouble();
            }
            random_query_sets.add(new DataPoint(answer));
        }
        return random_query_sets;
    }



    public static DataPoint[] KNNAlgorithmn(KDTree kdtree,DataPoint query_point,int no_of_points,int max_dimesions){
        ArrayList<DataPoint> k_datapoints_random_query_sets = generate_random_query_sets(no_of_points, max_dimesions, 10.0, 20.0);
        DataPoint[] k_datapoints = new DataPoint[k_datapoints_random_query_sets.size()];
        k_datapoints = k_datapoints_random_query_sets.toArray(k_datapoints);
        
        MaxHeap ans = new MaxHeap(k_datapoints,query_point, no_of_points);
        ans.buildMaxHeap();
        MinHeap mbr = new MinHeap(new MBR[0], query_point);
        MBR master_MBR = new MBR(max_dimesions);

        mbr.insert(master_MBR);

        while(mbr.getSize() != 0){
            MBR temp_mbr = mbr.extractMin();
            DataPoint temp_datapoint = ans.findMax();
            // System.out.println(temp_datapoint.toString() + " " + temp_mbr.toString() + " " +query_point.toString());
            // System.out.println(temp_datapoint.distance(query_point) + " " + temp_mbr.distance(query_point));
            if(temp_datapoint.distance(query_point) >= temp_mbr.distance(query_point)){
                // System.out.println("MBR IS A POINT : " + temp_mbr.isPoint() + " " + temp_mbr.toString());
                if(temp_mbr.isPoint()){
                    // System.out.println("MBR IS A POINT : " + temp_mbr.toString());
                    DataPoint mbr_to_point = temp_mbr.getPoint();
                    ans.insert(mbr_to_point);
                    // System.out.println("MaxHeap : "+ans.toString());
                }else{
                    ArrayList<MBR> children = kdtree.getChildren(temp_mbr);
                    // System.out.println(children.size());
                    for(int i = 0; i < children.size(); i++){
                        mbr.insert(children.get(i));
                    }
                }
            }else{
                break;
            }
        }
        DataPoint[] output = ans.get_all_points();
        Arrays.sort(output, new ArrayComparator(query_point));
        return output;
    }

    public static DataPoint[] sequential_scan(ArrayList<DataPoint> dataset, DataPoint query_point, int no_of_points){
        MaxHeap answer = new MaxHeap(new DataPoint[0],query_point, no_of_points);
        for(int i = 0; i < dataset.size(); i++){
            answer.insert(dataset.get(i));
        }
        DataPoint[] output = answer.get_all_points();
        Arrays.sort(output, new ArrayComparator(query_point));
        return output;
    }

}




























































































