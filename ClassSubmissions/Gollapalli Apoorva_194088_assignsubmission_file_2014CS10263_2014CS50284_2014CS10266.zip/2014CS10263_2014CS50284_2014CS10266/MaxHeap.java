import java.util.Arrays;

public class MaxHeap {

    DataPoint[] heap;
    int size;
    DataPoint query_point;
    int max_size;

    public double heapValue(DataPoint d1){
        return d1.distance(query_point);
    }

    public double heapValue(int index){
        return heapValue(this.heap[index]);
    }

    public MaxHeap(DataPoint[] heap,DataPoint query_point,int max_size) {
        this.size = heap.length;
        this.heap = Arrays.copyOf(heap, size);
        this.query_point = query_point;
        this.max_size = max_size;
    }
    
    public void maxHeapify(int index) {
        int largest = index;
        int leftIndex = 2 * index + 1;
        int rightIndex = 2 * index + 2;

        if ((leftIndex < size) && (heapValue(index) < heapValue(leftIndex))) {
            largest = leftIndex;
        }
        if (rightIndex < size && heapValue(largest) < heapValue(rightIndex)) {
            largest = rightIndex;
        }

        if (largest != index) {
            swap(index, largest);
            maxHeapify(largest);
        }
    }

    public void buildMaxHeap() {
        for (int i = size / 2 - 1; i >= 0; i--) {
            maxHeapify(i);
        }
    }

    public void insert(DataPoint elem) {
        // increase heap size
        if(size == max_size){
            // remove an element and insert
            extractMax();
            insert(elem);
        }else{
            heap = Arrays.copyOf(heap, size + 1);
            int i = size;
            int parentIndex = (int) Math.floor((i - 1) / 2);
            // move up through the heap till you find the right position
            while (i > 0 && heapValue(elem) > heapValue(parentIndex)) {
                heap[i] = heap[parentIndex];
                i = parentIndex;
                parentIndex = (int) Math.floor((i - 1) / 2);
            }
            heap[i] = elem;
            size++;
        }
    }

    public DataPoint findMax() {
        if (size == 0) {
            return null;
        } else {
            return heap[0];
        }
    }

    public DataPoint extractMax() {
        if (size == 0) return null;

        DataPoint min = heap[0];
        heap[0] = heap[size - 1];
        size--;
        maxHeapify(0);
        return min;
    }

    public int getSize() {
        return size;
    }

    public DataPoint[] getHeap() {
        return heap;
    }

    private void swap(int firstIndex, int secondIndex) {
        DataPoint temp = heap[firstIndex];
        heap[firstIndex] = heap[secondIndex];
        heap[secondIndex] = temp;
    }

    public DataPoint[] get_all_points(){
        return heap;
    }

    public String toString(){
        String ans = "";
        for(int i = 0 ; i < size; i++){
            ans += heap[i].toString() + "\n";
        }
        return ans;
    }
}