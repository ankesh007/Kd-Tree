import java.lang.Math;

public class DataPoint{
    double[] value;
    int size;

    DataPoint(int size){
        this.size = size;
        this.value = new double[size];
    }

    DataPoint(double[] value){
        this.size = value.length;
        this.value = value;
    }

    public double getValueAtDimension(int dimension){
        return this.value[dimension];
    }

    public double[] getValue(){
        return this.value;
    }

    public void print(){
    	for(int i = 0 ; i < size; i++){
    		System.out.print(value[i] + " ");
    	}
    	System.out.println();

    }

    public int size(){
    	return size;
    }

    public double distance(DataPoint d){
        double ans = 0.0;
        for(int i = 0 ; i < size; i++){
            ans += Math.pow(this.value[i] - d.getValueAtDimension(i), 2);
        }
        ans = Math.sqrt(ans);
        return ans;
    }

    public String toString(){
        String ans = "";
        for(int i = 0 ; i < size; i++){
            ans += value[i] + " ";
        }
        return  ans;
    }
}
