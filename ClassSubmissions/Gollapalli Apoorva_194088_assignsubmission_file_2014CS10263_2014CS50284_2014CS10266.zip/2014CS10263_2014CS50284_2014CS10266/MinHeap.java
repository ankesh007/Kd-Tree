import java.util.Arrays;

public class MinHeap {

    MBR[] heap;
    int size;
    DataPoint query_point;
    int max_size;

    public double heapValue(MBR d1){
        return d1.distance(query_point);
    }

    public double heapValue(int index){
        return heapValue(this.heap[index]);
    }

    public MinHeap(MBR[] heap,DataPoint query_point) {
        this.size = heap.length;
        this.heap = Arrays.copyOf(heap, size);
        this.query_point = query_point;
    }

    public void minHeapify(int index) {
        int smallest = index;
        int leftIndex = 2 * index + 1;
        int rightIndex = 2 * index + 2;

        if ((leftIndex < size) && (heapValue(index) > heapValue(leftIndex))) {
            smallest = leftIndex;
        }
        if ((rightIndex < size) && (heapValue(smallest) > heapValue(rightIndex))) {
            smallest = rightIndex;
        }

        if (smallest != index) {
            swap(index, smallest);
            minHeapify(smallest);
        }
    }

   
    public void buildMinHeap() {
        for (int i = size / 2 - 1; i >= 0; i--) {
            minHeapify(i);
        }
    }

    public void insert(MBR elem) {
        heap = Arrays.copyOf(heap, size + 1);
        int i = size;
        int parentIndex = (int) Math.floor((i - 1) / 2);
        while ((i > 0) && (heapValue(elem) < heapValue(parentIndex))) {
            heap[i] = heap[parentIndex];
            i = parentIndex;
            parentIndex = (int) Math.floor((i - 1) / 2);
        }
        heap[i] = elem;
        size++;
    }

    public MBR findMin() {
        if (size == 0) {
            return null;
        } else {
            return heap[0];
        }
    }

    public MBR extractMin() {
        if (size == 0) return null;

        MBR min = heap[0];
        heap[0] = heap[size - 1];
        size--;
        minHeapify(0);
        return min;
    }

    public int getSize() {
        return size;
    }

    public MBR[] getHeap() {
        return heap;
    }

    private void swap(int firstIndex, int secondIndex) {
        MBR temp = heap[firstIndex];
        heap[firstIndex] = heap[secondIndex];
        heap[secondIndex] = temp;
    }

    public String toString(){
        String ans = "";
        for(int i = 0 ; i < size; i++){
            ans += heap[i].toString() + "\n";
        }
        return ans;
    }
}