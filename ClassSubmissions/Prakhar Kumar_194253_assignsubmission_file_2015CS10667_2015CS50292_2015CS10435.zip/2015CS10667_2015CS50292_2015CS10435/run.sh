#!/bin/bash
make KdTree
./KdTree $1