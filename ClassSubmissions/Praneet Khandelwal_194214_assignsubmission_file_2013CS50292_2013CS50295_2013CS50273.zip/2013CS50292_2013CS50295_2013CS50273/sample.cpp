#include <stdlib.h>

#include <iostream>
#include <vector>
#include <limits.h>
#include <random>
#include <time.h>
#include <ctime>
#include <sys/time.h>
#include <queue>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <string>


using namespace std;

ofstream fil, fil1, fil2;

struct kdtreeNode
{
	vector<double> point;
	kdtreeNode* left;
	kdtreeNode* right;
	int dim_broken;
	int number;
	double point_dist;
	double mbr_dist;
	int counter_mbr;
	int counter_point;
	vector<double> min_point;
	vector<double> max_point;
	kdtreeNode(vector<double>& p, kdtreeNode* left, kdtreeNode* right, int d);
	void printNode();
};

class kdtree
{
public:
	static int count;
	
	kdtree();
	~kdtree();
	kdtree(vector<vector<double>>& input);

	kdtreeNode* root;
	vector<vector<double>> points;
	int dim;
	// kdtreeNode* getRoot();
	// void getAllPoints(vector<vector<double>>& points);
	int findMedian(int left, int right, int dim);
	void printTree();
	void knn(vector<double> & query, int k, int j);
	void sequential(vector<double> & query,int k);
	void sequential2(vector<double> & query,int k);
	pair<double,double> sequential23(vector<double> & query,int k);
	kdtreeNode* createTree(int i, int left, int right);
	static int nodenumber;
};

int kdtree::count = 0;
int kdtree::nodenumber = 0;


void printPoint(vector<double>& point)
{
	for(int i=0;i<point.size();i++)
	{
		if(i == point.size()-1)
		{
			cout<<point[i];
		}
		else
			cout<<point[i]<<" ";
	}
	cout<<"\n";
}

void printPointtofile(vector<double>& point, ofstream& fil)
{
	for(int i=0;i<point.size();i++)
	{
		if(i == point.size()-1)
		{
			fil<<to_string(point[i]);
		}
		else
			fil<<to_string(point[i]) + " ";
	}
	fil<<"\n";
}

void printAllPoints(vector<vector<double> >& points)
{
	for(int i=0;i<points.size();i++)
	{
		printPoint(points[i]);
	}
}

kdtreeNode::kdtreeNode(vector<double>& p, kdtreeNode* l, kdtreeNode* r, int d)
{
	point = p;
	left = l;
	right = r;
	dim_broken = d;
	point_dist = -1;
	mbr_dist = -1;
	counter_mbr = -1;
	counter_point = -1;
	for(int i=0;i<p.size();i++)
	{
		min_point.push_back(p[i]);
		max_point.push_back(p[i]);
	}
}

void kdtreeNode::printNode()
{
	printPoint(point);
	
}

kdtree::kdtree()
{
	root = NULL;
}

kdtree::~kdtree()
{
	delete root;
}

void resetdistances(kdtreeNode* root)
{
	if(root == NULL) return;
	root->point_dist = -1;
	root->mbr_dist = -1;
	resetdistances(root->left);
	resetdistances(root->right);
	return;
}

kdtree::kdtree(vector<vector<double> >& input)
{
	points = input;
	dim = input[0].size();
	root = NULL;
}


 
void swap(vector<double> *a, vector<double> *b)
{
   	vector<double> temp = *a;
    *a = *b;
    *b = temp;
}
 

int partition(vector<vector<double> >& points, int l, int r, int d)
{
    int x = points[r][d], i = l;
    for (int j = l; j <= r - 1; j++)
    {
        if (points[j][d] <= x)
        {
            swap(&points[i], &points[j]);
            i++;
        }
    }
    swap(&points[i], &points[r]);
    return i;
}
 
int randomPartition(vector<vector<double> >& points, int l, int r, int d)
{
    int length = r-l+1;
    int pivot = rand() % length;
    

    swap(&points[l+pivot], &points[r]);
    
    return partition(points, l, r, d);
}

int kthSmallest(vector<vector<double> >& points, int l, int r, int k, int d)
{
    if (k > 0 && k <= r - l + 1)
    {
        int pos = randomPartition(points, l, r, d);
        if (pos-l == k-1)
            return pos;
        if (pos-l > k-1)  
            return kthSmallest(points, l, pos-1, k, d);
 
        return kthSmallest(points, pos+1, r, k-pos+l-1, d);
    }
 
    return INT_MAX;
}

int kdtree::findMedian(int left, int right, int d)
{
	if(left == right) return left;
	int length = right - left + 1;
	int pos = kthSmallest(points, left, right, length/2+1, d);
	return pos;
}

kdtreeNode* kdtree::createTree(int i, int left, int right)
{
	if(left > right) return NULL;

	int index = findMedian(left,right,i);
	kdtreeNode* n = new kdtreeNode(points[index], NULL, NULL, i);
	n->number = nodenumber;
	nodenumber++;
	if(count == 0) root = n; 
	i = (i+1)%dim;
	count++;
	n->left = createTree(i,left, index-1);
	n->right = createTree(i, index+1, right);
	if( n->left != NULL )
	{
		for(int j=0;j<(n->min_point).size();j++)
		{
			n->min_point[j] = min(n->min_point[j],n->left->min_point[j]);
			n->max_point[j] = max(n->max_point[j],n->left->max_point[j]);
		}
	}
	if( n->right != NULL )
	{
		for(int j=0;j<(n->min_point).size();j++)
		{
			n->min_point[j] = min(n->min_point[j],n->right->min_point[j]);
			n->max_point[j] = max(n->max_point[j],n->right->max_point[j]);
		}
	}
	return n;
}

void kdtree::printTree()
{
	queue<pair<kdtreeNode*,int> > q;
	q.push(make_pair(root,-1));
	while(!q.empty())
	{
		pair<kdtreeNode*,int> t = q.front();
		t.first->printNode();
		for(int z=0;z<(t.first->min_point).size();z++)
		{
			cout << t.first->min_point[z]<<" ";
		}
		cout <<endl;
		for(int z=0;z<(t.first->max_point).size();z++)
		{
			cout << t.first->max_point[z]<<" ";
		}
		cout <<endl;
		
		q.pop();
		if(t.first->left!=NULL)
			q.push(make_pair(t.first->left, t.first->number));
		if(t.first->right!=NULL)
			q.push(make_pair(t.first->right, t.first->number));
	}
}


double cal_point_dist(kdtreeNode * node, vector<double> & q)
{
	double ans = 0;
	for (int i=0;i<q.size();i++)
	{
		double temp = abs(q[i]-(node->point)[i]);
		ans += pow(temp,2);
	}
	return sqrt(ans);
}

double cal_mbr_dist(kdtreeNode * node, vector<double> & q)
{
	double ans = 0;
	for(int i=0;i<q.size();i++)
	{
		double temp = 0;
		double temp1 = node->min_point[i] - q[i];
		double temp2 = q[i] - node->max_point[i];
		if(temp1 > 0)
		{
			temp = temp1;
		}
		else if(temp2 > 0)
		{
			temp = temp2;
		}
		else
		{
			temp = 0;
		}
		ans += pow(temp,2);
	}
	return sqrt(ans);
}

class Compare
{
public:
    bool operator() (kdtreeNode *a, kdtreeNode *b)
    {
    	if(a->point_dist < b->point_dist)
        	return true;
        else if(a->point_dist == b->point_dist)
        {
        	vector<double>& first = a->point;
        	vector<double>& second = b->point;
        	for(int i=0;i<first.size();i++)
        	{
        		if(first[i] > second[i]) return false;
        		else if(first[i] < second[i]) return true;
        	}
        	return true;
        }
    	return false;
    }
};


class Compare_mbr
{
public:
    bool operator() (kdtreeNode *a, kdtreeNode *b)
    {
    	if(a->mbr_dist > b->mbr_dist)
        	return true;
    	return false;
    }
};

 bool comp_new(kdtreeNode *a, kdtreeNode *b, double a_dis, double b_dis)
{
	if(a_dis < b_dis)
    	return true;
    else if(a_dis == b_dis)
    {
    	vector<double>& first = a->point;
    	vector<double>& second = b->point;
    	for(int i=0;i<first.size();i++)
    	{
    		if(first[i] < second[i]) return true;
    		else if(first[i] > second[i]) return false;
    	}
    	return true;
    }
	return false;
}

void kdtree::knn(vector<double>& query, int k, int q_no)
{
	priority_queue<kdtreeNode *, vector<kdtreeNode *>, Compare > answer;
	priority_queue<kdtreeNode *, vector<kdtreeNode *>, Compare_mbr > candidate;
	root->point_dist = cal_point_dist(root,query);
	root->counter_point = q_no;
	root->mbr_dist = cal_mbr_dist(root,query);
	root->counter_mbr = q_no;
	candidate.push(root);
	answer.push(root);
	while(!candidate.empty())
	{
		kdtreeNode * mbr_node = candidate.top();
		candidate.pop();
		kdtreeNode * answer_node = answer.top();
		if(answer_node->counter_point != q_no)
		{
			answer_node->point_dist = cal_point_dist(answer_node,query);
			answer_node->counter_point = q_no;
		}
		if(mbr_node->counter_mbr != q_no)
		{
			mbr_node->mbr_dist = cal_mbr_dist(mbr_node,query);
			answer_node->counter_mbr = q_no;
		}
		if(answer.size() >= k)
		{
			if(mbr_node->mbr_dist > answer_node->point_dist)
			{
				break;
			}
		}
		if(mbr_node->counter_point != q_no)
		{
			mbr_node->point_dist = cal_point_dist(mbr_node,query);
			mbr_node->counter_point = q_no;
		}
		
		if(comp_new(mbr_node,answer_node,mbr_node->point_dist,answer_node->point_dist))
		{
			answer.push(mbr_node);
			if(answer.size() > k)
			{
				answer.pop();
			}
		}
		if(mbr_node->left != NULL)
		{
			if(mbr_node->left->counter_mbr != q_no)
			{
				mbr_node->left->mbr_dist = cal_mbr_dist(mbr_node->left,query);
				mbr_node->left->counter_mbr = q_no;
			}
			if(answer.size() <= k && mbr_node->left->mbr_dist <= answer_node->point_dist)
			{
				candidate.push(mbr_node->left);
			}
		}
		if(mbr_node->right != NULL)
		{
			if(mbr_node->right->counter_mbr != q_no)
			{
				mbr_node->right->mbr_dist = cal_mbr_dist(mbr_node->right,query);
				mbr_node->right->counter_mbr = q_no;
			}
			if(answer.size() <= k && mbr_node->right->mbr_dist <= answer_node->point_dist)
			{
				candidate.push(mbr_node->right);
			}
		}
	}
	vector<kdtreeNode*> final_answer;
	while(!answer.empty())
	{
		final_answer.push_back(answer.top());
		answer.pop();
	}
	for(int i=final_answer.size()-1;i>=0;i--)
	{
		printPointtofile(final_answer[i]->point,fil);
	}
}


bool sort_function(const pair<kdtreeNode*,double> & a, const pair<kdtreeNode*,double> & b)
{
	if(a.second < b.second) return true;
	else if(a.second == b.second)
	{
		vector<double> first = a.first->point;
    	vector<double> second = b.first->point;
    	for(int i=0;i<first.size();i++)
    	{
    		if(first[i] < second[i]) return true;
    		else if(first[i] > second[i]) return false;
    	}
    	return true;
	}
	else return false;
}


double find_dist_points(vector<double> & p, vector<double> &q)
{
	double ans = 0;
	for (int i=0;i<q.size();i++)
	{
		double temp = abs(q[i]-p[i]);
		ans += pow(temp,2);
	}
	return sqrt(ans);
}



void kdtree::sequential(vector<double> & query,int k)
{
	
	vector<pair<kdtreeNode*, double>> distances;
	queue<kdtreeNode*> q;
	q.push(root);
	while(!q.empty())
	{
		kdtreeNode* f = q.front();
		q.pop();
		double dist = find_dist_points(f->point,query);
		distances.push_back(make_pair(f,dist));
		if(f->left!= NULL) q.push(f->left);
		if(f->right!= NULL) q.push(f->right);
	}

	sort(distances.begin(),distances.end(),sort_function);
	
	for(int i=0;i<k;i++)
	{
		printPointtofile(distances[i].first->point,fil1);
		
	}
}


class Compare_pair
{
public:
    bool operator() (pair<vector<double>*,double> a, pair<vector<double>*,double> b)
    {
    	if(a.second < b.second) return true;
		else if(a.second == b.second)
		{
			vector<double>& first = *a.first;
	    	vector<double>& second = *b.first;
	    	for(int i=0;i<first.size();i++)
	    	{
	    		if(first[i] < second[i]) return true;
	    		else if(first[i] > second[i]) return false;
	    	}
	    	return true;
		}
		else return false;
    }
};

 bool comp_new2(vector<double> *a, vector<double> *b, double a_dis, double b_dis)
{
	if(a_dis < b_dis)
    	return true;
    else if(a_dis == b_dis)
    {
    	vector<double>& first = *a;
    	vector<double>& second = *b;
    	for(int i=0;i<first.size();i++)
    	{
    		if(first[i] < second[i]) return true;
    		else if(first[i] > second[i]) return false;
    	}
    	return true;
    }
	return false;
}


void kdtree::sequential2(vector<double> & query,int k)
{
	priority_queue<pair<vector<double>*,double>, vector<pair<vector<double>*,double>>, Compare_pair> pq;


	for(int i=0;i<points.size();i++)
	{
		double dist = find_dist_points(points[i],query);
		if(i<k)
		{
			pq.push(make_pair(&points[i],dist));
		}
		else
		{
			if(comp_new2(&points[i],pq.top().first,dist,pq.top().second))
			{
				pq.pop();
				pq.push(make_pair(&points[i],dist));
			}
		}
	}
	vector<vector<double>*> final_answer;
	while(!pq.empty())
	{
		final_answer.push_back(pq.top().first);
		pq.pop();
	}
	for(int i=final_answer.size()-1;i>=0;i--)
	{
		printPointtofile(*final_answer[i],fil2);
	}
}

pair<double,double> kdtree::sequential23(vector<double> & query,int k)
{
	priority_queue<pair<vector<double>*,double>, vector<pair<vector<double>*,double>>, Compare_pair> pq;


	for(int i=0;i<points.size();i++)
	{
		double dist = find_dist_points(points[i],query);
		if(i<k)
		{
			pq.push(make_pair(&points[i],dist));
		}
		else
		{
			if(comp_new2(&points[i],pq.top().first,dist,pq.top().second))
			{
				pq.pop();
				pq.push(make_pair(&points[i],dist));
			}
		}
	}
	vector<vector<double>*> final_answer;
	int count =0;
	double f,s;
	while(!pq.empty())
	{
		final_answer.push_back(pq.top().first);
		count++;
		if(count == 1) s = pq.top().second; 
		if(count == 99) f = pq.top().second;
		pq.pop();
	}
	for(int i=final_answer.size()-1;i>=0;i--)
	{
		printPointtofile(*final_answer[i],fil2);
	}
	return make_pair(f,s);
}

void parseline(ifstream& ifil, vector<vector<double>>& points)
{
	int D,N;
	ifil >> D >> N;
	// dim = stoi(line);
	for(int i=0;i<N;i++)
	{
		vector<double> indi_point;
		double component;
		for(int j=0;j<D;j++)
		{
			ifil >> component;
			indi_point.push_back(component);
		}
		points.push_back(indi_point);
	}
}

int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];
	// [TODO] Construct kdTree using dataset_file here
	int dim;
	ifstream dfile; 
	vector<vector<double>> points;
	dfile.open(dataset_file);
	parseline(dfile, points);
	
	kdtree* kd = new kdtree(points);
	kd->createTree(0,0,points.size()-1);
	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	// cerr << dataset_file << " " << query_file << " " << k << endl;

	ifstream qfile;
	qfile.open(query_file);
	vector<vector<double>> query;
	parseline(qfile, query);

	fil.open("results.txt");
	// fil1.open("results1.txt");
	// fil2.open("results2.txt");

	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt
	// double avg_second = 0;
	// double avg_cent = 0;
	for(int j=0;j<query.size();j++)
	{
		// kd->sequential2(query[j],k);
		kd->knn(query[j], k, j);
		// kd->sequential(query[j], k);
		// pair<double, double> sec_cent = kd->sequential23(query[j],k);
		// avg_second = avg_second + sec_cent.first;
		// avg_cent = avg_cent + sec_cent.second;
	}
	// avg_cent = avg_cent/query.size();
	// avg_second = avg_second /query.size();
	// cerr << avg_second <<"  "<< avg_cent << endl;
	fil.close();
	// fil1.close();
	// fil2.close();
	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
}
