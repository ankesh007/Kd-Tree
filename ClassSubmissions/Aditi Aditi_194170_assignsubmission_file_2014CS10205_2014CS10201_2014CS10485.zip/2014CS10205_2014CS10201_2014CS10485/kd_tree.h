#ifndef KD_TREE_H
#define KD_TREE_H

#include <vector>
#include <queue>
#include <utility>
#include <functional>

using namespace std;

using D_TYPE = double;
using DATA = vector<D_TYPE>;
using comp_pair = pair<D_TYPE, int>;
using comp_t = function<bool(const comp_pair &, const comp_pair &)>;

class KD_Tree {
 private:
  const int dim;
  vector<DATA> data_vec;
  
  void make_tree(int l, int r, int d);
  void k_nearest_nbr_subroutine(int l, int r, int d, const DATA &p);
  void linear_scan(int l, int r, const DATA &p);

  comp_t comp = [&] (const comp_pair& a, const comp_pair& b) {
    if(a.first != b.first) {
      return (a.first < b.first);
    }
    if(a.second == -1 || b.second == -1) return false;
    for(int i=0; i<dim; i++) {
      if(data_vec[a.second][i] != data_vec[b.second][i]) {
        return (data_vec[a.second][i] < data_vec[b.second][i]);
      }
    }
    return false;
  };

  priority_queue<comp_pair, vector<comp_pair>, comp_t > w_list;

 public:
  KD_Tree(int dim) : visited_nodes(0), dim(dim), w_list(comp) {}
  
  int visited_nodes;

  D_TYPE dist(const DATA &a, const DATA &b);
  bool bulk_load(const vector<DATA> &data_vec);
  bool k_nearest_nbr(const DATA &p, int k, vector<DATA> &result, bool linear_scan = false);
  void print_tree();
};

#endif