#!/bin/bash

g++ -c -std=c++11 -Ofast kd_tree.cc 
g++ -c -std=c++11 -Ofast main.cc
g++ -std=c++11 -Ofast main.o kd_tree.o -o out
./out $1