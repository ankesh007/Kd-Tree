#include <fstream>
#include <iostream>
#include <random>
#include <chrono>
#include <cstdlib>

#include "kd_tree.h"

using namespace std;

void generate_dataset(int dim, int size, vector<DATA> &v) {
  uniform_real_distribution<double> unif(0.0,1.0);
  default_random_engine re(0);

  v = vector<DATA>(size);
  for(int i=0; i<size; ++i) {
    DATA &d = v[i];
    d = DATA(dim);
    for(int j=0; j<dim; j++) {
      d[j] = unif(re);
    }
  }
}

void run_query(KD_Tree &tree, vector<DATA> &query_points, int k) {
  tree.visited_nodes = 0;
  vector<DATA> result;

  D_TYPE closest_nbr_dist = 0;
  D_TYPE farthest_nbr_dist = 0;

  auto start_time = chrono::high_resolution_clock::now();

  for(auto &q : query_points){
    tree.k_nearest_nbr(q, k, result);
    closest_nbr_dist += tree.dist(q, result[1]);
    farthest_nbr_dist += tree.dist(q, result[k-1]);
  }

  auto end_time = chrono::high_resolution_clock::now();

  auto time_taken = chrono::duration_cast<chrono::milliseconds>(end_time - start_time).count();

  cerr << "Time taken in ms: " << time_taken << endl;
  cerr << "AVG Ratio: " << farthest_nbr_dist/closest_nbr_dist << endl;
  cerr << "AVG nodes visited: " << tree.visited_nodes/query_points.size() << endl << endl;
}

void test(int dim, int q_size, int tree_size, int k) {
  cerr << "Dim: " << dim << endl;

  vector<DATA> query_points, kd_tree_data;
  generate_dataset(dim, q_size, query_points);
  generate_dataset(dim, tree_size, kd_tree_data);

  KD_Tree tree(dim);
  tree.bulk_load(kd_tree_data);

  run_query(tree, query_points, k);
}

void printtofile(ofstream &fout, vector<DATA> &result) {
  for(auto &p : result){
    for(auto &d : p) fout << d << " ";
    fout << endl;
  }
}

void f1(string filename) {
  ifstream fin(filename);

  int D, N1;
  vector<DATA> dataset;
  
  fin >> D >> N1;

  for(int i = 0; i < N1; i++) {
    D_TYPE d;
    DATA datapoint;
    for(int j = 0; j < D; j++) {
      fin >> d;
      datapoint.push_back(d);
    }
    dataset.push_back(datapoint);
  }

  KD_Tree tree(D);
  tree.bulk_load(dataset);
  fin.close();

  cout << "0" << endl;

  string queryname;
  int K;

  cin >> queryname >> K;
  ifstream queryfile(queryname);
  ofstream outputfile("results.txt");

  int N2;
  queryfile >> D >> N2;

  for(int i = 0; i < N2; i++) {
    D_TYPE d;
    DATA querypoint;
    for(int j = 0; j < D; j++) {
      queryfile >> d;
      querypoint.emplace_back(d);
    }
    vector<DATA> result;
    tree.k_nearest_nbr(querypoint, K, result);
    printtofile(outputfile, result);
  }

  queryfile.close();
  outputfile.close();

  cout << "1" << endl;
}

int main(int argc, char const *argv[]) {

  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  // for(int i=2; i<=20; ++i){
  //   test(i, 100, atoi(argv[2]), atoi(argv[3]));
  // }

  string filename = string(argv[1]);
  f1(filename);

  return 0;
}