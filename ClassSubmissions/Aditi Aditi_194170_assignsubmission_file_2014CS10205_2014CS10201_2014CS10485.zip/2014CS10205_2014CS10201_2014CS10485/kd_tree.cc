#include <algorithm>
#include <cassert>
#include <iostream>
#include <limits>
#include <cmath>

#include "kd_tree.h"

using namespace std;

D_TYPE INF = numeric_limits<D_TYPE>::infinity();

D_TYPE KD_Tree::dist(const DATA &a, const DATA &b) {
  D_TYPE distance = 0;
  for(int i=0; i<dim; ++i){
    distance += (a[i] - b[i])*(a[i] - b[i]);
  }
  return distance;
}

void KD_Tree::make_tree(int l, int r, int d){
  auto comparator = [&] (const DATA &a, const DATA &b) {
    return a[d] < b[d];
  };
  // cerr << l << " " << r << " " << d << endl;
  sort(data_vec.begin() + l, data_vec.begin() + r + 1, comparator);
  if(l >= r-1) return;
  
  int mid = (l+r)/2;
  make_tree(l, mid-1, (d+1)%dim);
  make_tree(mid+1, r, (d+1)%dim);
}

bool KD_Tree::bulk_load(const vector<DATA> &data_vec){
  for(auto &d : data_vec) assert(d.size() == dim);
  this->data_vec = data_vec;
  if (data_vec.size() == 0) return false;
  make_tree(0, data_vec.size()-1, 0);
  return true;
}

void KD_Tree::print_tree(){
  for (auto &d : data_vec)
  {
    for (auto &x : d)
      cerr << x << "\t";
    cerr << endl;
  }
}

void KD_Tree::linear_scan(int l, int r, const DATA &p) {
  for(int i=l; i <= r; ++i) {
    D_TYPE x_dist = dist(data_vec[i], p);
    if(x_dist <= w_list.top().first) {
      w_list.push(make_pair(x_dist, i));
      w_list.pop();
    }
  }
}

void KD_Tree::k_nearest_nbr_subroutine(int l, int r, int d, const DATA &p) {
  // Base case
  if(r - l < 2.5 * dim) {
    // Do a linear scan if range is less than 2.5*dim elements
    visited_nodes += (r-l+1);
    linear_scan(l, r, p);
    return;
  }

  int mid = (l+r)/2;
  auto &x = data_vec[mid];

  visited_nodes++;
  D_TYPE x_dist = dist(x,p);
  if(x_dist <= w_list.top().first) {
    w_list.push(make_pair(x_dist, mid));
    w_list.pop();
  }

  if(p[d] < x[d]) {
    // Go left first, then right
    k_nearest_nbr_subroutine(l, mid-1, (d+1)%dim, p);
    if(p[d] + sqrt(w_list.top().first) >= x[d]) k_nearest_nbr_subroutine(mid+1, r, (d+1)%dim, p);
  }
  else {
    // Go right first, then left
    k_nearest_nbr_subroutine(mid+1, r, (d+1)%dim, p);
    if(p[d] - sqrt(w_list.top().first) <= x[d]) k_nearest_nbr_subroutine(l, mid-1, (d+1)%dim, p);
  }
}

bool KD_Tree::k_nearest_nbr(const DATA &p, int k, vector<DATA> &result, bool ls) {
  assert(w_list.empty());
  result = vector<DATA>(k);
  for(int i = 0; i < k; i++) {
    w_list.push(make_pair(INF, -1));
  }
  
  if(ls)
    linear_scan(0, data_vec.size()-1, p);
  else
    k_nearest_nbr_subroutine(0, data_vec.size()-1, 0, p);

  for(int i = 0; i < k; ++i){
    auto &x = w_list.top();
    assert(x.second != -1);
    result[k-1-i] = data_vec[x.second];
    w_list.pop();
  }
  assert(w_list.empty());

  return true;
}
