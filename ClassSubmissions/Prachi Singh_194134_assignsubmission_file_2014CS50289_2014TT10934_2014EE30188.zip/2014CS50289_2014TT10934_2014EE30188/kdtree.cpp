#include "stdc++.h"
#include <iostream>
#include <cstdio>
#include <ctime>
using namespace std;

class Node{
	public:
	int    split_dim;
	Node  *leftChild;
	Node  *rightChild;
	double coordinate[20];
	Node (double coordinates[20])
	{
	  memcpy(coordinate, coordinates, sizeof(coordinate));
	  leftChild = nullptr;
	  rightChild = nullptr;
	  split_dim = -1;
	}
};

int dimension;
int data_num;
double *point;
Node* mytree_root;
ofstream outfile;

double l2_distance(double point1[], double* point2){
    double answer = 0.0;
    for (int i =0; i< dimension; i++){
        answer+=pow((point1[i]-point2[i]),2);
    }
    return sqrt(answer);
};


bool tieBreaker(Node* p1, Node*p2){
    for (int i =0; i< dimension; i++){
        if (p1->coordinate[i] != p2->coordinate[i]) return (p1->coordinate)[i] < (p2->coordinate)[i];
    }
    return true;
};

class myComparator_flipped
{
public:
    int operator() ( Node* p1,  Node* p2)
    {
        double a = l2_distance(p1->coordinate,point);
        double b = l2_distance(p2->coordinate,point);
        if (a!=b) return a<b;
        else{
            return tieBreaker(p1,p2);
        }
    }
};


class myComparator
{
public:
    int operator() ( Node* p1,  Node* p2)
    {
        double a = l2_distance(p1->coordinate,point);
        double b = l2_distance(p2->coordinate,point);
        if (a!=b) return a<b;
        else{
            return tieBreaker(p1,p2);
        }
    }
};

priority_queue <Node*, vector<Node*>, myComparator_flipped > answer_set;


void swap(Node *x, Node *y) {
    double tmp[dimension];
    memcpy(tmp,  x->coordinate, sizeof(tmp));
    memcpy(x->coordinate, y->coordinate, sizeof(tmp));
    memcpy(y->coordinate, tmp,  sizeof(tmp));
}

Node* findMedian(Node *start, Node *end, int index){
	// cout<<"I AM IN FM"<<endl;
	if (end <= start)
	{
		// cout<<"leaf"<<endl;
		return nullptr;
	}
	if (end==start+1)
	{
		// cout<<"almostend"<<endl;
		return start;
	}
	Node *p= start + (end-start)/2 ;
	Node *store= start + (end-start)/2 ;
	Node *md= start + (end-start)/2 ;
	double pivot;
	while(true){
		pivot = md->coordinate[index];
		// cout<<"pivot"<<pivot<<endl;
		swap(md, end-1);
		for (store = p = start; p < end; p++)
		{
			if (p->coordinate[index] < pivot) {
                if (p != store)
                    swap(p, store);
                store++;
            }
		}
		swap(store, end - 1);
 		// cout<<store->coordinate[index]<<endl;
 		// cout<<md->coordinate[index]<<endl;
        /* median has duplicate values */
        double v1 = store->coordinate[index];
        double v2 = md->coordinate[index];
        if (v1 == v2){
        	// cout<<"return md"<<endl;
        	return md;
        	// cout<<"return2 md";
        }
        if (store > md){
        	end = store;
        }else{
        	start = store;
        }
	}
}

Node* build_tree(Node *start, int len, int index){
	// cout<<"I am in build_tree"<<endl;
	if (!len)
	{
		return 0;
	}
	Node *end = start+len;
	Node *n=findMedian(start, end, index);
	if (n)
	{
		n->split_dim = index;
		index = (index+1)%dimension;
		n->leftChild = build_tree(start, n-start, index);
		n->rightChild = build_tree(n+1, end-(n+1), index);
	}
	return n;
}

void printTree(Node* root){
    cout<<"split"<<root->split_dim<<endl;
    cout<<"coord"<<endl;
    for (int i = 0; i < dimension; ++i)
    {
        cout<<root->coordinate[i]<<",";
    }
    cout<<endl;
    if (root->leftChild == nullptr && root->rightChild == nullptr)
    {
        // cout<<"IT WAS A LEAF"<<endl;
        return;
    }else{
        if (root->leftChild == nullptr)
        {
            printTree(root->rightChild);
        }else
        {
            if (root->rightChild == nullptr)
            {
                printTree(root->leftChild);
            }else{
                printTree(root->leftChild);
                printTree(root->rightChild);
            }
        }
    }
    return;
};

Node* read_file(char* dataset_file){
    ifstream inFile (dataset_file);
    string line;
    string line2;
    getline(inFile,line);
    stringstream lineStream(line);
    string token;
    getline(lineStream, token, ' ');
    dimension= stoi(token);
    getline(lineStream, token, ' ');
    data_num = stoi(token);
    Node *data = (Node*) calloc(data_num, sizeof(Node));
    int ctr;
    int data_cnt=0;
    while(getline(inFile, line2))
    {
        double single_line[20];
        stringstream new_line(line2);
        // cout<<line2<<endl;
        string value;
        ctr = 0;
        while(getline(new_line, value, ' '))
        {
            single_line[ctr] = stod(value);
            ctr++;
        }

        Node node = Node(single_line);

        data[data_cnt] = node;
        data_cnt++;
    }
    Node *root = build_tree(data,data_num,0);
    // printTree(root);
    return root;
};

void best_first (Node* root, double* point, int k)
{ 
	if (root==nullptr)
	{
		return;
	}
    // cout<<3<<endl;
    if (answer_set.size() == k){
        answer_set.push(root);
        answer_set.pop();
    }else{
    	answer_set.push(root);
    }

    Node* n_answer = answer_set.top();
    // cout<<1<<endl;
    int split_dim = root->split_dim;
    bool flag = (point[split_dim] < root->coordinate[split_dim]);
    // cout<<"flag:"<<flag<<endl;
    if (flag){
        best_first(root->leftChild, point, k);
    }else{
        best_first(root->rightChild, point, k);        
    }
    if (answer_set.size() < k || abs(point[split_dim] - root->coordinate[split_dim]) < l2_distance(n_answer->coordinate,point)){
        if (flag){
            best_first(root->rightChild, point, k);  
        }
        else{
            best_first(root->leftChild, point, k);  
        }
    }
};

void seq_scan (Node* root, double* point, int k)
{ 
    if (root==nullptr)
    {
        return;
    }
    // cout<<3<<endl;
    if (answer_set.size() == k){
        answer_set.push(root);
        answer_set.pop();
    }else{
        answer_set.push(root);
    }
    seq_scan(root->leftChild, point, k);
    seq_scan(root->rightChild, point, k);        
};

vector<double*> read_query_file(char* query_file){
    ifstream inFile (query_file);
    string line;
    string line2;
    getline(inFile,line);
    stringstream lineStream(line);
    string token;
    getline(lineStream, token, ' ');
    int query_dimension= stoi(token);
    getline(lineStream, token, ' ');
    int query_num = stoi(token);
    vector<double*> query_points;
    while(getline(inFile, line2))
    {
    	// cout<<line2<<endl;
        double* single_line = (double*) calloc(query_num, sizeof(double));
        stringstream new_line(line2);
        // cout<<line2<<endl;
        string value;
        int ctr = 0;
        while(getline(new_line, value, ' '))
        {
        	// cout<<stod(value)<<endl;
            single_line[ctr] = stod(value);
            // cout<<single_line[ctr]<<endl;
            ctr++;
        }
        query_points.push_back(single_line);
    }
    // cout<<query_points.size()<<endl;
    return query_points;
    // return;
};

int main(int argc, char* argv[]) {
    char* dataset_file = argv[1];
    clock_t start;
    double duration;
    outfile.open("result.txt");
    mytree_root = read_file(dataset_file);
    // printTree(root);

	cout<<0<<endl;
    char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	// read_query_file(query_file,k);
    vector<double*> query_set = read_query_file(query_file);
    for (int i = 0; i < query_set.size(); ++i)
    {
    	point = query_set[i];
    	best_first(mytree_root,point,k);
        // seq_scan(mytree_root,point,k);
    	vector<double*> coord;
    	for (int j = 0; j < k; ++j){
	        Node* n = answer_set.top();
	        coord.push_back(&(n->coordinate[0]));
	        answer_set.pop();
	    }
	    for (int j = k-1; j > -1; j--){
		    for (int r = 0; r < dimension ; r++){
		        outfile<<coord[j][r]<<" ";
		    }
		    outfile<<endl;
		}
	    // cout<<answer_set.size()<<endl;
	    answer_set = priority_queue <Node*, vector<Node*>, myComparator_flipped>();
    }
    //cout<<duration<<endl;
    outfile.close();
    cout<<1<<endl;
    return 1;
}

