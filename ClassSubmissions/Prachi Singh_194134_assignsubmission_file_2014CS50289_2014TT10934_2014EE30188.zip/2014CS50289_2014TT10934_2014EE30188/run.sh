g++  -Ofast -o main kdtree.cpp
./main $1

