import sys
import pandas as pd
import numpy as np
import math

if __name__ == '__main__':

	dataset_file = sys.argv[1]

	def loadData(dataFileName):
		# print "loading data...."

		data = pd.read_csv(dataFileName,header=None,skiprows=[0],delim_whitespace=True).as_matrix()
		# query = pd.read_csv(queryFileName,header=None,skiprows=[0],delim_whitespace=True).as_matrix()

		# print "data loaded."
		return data

	class node:
		def __init__(self):
			self.point = None    #1Xn dimension array
			self.dimension = -1
			self.child = []
			self.parent = None
			self.max_region = None
			self.min_region = None
			
		def get_num_child(self):
			return len(self.child)
		
		def get_dimension(self):
			return self.dimension
		
		def get_value(self):
			return self.value
		
		def get_child_list(self):
			return self.child
		
		def get_parent(self):
			return self.parent
		
		def set_parent(self,p):
			self.parent = p
		
		def get_text(self):
			s = ''
			if(not np.all(self.point==None)):
				for v in self.point:
					s += str(v)[:4]+','
			return s+'('+str(self.dimension)+')'

	class kdtree:
		def __init__(self):
			self.root = None
			
		def get_root(self):
			return self.root
		
		def set_root(self,r):
			self.root = r

	def addToHeap(heap,dist,pt):
		try:
			heap[dist] += [pt]
		except:
			heap[dist] = [pt]

	def calc_dist(pt1,pt2):
		return math.sqrt(sum([((p1-p2)**2) for (p1,p2) in zip(pt1,pt2)]))

	def calc_dist_region(max_region,min_region,query):
		max_mask = query > max_region
		min_mask = query < min_region
		dist = sum((query[max_mask] - max_region[max_mask])**2) + sum((query[min_mask]-min_region[min_mask])**2)
		return math.sqrt(dist)

	def divideDataWithSort(data,splitOn):
		a = np.reshape(sorted(data, key=lambda d_entry: d_entry[splitOn]),(data.shape[0],data.shape[1]))
		index = a.shape[0]//2
		med_value = a[index][splitOn]
		data_1 = a[a[:,splitOn] < med_value]
		data_2 = a[a[:,splitOn] >= med_value]
		point = data_2[0]
		data_2= data_2[1:]
		return point,data_1,data_2

	def buildKDTree(n,data,parent,level=0):
		d = data.shape[1]
		count = data.shape[0]
		splitOn = level%d
		
		n.parent = parent
		
		if(count==1):
			n.point = data[0,:]
		
		elif(count==0):
			pass
		else:
			n1 = node()
			n2 = node()
			
			if(parent==None):
				n.max_region = np.zeros((data.shape[1],))+float("inf")
				n.min_region = np.zeros((data.shape[1],))-float("inf")
				
			else:
				n.max_region = parent.max_region.copy()
				n.min_region = parent.min_region.copy()
							
				if(n.parent.get_child_list().index(n)==1):
					n.min_region[parent.dimension] = parent.point[parent.dimension]
				else:
					n.max_region[parent.dimension] = parent.point[parent.dimension]
			
			n.dimension = splitOn

			point,data_1,data_2 = divideDataWithSort(data,splitOn)

			n.point = point

			n.child += [n1]
			n.child += [n2]

			buildKDTree(n1,data_1,n,level+1)
			buildKDTree(n2,data_2,n,level+1)

	def buildTree(data):
		# print "building tree of dimension: ",data.shape[1]
		# start3 = time.time()
		t = kdtree()
		root = node()
		buildKDTree(root,data,None)
		t.set_root(root)
		# print "time taken: ",time.time()-start3

		return t


	data = loadData(dataset_file)
	t = buildTree(data)
	# [TODO] Construct kdTree using dataset_file here

	# Request name/path of query_file from parent by just sending "0" on stdout
	sys.stdout.write('0\n')

	# Wait till the parent responds with name/path of query_file and k | Timer will start now
	query_file = input()
	k = int(input())


	query = loadData(query_file)

	def bestSearchKNN(sol_heap,mbr_heap,query,k):
	# global time1,time2,time3,time4
		# temp = time.time()
		min_mbr_dist = min(mbr_heap.keys())
		
		mbr = mbr_heap[min_mbr_dist].pop(0)
		# time1+=time.time()-temp
		
		if(len(mbr_heap[min_mbr_dist])==0):
			del mbr_heap[min_mbr_dist]

		if(len(sol_heap.keys())<k):
			addToHeap(sol_heap,calc_dist(mbr.point,query),tuple(mbr.point))
		
		else:
			# temp = time.time()

			dist_sol = max(sol_heap.keys())
			if(min_mbr_dist <= dist_sol):
				dist_mbr_pt = calc_dist(mbr.point,query)
				if(dist_mbr_pt < dist_sol):
					if(len(sol_heap[dist_sol])==1):
						del sol_heap[dist_sol]
					else:
						sol_heap[dist_sol] = sorted(sol_heap[dist_sol])[:-1]
					addToHeap(sol_heap,dist_mbr_pt,tuple(mbr.point))
				elif(dist_mbr_pt==dist_sol):
					sol_heap[dist_sol] += [tuple(mbr.point)]
					sol_heap[dist_sol] = sorted(sol_heap[dist_sol])[:-1]
			
			# time2 += time.time()-temp

		# temp = time.time()

		dist_sol = max(sol_heap.keys())
		child_list = mbr.get_child_list()
		
		# time3 += time.time()-temp
		
		# temp = time.time()
		
		for i in range(2):
			if(child_list[i].dimension!=-1):
				dist_reg_child0 = calc_dist_region(child_list[i].max_region,child_list[i].min_region,query)
				if(dist_reg_child0 <= dist_sol):
					addToHeap(mbr_heap,dist_reg_child0,child_list[i])
			elif(not np.all(child_list[i].point==None)):
				dist_mbr_child_pt = calc_dist(child_list[i].point,query)
				if(dist_mbr_child_pt < dist_sol):
					if(len(sol_heap[dist_sol])==1):
						del sol_heap[dist_sol]
					else:
						sol_heap[dist_sol] = sorted(sol_heap[dist_sol])[:-1]
					addToHeap(sol_heap,dist_mbr_child_pt,tuple(child_list[i].point))
					dist_sol = max(sol_heap.keys())
				elif(dist_mbr_child_pt==dist_sol):
					sol_heap[dist_sol] += [tuple(child_list[i].point)]
					sol_heap[dist_sol] = sorted(sol_heap[dist_sol])[:-1]
					dist_sol = max(sol_heap.keys())
				
				
				
		# time4 += time.time()-temp

	def callBestFirst(k,r,queryPts):
		result = []
		for i in queryPts:
			# print i
			sol_heap = {}
			mbr_heap = {}
			query = i
			dist_root = calc_dist_region(r.max_region,r.min_region,query)
			mbr_heap[dist_root] = [r]
			started = False
			while(len(mbr_heap.keys())!=0):
				if(not started):
					started = True
				else:
					if(min(mbr_heap.keys()) > max(sol_heap.keys())):
						break
				bestSearchKNN(sol_heap,mbr_heap,i,k)
			
			for ke in sol_heap.keys():
				sol_heap[ke] = sorted(sol_heap[ke])

			res = sorted(sol_heap.items(),key = lambda x: x[0])
			res1 = [e[1] for e in res]
			# res1 = sorted(res)
			result += [res1]

		# df = pd.DataFrame(np.array(result))
		# df.to_csv('results.txt',sep=' ',header=False,index=False)
		f = open('results.txt','w')
		for i in result:
			s = ''
			for j in i:
				for ki in j:
					for kj in ki:
						s+=str(kj)+' '
					s = s[:-1]
					s+='\n'
			f.write(s)

			# print sorted(sol_heap.keys())

	callBestFirst(k,t.get_root(),query)
	# [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

	# Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	sys.stdout.write('1\n')
