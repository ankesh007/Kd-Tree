#!/bin/bash
g++ -std=c++11 -O3 main.cpp bulkInput.cpp KDTree.cpp
./a.out $1
# python sample.py $1