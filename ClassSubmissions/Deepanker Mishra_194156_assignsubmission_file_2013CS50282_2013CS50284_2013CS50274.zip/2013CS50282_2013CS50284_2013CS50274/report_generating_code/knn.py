import sys
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neighbors import NearestNeighbors
from sklearn.neighbors import KDTree
import numpy as np
import time

def knn(filename, k):
	points = []
	with open(filename,'r') as file:
		d,n = (file.readline()).strip().split()
		for i in range(int(n)):
			points.append(list(map(float,file.readline().strip().split())))
		# print(points)
	# nbrs = NearestNeighbors(n_neighbors=k, algorithm='kd_tree').fit(points)
	# print(nbrs)
	kdt = KDTree(points, metric='euclidean')
	start_time = time.clock()
	x = kdt.query([[0.65,0.06,0.5342651142202411,0.82,0.9,0.65,0.06,0.5342651142202411,0.82,0.9,0.65,0.06,0.5342651142202411,0.82,0.9,0.65,0.06,0.5342651142202411,0.82,0.9]], k=k, return_distance=False)
	print("--- %s seconds ---" % (time.clock() - start_time))
	for i in x:
		for j in i:
			print(points[j])

knn(sys.argv[1], int(sys.argv[2]))