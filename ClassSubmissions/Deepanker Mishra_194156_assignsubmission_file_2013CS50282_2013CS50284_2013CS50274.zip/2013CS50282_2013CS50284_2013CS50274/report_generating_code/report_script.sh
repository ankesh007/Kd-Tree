#!/bin/bash
python3 parent.py data2.txt query2.txt 20 >> testing_kd.txt
python3 parent.py data3.txt query3.txt 20 >> testing_kd.txt
python3 parent.py data5.txt query5.txt 20 >> testing_kd.txt
python3 parent.py data10.txt query10.txt 20 >> testing_kd.txt
python3 parent.py data15.txt query15.txt 20 >> testing_kd.txt
python3 parent.py data20.txt query20.txt 20 >> testing_kd.txt