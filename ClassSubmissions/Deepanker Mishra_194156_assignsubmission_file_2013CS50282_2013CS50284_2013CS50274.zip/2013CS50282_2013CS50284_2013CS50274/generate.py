import random
import sys

def write_random(d,n, filename):
	with open(filename,"w") as file:
		file.write(str(d))
		file.write(' ')
		file.write(str(n))
		file.write('\n')
		for i in range(n):
			for j in range(d):
				file.write(str(random.uniform(0, 1)))
				file.write(' ')
			file.write('\n')

write_random(int(sys.argv[1]), int(sys.argv[2]), sys.argv[3])