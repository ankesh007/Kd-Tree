#!/bin/bash
# g++ -O3 main.cpp bulkInput.cpp KDTree.cpp bulkInput.hpp KDTree.hpp
g++ -O3 sequential.cpp
./a.out $1
# python sample.py $1