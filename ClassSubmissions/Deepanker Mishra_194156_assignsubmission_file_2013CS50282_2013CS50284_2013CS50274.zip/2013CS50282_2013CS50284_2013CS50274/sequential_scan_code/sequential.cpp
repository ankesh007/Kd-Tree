//
//  main.cpp
//  KDtree
//
//  Created by Deepanker Mishra on 24/03/18.
//  Copyright © 2018 Deepanker Mishra. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
#include <cmath>
#include <cassert>
#include <ctime>
#include <algorithm>
#include <fstream>

using namespace std;

typedef std::vector<double> Point;

typedef pair<double, Point> pointInfo; // l2 distance from query, pointer to the node

struct mincomp{
    bool operator()(const pointInfo& i, const pointInfo& j){
        return i.first > j.first;
    }
};

struct maxcomp{
    bool operator()(const pointInfo& i, const pointInfo& j){
        if(i.first != j.first)
            return i.first < j.first;
        else{
            for(int a=0;a<i.second.size();a++){
                if((i.second)[a] != (j.second)[a])
                    return (i.second)[a] < (j.second)[a];
            }
        }
    }
};


typedef priority_queue<pointInfo, vector<pointInfo >, mincomp > MinHeap;
typedef priority_queue<pointInfo, vector<pointInfo >, maxcomp > MaxHeap;

void printPoint(const Point p){
    cout<<"(";
    int i=0;
    for(;i< p.size()-1;i++){
        cout<< p[i]<<" ";
    }
    cout<< p[i] <<")"<<endl;
}

// not used
double l2(const Point& p1, const Point& p2){
    double d = 0;
    for(int i=0; i<p1.size(); i++){
        d += (p1[i]-p2[i])*(p1[i]-p2[i]);
    }
    return (d); // optional for speed up
}

bool leq(const Point& i, const Point& j){
    for(int a=0;a<i.size();a++){
        if(i[a] != j[a])
            return i[a] < j[a];
    }
    return false;
}


vector<Point> seq(const vector<Point> all, const Point& q, const int k){
    MaxHeap bestk;  // heap for tranversal
    pointInfo temp;
    double dist;
    for(int i=0;i<all.size();i++){
        dist = l2(all[i],q);
        if(bestk.size() < k){
            temp.first = dist;
            temp.second = all[i];
            bestk.push(temp);
        }
        else{
            if(dist < bestk.top().first || (dist == bestk.top().first && leq(all[i],bestk.top().second))){
                bestk.pop();
                temp.first = dist;
                temp.second = all[i];
                bestk.push(temp);
            }
            else{
                continue;
            }
        }
    }
    vector<Point> answer;
    while(!bestk.empty()){
        answer.push_back(bestk.top().second);
        // printPoint(bestk.top().second);
        bestk.pop();
    }
    std::reverse(answer.begin(),answer.end());
    return answer;

}



int main(int argc, const char * argv[]) {
    
    ifstream fin(argv[1]);
    int dim, numlines, i;
    double dub;
    fin >> dim >> numlines;
    vector<Point> allPoints;
    while(numlines--){
        i=dim;
        Point inp;    
        while(i--){
            fin >> dub;
            inp.push_back(dub);
        }
        allPoints.push_back(inp);
    }

    cout << 0 << endl;

    char* query_file = new char[100];
    int k;
    cin >> query_file >> k;

    ifstream fin2(query_file);
    fin2 >> dim >> numlines;
    vector<Point> query;
    while(numlines--){
        i=dim;
        Point inp;    
        while(i--){
            fin2 >> dub;
            inp.push_back(dub);
        }
        query.push_back(inp);
    }

    for(int i=0;i<query.size();i++)
        seq(allPoints, query[i], k);

    cout << 1 << endl;
//     static const double arr[] = {0.65,0.06,0.5342651142202411,0.82,0.9,0.65,0.06,0.5342651142202411,0.82,0.9,0.65,0.06,0.5342651142202411,0.82,0.9,0.65,0.06,0.5342651142202411,0.82,0.9};
//     Point q (arr, arr + sizeof(arr) / sizeof(arr[0]));
// //    q.push_back(0.5); q.push_back(0.5); q.push_back(0.5); q.push_back(0.5);
//    clock_t t;
//    t = clock();
//    seq(allPoints, q, 20);
//    cout << "\n" << (float)(clock() - t) / CLOCKS_PER_SEC;
    return 0;
}
