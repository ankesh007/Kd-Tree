#!/bin/bash
g++ code.cpp -o exec -O3 -std=c++11  ;./exec $1
