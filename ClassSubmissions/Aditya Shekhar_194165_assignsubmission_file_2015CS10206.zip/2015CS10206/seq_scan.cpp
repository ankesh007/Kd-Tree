#include <iostream>
#include <string>
#include <vector>
#include <random>
#include <limits.h>
#include <algorithm>
#include <queue>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
double min_euclidean_dist(vector<double > dimen, vector< double > point)
{
	double dist =0.0;
	for(int i=0;i<dimen.size();i++)
	{

		dist += (dimen[i]-point[i])*(dimen[i]-point[i]);
	}
	dist = sqrt(dist);
	return dist;
}
class your_comparator
{
public:
	int operator()(const pair<double,vector<double > > &p1,const pair<double,vector<double >> &p2)
	{
		if(p1.first == p2.first)
		{
			for(int i=0;i<p1.second.size();i++)
			{
				if(p1.second[i]<p2.second[i])
				{
					return 1;
				}
				else if(p1.second[i]>p2.second[i])
				{
					return 0;
				}
			}
		}
		return p1.first < p2.first;	
	}
};
bool lexi(vector<double> vec1,vector<double> vec2)
{
	for(int i =0;i<vec1.size();i++)
	{
		if(vec1[i] < vec2[i])
		{
			return true;
		}
		else if(vec1[i] > vec2[i])
		{
			return false;
		}
	}
	return false;
}
priority_queue< pair<double,vector<double> >, vector<pair<double,vector<double>>>, your_comparator> seq_scan(vector< vector<double> >data_set,vector<double> q_point, int k)
{
	priority_queue< pair<double,vector<double>>, vector<pair<double,vector<double>>>, your_comparator> ans_set;
	for(int i=0;i<data_set.size();i++)
	{
		double dist = min_euclidean_dist(data_set[i],q_point);
		if(ans_set.size() < k)
		{
			ans_set.push(make_pair(dist,data_set[i]));
		}
		else
		{
			pair<double, vector<double >> tempi = ans_set.top();
			if(tempi.first > dist)
			{
				ans_set.pop();
				ans_set.push(make_pair(dist,data_set[i]));
			}
			else if(tempi.first == dist)
			{
				if(lexi(data_set[i],q_point))
				{
					ans_set.pop();
					ans_set.push(make_pair(dist,data_set[i]));
				}
			}
		}
	}
	return ans_set;
}
int main(int argc,char* argv[])
{
	int n,d;
	string data_set = string(argv[1]);
	ifstream myfile;
	myfile.open(&data_set[0]);
	myfile>>d>>n;
	vector< vector <double > > data_vec;
	for(int i=0;i<n;i++)
	{
		vector<double > temp1;
		for(int j=0;j<d;j++)
		{
			double ne;
			myfile>>ne;
			temp1.push_back(ne);
		}
		data_vec.push_back(temp1);
	}
	myfile.close();
	// vector< vector < vector < double > > > forsorting = sorted(data_vec,d,n);
	// data_vec.clear();
	// node *root = grow_tree(forsorting,n,d);		
	string query_fname;
	int k_nn;
	cout<<0<<endl;
	cin>>query_fname;
	cin>>k_nn;
	vector< vector<double > > query_points;
	ifstream nfile;
	nfile.open(&query_fname[0]);
	int q_n,q_d;
	nfile>>q_d>>q_n;
	// cout<<q_n<<endl;
	for(int i=0;i<q_n;i++)
	{
		vector<double> temp2;
		for(int j=0;j<q_d;j++)
		{
			double pe;
			nfile>>pe;
			temp2.push_back(pe);
		}
		query_points.push_back(temp2);
	}
	nfile.close();
	ofstream yfile;
	yfile.open("resultsseq.txt");
	for(int i=0;i<q_n;i++)
	{

		priority_queue< pair<double,vector<double>>, vector<pair<double,vector<double>>>, your_comparator > ans_set = seq_scan(data_vec,query_points[i],k_nn);
		// cout<<ans_set.size()<<endl;
		vector< vector< double > > ret_vec;	
		while(!ans_set.empty())
		{
			vector< double > temp = ans_set.top().second;
			ans_set.pop();
			ret_vec.push_back(temp);	
		}
		for(int j = ret_vec.size()-1;j>=0;j--)
		{
			for(int k =0;k<ret_vec[j].size();k++)
			{
				yfile<<ret_vec[j][k]<<" ";				
			}
			yfile<<endl;
		}	
	}
	cout<<1<<endl;	
}


