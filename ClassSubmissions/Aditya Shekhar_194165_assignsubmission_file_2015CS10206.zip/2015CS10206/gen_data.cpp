#include <iostream>
#include <string>
#include <vector>
#include <random>
#include <limits.h>
#include <algorithm>
#include <queue>
#include <fstream>
using namespace std;
vector< vector<double> > generate_point(int n, int d)
{
	vector< vector<double > > points(n);
	for(int i=0;i<n;i++)
	{
		vector<double> vec(d);
		for(int j=0;j<d;j++)
		{
			vec[j] =((double)rand()/(RAND_MAX));
		}
		points[i] = vec;
	}
	return points;
}
int main(int argc,char* argv[])
{
	int n = int(atoi(argv[2]));
	int d = int(atoi(argv[1]));
	vector<vector<double>> points = generate_point(n,d);
	string output = string(argv[3]);
	ofstream myfile;
	myfile.open(&output[0]);
	myfile<<d<<" ";
	myfile<<n<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j= 0;j<d;j++)
		{
			myfile<<points[i][j]<<" ";
		}
		myfile<<endl;
	}
	myfile.close();
}