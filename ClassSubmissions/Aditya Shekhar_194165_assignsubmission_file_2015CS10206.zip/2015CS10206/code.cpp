#include <iostream>
#include <string>
#include <vector>
#include <random>
#include <limits.h>
#include <algorithm>
#include <queue>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
int chan;
// class for k-d tree


class node
{
public:
	int data;
	vector< double > MBR_max;
	vector< double > MBR_min;
	vector< double > dimen;
	node *right,*left;
};

// functions 
// Maximum ddistance of point P to MBR r
vector< double > max_dist_MBR(vector<double > MBR_min,vector<double > MBR_max,vector<double> point)
{
	int n = MBR_min.size();
	vector<double> max_dist(n);
	for(int i=0;i<n;i++)
	{
		max_dist[i] = (double)(max(abs(MBR_min[i] - point[i]),abs(point[i] - MBR_max[i])));
	}
	return max_dist;
}
// Minimum distance of point P to MBR r
inline void min_dist_MBR(vector<double > &MBR_min,vector<double > &MBR_max,vector< double > &point, vector<double> &min_dist)
{
	int n = MBR_min.size();
	for(int i=0;i<n;i++)
	{
		if(point[i]<MBR_min[i])
		{
			min_dist[i] = MBR_min[i] - point[i];
		}
		else if (point[i]>MBR_max[i])
		{
			min_dist[i] = point[i] - MBR_max[i];
		}
		else
		{
			min_dist[i] = 0.0;
		}
	}
	return;
}
// MBR functions for calculations
inline double min_euclidean_dist(vector<double > &MBR_min,vector<double > &MBR_max , vector< double > &point)
{
	vector< double > min_dist((int)(MBR_min.size()));
	min_dist_MBR(MBR_min,MBR_max,point,min_dist);
	double dist =0.0;
	// cout<<min_dist[0]<<" "<<min_dist[1]<<" "<<MBR_min[0]<<" "<<MBR_min[1]<<" "<<MBR_max[0]<<" "<<MBR_max[1]<<endl;
	for(int i=0;i<min_dist.size();i++)
	{

		dist += (min_dist[i]*min_dist[i]);
	}
	// cout<<dist<<"---------"<<endl;
	dist = sqrt(dist);
	// cout<<dist<<endl;
	return dist;
}
double max_euclidean_dist(vector<double > MBR_min,vector<double > MBR_max,vector< double > point)
{
	vector< double > max_dist = max_dist_MBR(MBR_min,MBR_max,point);
	double dist =0;
	for(int i=0;i<max_dist.size();i++)
	{
		dist += max_dist[i]*max_dist[i];
	}
	dist = sqrt(dist);
	return dist;
}

// comparator for  priority queue
class my_comparator
{
public:
	int operator()(const pair<double,node*> &p1,const pair<double,node*> &p2)
	{
		return p1.first > p2.first;
	}
};

// comparator for priority queue
class your_comparator
{
public:
	int operator()(const pair<double,node*> &p1,const pair<double,node*> &p2)
	{
		if(p1.first==p2.first)
		{
			for(int i=0;i<p1.second->dimen.size();i++)
			{
				if(p1.second->dimen[i]<p2.second->dimen[i])
				{
					return 1;
				}
				else if(p1.second->dimen[i]>p2.second->dimen[i])
				{
					return 0;
				}
			}
		}
		return p1.first < p2.first;	
	}
}; 

bool lexi(vector<double> vec1,vector<double> vec2)
{
	for(int i =0;i<vec1.size();i++)
	{
		if(vec1[i] < vec2[i])
		{
			return true;
		}
		else if(vec1[i] > vec2[i])
		{
			return false;
		}
	}
	return false;
}
// function for searching the nearest neighbours
void nearest_neighbour_k(node *root,int k,vector< double > q_point, priority_queue< pair<double,node*>, vector<pair<double,node*>>, your_comparator> &ans_set )
{
	priority_queue< pair<double,node*>, vector<pair<double,node*>>, my_comparator> min_heap;
	double dist = min_euclidean_dist(root->MBR_min,root->MBR_max,q_point);
	min_heap.push(make_pair(dist,root));
	while(true)
	{

		if(min_heap.empty())
		{
			break;
		}
		pair <double ,node*> point = min_heap.top();
		min_heap.pop();
		if(ans_set.size() == k )
		{
			double temp_dist = ans_set.top().first;
			if(temp_dist < point.first)
				break;
		}
		if(point.second->left != NULL && point.second->right != NULL )
		{
			double dist1 = min_euclidean_dist(point.second->left->MBR_min,point.second->left->MBR_max,q_point);
			double dist2 = min_euclidean_dist(point.second->right->MBR_min,point.second->right->MBR_max,q_point);
			if(ans_set.size()<k)
			{
				min_heap.push(make_pair(dist1,point.second->left));
				min_heap.push(make_pair(dist2,point.second->right));	
			}
			else
			{ 
				double temp_dist = ans_set.top().first;
				if(temp_dist >= dist1)	
				{
					min_heap.push(make_pair(dist1,point.second->left));
				}
				if(temp_dist >= dist2)
				{
					min_heap.push(make_pair(dist2,point.second->right));
				}
			}		
		}
		else if(point.second->left == NULL && point.second->right == NULL)
		{

			if(ans_set.size()<k)
			{
				ans_set.push(point);	
			}
			else
			{
				double temp_dist = ans_set.top().first;
				vector< double > arr = ans_set.top().second->dimen;
				if(temp_dist > point.first)
				{
					ans_set.pop();
					ans_set.push(point);
				}
				else if(temp_dist == point.first)
				{

					if(lexi(point.second->dimen,arr))
					{
						ans_set.pop();
						ans_set.push(point);
					}
				}
			}
		}
	}
	return;
}

// function for grow_tree_util
node* grow_tree_util(vector< vector< vector< double > > > &forsorting, int d, int depth)
{
	if(forsorting[0].size() == 1)
	{
		node *root= new node();
		root->right = NULL;
		root->left = NULL;
		root->dimen = forsorting[0][0];
		root->MBR_min = forsorting[0][0];
		root->MBR_max = forsorting[0][0];
		return root;
	}
	int dim = depth % d;
	int cur_len = forsorting[0].size();
	int new_cur_len = cur_len/2; 
	vector< vector<vector< double > > > new_forsort1(d);
	vector<vector< vector< double > > > new_forsort2(d);
	node* root = new node();
	vector< double > tempmax(d);
	vector< double > tempmin(d);
	for(int i=0;i<d;i++)
	{
		tempmax[i] = forsorting[i][cur_len-1][i];
		tempmin[i] = forsorting[i][0][i];
	}
	root->MBR_min = tempmin;
	root->MBR_max = tempmax;
	if(cur_len%2 == 0)
	{
		vector< double > distin = forsorting[dim][new_cur_len];
		for(int i=0;i<d;i++)
		{
			vector<vector<double >>	new_temp1(new_cur_len);
			vector<vector<double >>	new_temp2(new_cur_len);
			int t1=0;
			int t2=0;
			for(int j=0;j<cur_len;j++)
			{
				for(int k = 0;k<d;k++)
				{
					if(forsorting[i][j][(dim+k)%d] < distin[(dim+k)%d])
					{
						new_temp1[t1] = forsorting[i][j];
						t1++;
						break;
					}
					else if(forsorting[i][j][(dim+k)%d] > distin[(dim+k)%d])
					{
						new_temp2[t2] = forsorting[i][j];
						t2++;
						break;
					}
					else
					{
						if(k==d-1)
						{
							new_temp2[t2] = forsorting[i][j];
							t2++;
							break;		
						}
					}
				}
			}

			new_forsort1[i]= new_temp1;
			new_forsort2[i]= new_temp2;
		}
	}
	else
	{
		vector< double > distin = forsorting[dim][new_cur_len];
		for(int i=0;i<d;i++)
		{
			vector<vector<double >>	new_temp1(new_cur_len);
			vector<vector<double >>	new_temp2(new_cur_len+1);
			int t1=0;
			int t2=0;
			for(int j=0;j<cur_len;j++)
			{
				for(int k = 0;k<d;k++)
				{
					if(forsorting[i][j][(dim+k)%d] < distin[(dim+k)%d])
					{
						new_temp1[t1] = forsorting[i][j];
						t1++;
						break;
					}
					else if(forsorting[i][j][(dim+k)%d] > distin[(dim+k)%d])
					{
						new_temp2[t2] = forsorting[i][j];
						t2++;
						break;
					}
					else
					{
						if(k==d-1)
						{
							new_temp2[t2] = forsorting[i][j];
							t2++;
							break;		
						}
					}
				}
			}
			new_forsort1[i] = new_temp1;
			new_forsort2[i] = new_temp2;
		}
	}
	root->left = grow_tree_util(new_forsort1,d,depth+1);
	root->right = grow_tree_util(new_forsort2,d,depth+1);
	return root; 
}

// function for growing tree 
node* grow_tree(vector< vector < vector< double > > > forsorting , int n, int d)
{
	int depth = 0;
	node* root; 
	root = grow_tree_util(forsorting,d,depth);
	return root;
}

// function for generating random points

vector<vector < double > > generatepoints(int d, int n)
{
	vector<vector< double > > temp(n);
	for(int i = 0 ;i < n;i++)
	{
		vector<double> temp1(d);
		for(int j=0;j<d;j++)
		{
			double db = (double)rand()/RAND_MAX;
			temp1[j] = db;
		}
		temp[i] = temp1;
	}
	return temp;
}

// temporary function for sorting 
int dime = 0;
bool sortcol(const vector< double > &v1,const vector< double > &v2)
{
	int k = 0;
	for(int k = 0;k<dime;k++)
	{
		if(v1[(chan+k)%dime]!=v2[(chan+k)%dime])
		{
			return v1[(chan+k)%dime]<v2[(chan+k)%dime];
		}
	}
	return v1[chan]<v2[chan];
}

// function for inorder traversal

void inorder_traversal(node *root)
{
	if(root->left == NULL && root->right == NULL)
	{
		vector< double > temp = root->dimen;
		for(int i=0;i<temp.size();i++)
		{
			cout<<temp[i]<<" ";
		}
		cout<<endl;
		return;
	}
	inorder_traversal(root->left);
	inorder_traversal(root->right);

} 

// function for generating sorted vector

vector< vector < vector < double > > > sorted(vector< vector < double > > temp, int d, int n)
{
	vector< vector< vector< double > > > forsorting(d);
	for(int i=0;i<d;i++)
	{
		vector< vector< double > > forsort = temp;
		forsorting[i] = forsort;
	}
	for(int i=0;i<d;i++)
	{
		chan = i;
		dime = d;
		sort(forsorting[i].begin(),forsorting[i].end(),sortcol);
	}
	return forsorting;
}

int main(int argc,char* argv[])
{
	int n,d;

	string data_set = string(argv[1]);
	ifstream myfile;
	myfile.open(&data_set[0]);
	myfile>>d>>n;
	vector< vector <double > > data_vec;
	for(int i=0;i<n;i++)
	{
		vector<double > temp1;
		for(int j=0;j<d;j++)
		{
			double ne;
			myfile>>ne;
			temp1.push_back(ne);
		}
		data_vec.push_back(temp1);
	}
	myfile.close();
	vector< vector < vector < double > > > forsorting = sorted(data_vec,d,n);
	data_vec.clear();
	node *root = grow_tree(forsorting,n,d);		
	string query_fname;
	int k_nn;
	cout<<0<<endl;
	cin>>query_fname;
	cin>>k_nn;
	vector< vector<double > > query_points;
	ifstream nfile;
	nfile.open(&query_fname[0]);
	int q_n,q_d;
	nfile>>q_d>>q_n;
	for(int i=0;i<q_n;i++)
	{
		vector<double> temp2;
		for(int j=0;j<q_d;j++)
		{
			double pe;
			nfile>>pe;
			temp2.push_back(pe);
		}
		query_points.push_back(temp2);
	}
	nfile.close();
	ofstream yfile;
	ofstream lfile;
	yfile.open("results.txt");
	// lfile.open("avg_dist.txt");
	double total_dist_100 = 0.0;
	double total_dist_2 = 0.0;
	for(int i=0;i<q_n;i++)
	{
		priority_queue< pair<double,node*>, vector<pair<double,node*>>, your_comparator > ans_set;
		nearest_neighbour_k(root,k_nn,query_points[i],ans_set);
		vector< vector< double > > ret_vec;	
		vector< double > ret_dist;
		while(!ans_set.empty())
		{
			vector< double > temp = ans_set.top().second->dimen;
			double val = ans_set.top().first;
			ans_set.pop();
			ret_vec.push_back(temp);	
			ret_dist.push_back(val);
		}
		for(int j = ret_vec.size()-1;j>=0;j--)
		{	
			if(j==0)
			{
				total_dist_100 += ret_dist[j];
			}
			else if(j == ret_vec.size()-2)
			{
				total_dist_2 += ret_dist[j];
			}
			for(int k =0;k<ret_vec[j].size();k++)
			{
				yfile<<ret_vec[j][k]<<" ";				
			}
			yfile<<endl;
		}	
	}
	double ppp = (double)total_dist_2/total_dist_100;
	// lfile<<ppp<<endl;
	yfile.close();
	// lfile.close();
	cout<<1<<endl;
}