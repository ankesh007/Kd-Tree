#!/bin/bash

g++ -std=c++11 -O3 -o kdtree main.cpp
./kdtree $1