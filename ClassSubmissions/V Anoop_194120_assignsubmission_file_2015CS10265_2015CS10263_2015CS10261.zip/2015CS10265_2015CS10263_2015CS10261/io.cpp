#include "vars.h"

point* read_points(char* fname,int &d,int &n){
    ifstream in(fname);
    stringstream ss;
    string line,temp;
    getline(in,line);
    ss.str(line);
    ss >> temp; d = stoi(temp);
    ss >> temp; n = stoi(temp);
    point* pts = (point*)malloc(n*sizeof(point));
    for(int i=0;i<n;i++){
        stringstream ss;
        getline(in,line);
        ss.str(line);
        for(int j=0;j<d;j++){
            ss >> temp; pts[i].x[j] = (double)stof(temp);
        }
    }
    in.close();
    return pts;
}

void write_points(heap** answers,int queries,int dim,int k){
    ofstream out("results.txt");
    out.precision(4);
    KD_node** nodes = (KD_node**)malloc(k*sizeof(KD_node*));
    for(int i=0;i<queries;i++){
        heap* ans = answers[i];
        for(int j=0;j<k;j++){
            nodes[j] = ans->top();
            ans->pop();
        }
		for(int j=k-1;j>=0;j--){
			for(int idx=0;idx<dim;idx++){
                if(idx != dim-1){
					out << nodes[j]->x->x[idx] << " ";
				}
				else{
					out << nodes[j]->x->x[idx];
				}
            }
            if(!(i == queries-1 && j == 0)){
				out << endl;
			}
		}
    }
    out.close();
}