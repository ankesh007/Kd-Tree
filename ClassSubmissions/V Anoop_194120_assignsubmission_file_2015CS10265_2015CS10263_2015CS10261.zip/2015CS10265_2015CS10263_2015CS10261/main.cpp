#include "vars.h"
#include "io.cpp"
#include "graph_a.cpp"

int main(int argc, char* argv[]) {
	char* dataset_file = argv[1];

	int d,n;
	point* pts = read_points(dataset_file,d,n);
	KD_node* root = make_tree(pts,n,0,d);

	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	int q;
	point* qs = read_points(query_file,d,q);

	ofstream out("results.txt");
    out.precision(7);
	KD_node** nodes = (KD_node**)malloc(k*sizeof(KD_node*));
	heap ans;
	for(int i=0;i<q;i++){
		heap cand;
		cand.push(root);
		kNN(&ans,&cand,&qs[i],d,k);
		for(int j=0;j<k;j++){
            nodes[j] = ans.top();
            ans.pop();
        }
		for(int j=k-1;j>=0;j--){
			for(int idx=0;idx<d;idx++){
                if(idx != d-1){
					out << nodes[j]->x->x[idx] << " ";
				}
				else{
					out << nodes[j]->x->x[idx];
				}
            }
            if(!(i == q-1 && j == 0)){
				out << endl;
			}
		}
	}
	out.close();
	// cerr << "kNN done" << endl;

	// class KD_node *data1 = (class KD_node *)calloc(n, sizeof(class KD_node));
	// for (int i = 0; i < n; i++)
	// 	data1[i].x = &pts[i];

	// for (int i = 0; i < q; i++){
	// 	seq_scan(data1, n, &qs[i], d, k);
	// }

	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
}
