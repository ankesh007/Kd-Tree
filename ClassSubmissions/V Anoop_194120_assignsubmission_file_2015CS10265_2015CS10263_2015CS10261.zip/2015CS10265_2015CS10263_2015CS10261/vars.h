#ifndef FILE_H
#define FILE_H

#include <bits/stdc++.h>
#include <ctime>
#include <cmath>
using namespace std;

#define MAX_DIMENSION 20

class point{
public:
    double x[MAX_DIMENSION];
};

class KD_node{
public:
    point *x;
    point *r_min;
    point *r_max;
    KD_node *left, *right;
    double dist;
    int length;

    KD_node(point *a){
        x = (point*)malloc(sizeof(point));
        memcpy(x->x, a->x, sizeof(x->x));
    }

    KD_node(int size){
        x = (point*)malloc(sizeof(point));
        r_min = (point*)malloc(sizeof(point));
        r_max = (point*)malloc(sizeof(point));
    }
};

struct OrderByDist{
    bool operator()(KD_node *const &a, KD_node *const &b){
        if(a->dist != b->dist)
            return a->dist < b->dist;
        
        for(int i = 0;i < MAX_DIMENSION;i++){
            if(a->x->x[i] < b->x->x[i])
                return true;
            if(a->x->x[i] > b->x->x[i])
                return false;
        }   
        return false;
    }
};

typedef priority_queue<KD_node *, vector<KD_node *>, OrderByDist> heap;

#endif