#include "vars.h"
#include <ctime>
#include <cmath>

void
print_point(point *t, int dim)
{
    for (int i = 0; i < dim; i++)
        cerr << t->x[i] << " ";
    cerr << endl;
}

inline double
dist(class point *a, class point *b, int dim)
{
    double t, d = 0;
    for (int i = 0; i < dim; i++)
    {
        t = a->x[i] - b->x[i];
        d += t * t;
    }
    return d;
}

inline void
swap(class point *x, class point *y)
{
    double temp[MAX_DIMENSION];
    memcpy(temp, x->x, sizeof(temp));
    memcpy(x->x, y->x, sizeof(temp));
    memcpy(y->x, temp, sizeof(temp));
}

class point *
find_median(class point *start, class point *end, int idx)
{
    if (end <= start)
        return NULL;
    if (end == start + 1)
        return start;

    class point *p, *store, *md = start + (end - start) / 2;
    double pivot;

    while (true)
    {
        pivot = md->x[idx];

        swap(md, end - 1);

        for (store = p = start; p < end; p++)
        {
            if (p->x[idx] < pivot)
            {
                if (p != store)
                    swap(p, store);
                store++;
            }
        }
        swap(store, end - 1);

        if (store->x[idx] == md->x[idx])
            return md;

        if (store > md)
            end = store;
        else
            start = store;
    }
}

inline double
minimum(point *r_min, point *r_max, point *query, int dim)
{
    double res = 0.0;
    for (int i = 0; i < dim; i++)
    {
        if (query->x[i] > r_max->x[i])
            res += (query->x[i] - r_max->x[i]) * (query->x[i] - r_max->x[i]);
        else if (query->x[i] < r_min->x[i])
            res += (query->x[i] - r_min->x[i]) * (query->x[i] - r_min->x[i]);
    }

    return res;
}

int 
check_dim(point *a, point *b, int dim){
    for(int i = 0;i < dim;i++){
        if(a->x[i] < b->x[i])
            return 1;
        if(a->x[i] > b->x[i])
            return 0;
    }   
    return 0;
}

void
kNN(heap *ans, heap *candidate, point *query, int dim, int k)
{
    if (candidate->size() == 0)
        return;

    KD_node *top_cand = candidate->top();
    candidate->pop();
    
    double dist_cand = top_cand->dist;
    double dist_ans;

    if (ans->size() < k)
    {
        KD_node *temp = new KD_node(top_cand->x);
        temp->dist = dist(top_cand->x, query, dim);
        ans->push(temp);
        if (top_cand->left != NULL)
        {
            top_cand->left->dist = minimum(top_cand->left->r_min, top_cand->left->r_max, query, dim);
            candidate->push(top_cand->left);
        }
        if (top_cand->right != NULL)
        {
            top_cand->right->dist = minimum(top_cand->right->r_min, top_cand->right->r_max, query, dim);
            candidate->push(top_cand->right);
        }
    }
    else
    {
        KD_node *top_ans = ans->top();
        dist_ans = top_ans->dist;
        if (dist_ans < dist_cand)
        {
            kNN(ans, candidate, query, dim, k);
            return;
        }

        KD_node *temp = new KD_node(top_cand->x);
        temp->dist = dist(top_cand->x, query, dim);
        if (dist_ans >= temp->dist)
        {
            if(dist_ans != temp->dist || check_dim(temp->x, ans->top()->x,dim) == 1){
                ans->pop();
                ans->push(temp);
            }
        }

        if (top_cand->left != NULL)
        {
            top_cand->left->dist = minimum(top_cand->left->r_min, top_cand->left->r_max, query, dim);
            if (top_cand->left->dist <= dist_ans)
                candidate->push(top_cand->left);
        }
        if (top_cand->right != NULL)
        {
            top_cand->right->dist = minimum(top_cand->right->r_min, top_cand->right->r_max, query, dim);
            if (top_cand->right->dist <= dist_ans)
                candidate->push(top_cand->right);
        }
    }
    kNN(ans, candidate, query, dim, k);
}

class KD_node *
make_tree(class point *t, int len, int idx, int dim)
{
    if (!len)
        return NULL;

    class KD_node *n = new KD_node(len);
    class point *p;

    memcpy(n->r_min->x, t[0].x, sizeof(n->r_min->x));
    memcpy(n->r_max->x, t[0].x, sizeof(n->r_max->x));
    n->length = len;

    for (int j = 1; j < len; j++)
    {
        for (int k = 0; k < dim; k++)
        {
            if (n->r_min->x[k] > t[j].x[k])
                n->r_min->x[k] = t[j].x[k];
            if (n->r_max->x[k] < t[j].x[k])
                n->r_max->x[k] = t[j].x[k];
        }
    }

    p = find_median(t, t + len, idx);
    memcpy(n->x->x, p->x, sizeof(n->x->x));
    idx = (idx + 1) % dim;
    n->left = make_tree(t, p - t, idx, dim);
    n->right = make_tree(p + 1, t + len - (p + 1), idx, dim);

    return n;
}

pair<float, float>
seq_scan(class KD_node *data, int N, class point *query, int dim, int k)
{
    heap h1;

    for (int i = 0; i < N; i++)
    {
        double d = dist(query, data[i].x, dim);
        data[i].dist = d;

        if (h1.size() < k)
            h1.push(&data[i]);
        else
            if (h1.top()->dist > d)
            {
                h1.pop();
                h1.push(&data[i]);
            }
    }
    float res2, res100;
    for (int i = 0; i < k; i++)
    {
        if(i == 0){
            res100 =  sqrt(dist(query, h1.top()->x, dim));
            // print_point(h1.top()->x, dim);
        }
        if(i == k-2){
            res2 =  sqrt(dist(query, h1.top()->x, dim));
            // print_point(h1.top()->x, dim);
        }
        print_point(h1.top()->x,dim);
        h1.pop();
    }
    return make_pair(res2, res100);
}

void
rand_pt(point *v, int dim)
{
    for (int i = 0; i < dim; i++)
        v->x[i] = rand() / (double)RAND_MAX;
}

void
print(KD_node *root,int dim)
{
    if (root == NULL)
        return;

    print_point(root->x,dim);
    print(root->left,dim);
    print(root->right,dim);
}

void deallocate(KD_node *node)
{
    //do nothing if passed a non-existent node
    if (node == NULL)
        return;

    //now onto the recursion
    deallocate(node->left);
    deallocate(node->right);

    free(node->r_max);
    free(node->r_min);
    free(node->x);
}

// int main(void)
// {
//     int N = 100000;
//     int DIM = 20;
//     int dim[6] = {2, 3, 5, 10, 15, 20};
//     int k = 20;
//     int sets = 100;

//     class point *data = (class point *)calloc(N, sizeof(class point));

//     srand(time(0));
//     // Generate 20D data
//     for (int i = 0; i < N; i++)
//         rand_pt(&data[i], DIM);
//     class KD_node *data1 = (class KD_node *)calloc(N, sizeof(class KD_node));
//     for (int i = 0; i < N; i++)
//         data1[i].x = &data[i];

//     class point *queries = (class point *)calloc(sets, sizeof(class point));
//     // Generate 20D query points
//     for (int i = 0; i < sets; i++)
//         rand_pt(&queries[i], DIM);

//     class KD_node *root;
//     for (int i = 0; i < 6; i++)
//     {
//         root = make_tree(data, N, 0, dim[i]);
//         // root->dist = 0;
//         clock_t begin = clock();
//         for (int j = 0; j < sets; j++)
//         {
//             heap h1;
//             heap h2;
//             h2.push(root);
//             kNN(&h1, &h2, &queries[j], dim[i], k);
//             // seq_scan(data1, N, &queries[j], dim[i], k);
//         }
//         clock_t end = clock();
//         double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
//         cout << dim[i] << " " << elapsed_secs/k << endl;
//     }
//     for (int i = 0; i < 6; i++)
//     {
//         root = make_tree(data, N, 0, dim[i]);
//         // root->dist = 0;
//         clock_t begin = clock();
//         for (int j = 0; j < sets; j++)
//         {
//             heap h1;
//             heap h2;
//             h2.push(root);
//             // kNN(&h1, &h2, &queries[j], dim[i], k);
//             seq_scan(data1, N, &queries[j], dim[i], k);
//         }
//         clock_t end = clock();
//         double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
//         cout << dim[i] << " " << elapsed_secs/k << endl;
//     }

//     for (int i = 0; i < 6; i++)
//     {
//         root = make_tree(data, N, 0, dim[i]);
//         // root->dist = 0;
//         pair<float, float> res = make_pair(0.0, 0.0);
//         pair<float, float> tem;
//         // clock_t begin = clock();
//         for (int j = 0; j < sets; j++)
//         {
//             heap h1;
//             heap h2;
//             h2.push(root);
//             // kNN(&h1, &h2, &queries[j], dim[i], k);
//             tem = seq_scan(data1, N, &queries[j], dim[i], 100);
//             res.first += tem.first;
//             res.second += tem.second;
//         }
//         // clock_t end = clock();
//         // double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
//         cout << dim[i] << " " << res.first/100.0 << " " << res.second/100.0 << " " << res.first/res.second << endl;
//     }

//     // cout << "-----------------------------------------------" << endl;
//     // for(int i = 0; i < 100000000000; i++)
//     // {
//     //     int k = 0;
//     // }

//     return 0;
// }