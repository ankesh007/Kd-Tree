python3 parent.py data/dataset.n.100000.d.2.txt data/query.n.100.d.2.txt 20 
python3 parent.py data/dataset.n.100000.d.3.txt data/query.n.100.d.3.txt 20
python3 parent.py data/dataset.n.100000.d.5.txt data/query.n.100.d.5.txt 20
python3 parent.py data/dataset.n.100000.d.10.txt data/query.n.100.d.10.txt 20
python3 parent.py data/dataset.n.100000.d.15.txt data/query.n.100.d.15.txt 20
python3 parent.py data/dataset.n.100000.d.20.txt data/query.n.100.d.20.txt 20

# python3 parent.py data/dataset.n.100000.d.2.txt data/query.n.100.d.2.txt 100
# python3 parent.py data/dataset.n.100000.d.3.txt data/query.n.100.d.3.txt 100
# python3 parent.py data/dataset.n.100000.d.5.txt data/query.n.100.d.5.txt 100
# python3 parent.py data/dataset.n.100000.d.10.txt data/query.n.100.d.10.txt 100
# python3 parent.py data/dataset.n.100000.d.15.txt data/query.n.100.d.15.txt 100
# python3 parent.py data/dataset.n.100000.d.20.txt data/query.n.100.d.20.txt 100
