//
//  main.cpp
//  kd-tree
//
//  Created by Praveen P Kulkarni on 17/04/18.
//  Copyright © 2018 Praveen P Kulkarni. All rights reserved.
//

#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
// #include <cassert>
#include <queue>
using namespace std;

struct stacknode_t {
    int dim_index;
    int L;
    int median;
    int R;
    bool processed_once;
};

const int STACK_SIZE = 100;
// const double EPS = 1e-8;

stacknode_t rec_stack[STACK_SIZE];
vector<pair<double,int>> kdtree;
vector<vector<double>> points;
vector<vector<double>> querypoints;
vector<double> querypoint;
int ndata;
int ndim;
int k = 20;

struct LexicalComparator {
    bool operator()(const pair<double, int> &v1, const pair<double, int> &v2) {
        if(v1.first != v2.first) return v1.first < v2.first;
        for(int i = 0; i < ndim; ++i) {
            if(points[v1.second][i] == points[v2.second][i]) continue;
            return points[v1.second][i] < points[v2.second][i];
        }
        // assert(false);
        return false;
    }
};

typedef priority_queue<pair<double, int>, vector<pair<double, int>>, LexicalComparator> knn_t;
// typedef priority_queue<pair<double, int>> knn_t;
knn_t knn;

void read_points(vector<vector<double>> &points, const string filename) {
    ifstream fin(filename);
    fin >> ndim >> ndata;
    points.clear();
    points.resize(ndata, vector<double>(ndim, 0));
    for(int i = 0; i < ndata; ++i) {
        for(int j = 0; j < ndim; ++j) {
            fin >> points[i][j];
        }
    }
    fin.close();
}

void make_kdtree(const int dim_index, int L, int R) {
    if(L == R) return;
    sort(points.begin() + L,
         points.begin() + R + 1,
         [&](const vector<double> &v1, const vector<double> &v2){
             return (v1[dim_index] < v2[dim_index]);
    });
    int median = (L + R) / 2;
    // assert(L <= R);
    // assert(L <= median);
    // assert(median + 1 <= R);
    make_kdtree((dim_index + 1) % ndim, L, median);
    make_kdtree((dim_index + 1) % ndim, median + 1, R);
}

inline double l2norm(const vector<double> &v1, const vector<double> &v2) {
    double norm = 0;
    for(int i = 0; i < ndim; ++i) {
        double diff = v1[i] - v2[i];
        norm += diff * diff;
    }
    return norm;
}

void arraystack_search() {
    int stack_ptr = 0;
    rec_stack[0] = {0, 0, (ndata - 1) >> 1, ndata-1, false};
    while(stack_ptr >= 0) {
        const auto &node = rec_stack[stack_ptr];
        if(node.R - node.L <= ndim * 4) {
            stack_ptr--;
            for(int i = node.L; i <= node.R; ++i) {
                knn.push({l2norm(points[i], querypoint), i});
                if (knn.size() > k) knn.pop();
            }
            // while(knn.size() > k) knn.pop();
            continue;
        }
//        if(node.L == node.R) {
//            stack_ptr--;
//            knn.push({l2norm(points[node.L], querypoint), node.L});
//            if(knn.size() > k) knn.pop();
//            continue;
//        }
        const double split_value = points[node.median][node.dim_index];
        const int next_dim_index = (node.dim_index + 1) % ndim;
        const bool go_left = querypoint[node.dim_index] <= split_value;
        if(not node.processed_once) {
            const int L1 = (go_left ? node.L : node.median + 1);
            const int R1 = (go_left ? node.median : node.R);
            rec_stack[stack_ptr].processed_once = true;
            rec_stack[++stack_ptr] = {next_dim_index, L1, (L1 + R1) >> 1, R1, false};
        } else {
            const double diff = split_value - querypoint[node.dim_index];
            stack_ptr--;
            if(knn.size() < k or diff * diff < knn.top().first) {
                const int L2 = (go_left ? node.median + 1 : node.L);
                const int R2 = (go_left ? node.R : node.median);
                rec_stack[++stack_ptr] = {next_dim_index, L2, (L2 + R2) >> 1, R2, false};
            }
        }
    }
}

inline void search_kdtree(int dim_index, int L, int R) {
    // if(L == R) {
    //     knn.push({l2norm(points[L], querypoint), L});
    //     if(knn.size() > k) knn.pop();
    //     return;
    // }
    if(R - L <= ndim*4) {
        for(int i = L; i <= R; ++i) {
            knn.push({l2norm(points[i], querypoint), i});
            if (knn.size() > k) knn.pop();
        }
        // while(knn.size() > k) knn.pop();
        return;
    }
    int median = (L + R) >> 1;
    double split_value = points[median][dim_index];
    int next_dim_index = (dim_index + 1) % ndim;
    double diff = split_value - querypoint[dim_index];
    if(querypoint[dim_index] <= split_value) {
        search_kdtree(next_dim_index, L, median);
        // assert(not knn.empty());
        if(knn.size() < k or diff * diff < knn.top().first)
            search_kdtree(next_dim_index, median + 1, R);
    } else {
        search_kdtree(next_dim_index, median + 1, R);
        if(knn.size() < k or diff * diff < knn.top().first)
            search_kdtree(next_dim_index, L, median);
    }
}

inline void write_knn(knn_t &q, ofstream &fout) {
    vector<int> order;
    while(not q.empty()) {
        order.push_back(q.top().second);
        q.pop();
    }
    for(int i = (int)order.size() - 1; i >= 0; --i) {
        int index = order[i];
        for(double elem: points[index]) {
            fout << elem << " ";
        }
        fout << "\n";
    }
}

int main(int argc, const char * argv[]) {
    string data_file = argv[1];// "dataset.n.100000.d.20.txt";
    string query_file; // = "query.n.100.d.20.txt";
    read_points(points, data_file);
    
    make_kdtree(0, 0, ndata - 1);

    cout << 0 << endl;
    cin >> query_file >> k;
            
    read_points(querypoints, query_file);
    ndata = (int)points.size();
    
    ofstream fout("results.txt");
    for(int i = 0; i < querypoints.size(); ++i) {
        querypoint = querypoints[i];
        arraystack_search();
        // search_kdtree(0, 0, ndata-1);
        write_knn(knn, fout);
    }
    fout.close();
    cout << 1 << endl;
    return 0;
}
