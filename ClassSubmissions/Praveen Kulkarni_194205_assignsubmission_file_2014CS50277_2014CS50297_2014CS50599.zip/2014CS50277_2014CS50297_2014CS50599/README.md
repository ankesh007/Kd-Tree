# KDTree assignment

### Instructions

```python3 parent.py <path-to-datafile> <path-to-queryfile> <k>```

Some datafiles and queryfiles can be found in the `data/` directory in the format described  below. 

__Point files__: ```dataset.n.<num-of-points>.d.<dimension>.txt```.   
__Query files__: ```dataset.n.<num-of-points>.d.<dimension>.txt```. 

You can use the command ```python3 generate_datasets.py``` to generate new datapoints.

Examples of commands to run can be found in `commands.sh`.