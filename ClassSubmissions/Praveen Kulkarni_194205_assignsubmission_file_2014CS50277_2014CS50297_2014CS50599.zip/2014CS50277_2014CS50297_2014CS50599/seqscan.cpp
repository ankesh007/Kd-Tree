//  Created by Praveen P Kulkarni on 13/04/18.
//  Copyright © 2018 Praveen P Kulkarni. All rights reserved.

#include <algorithm>
#include <fstream>
#include <iostream>
#include <numeric>
#include <queue>
#include <vector>
#include <cassert>
using namespace std;

int ndim;
int ndata;

// read the uniformly distributed points from a file
void read_points(vector<vector<double>> &points, const string filename) {
    ifstream fin(filename);
    fin >> ndim >> ndata;
    points.clear();
    points.resize(ndata, vector<double>(ndim, 0));
    for(int i = 0; i < ndata; ++i) {
        for(int j = 0; j < ndim; ++j) {
            fin >> points[i][j];
        }
    }
    fin.close();
}

// calculate the squared-L2 distance between two points
inline double square_dist(const vector<double> &pt1, const vector<double> &pt2) {
    double answer = 0;
    for(int i = 0; i < ndim; ++i) {
        double diff = pt1[i] - pt2[i];
        answer += diff * diff;
    }
    return answer;
}

// read the query file consisting of a single point
void read_query_file(vector<double> &querypoint, const string query_file) {
    querypoint.clear();
    querypoint.resize(ndim, 0);
    ifstream fin(query_file);
    int d; fin >> d;
    for(int i = 0; i < ndim; ++i) {
        fin >> querypoint[i];
    }
    fin.close();
}

inline void write_knn(const vector<vector<double>> &points,
                      priority_queue<pair<double, int>> &q,
                      ofstream &fout) {
    vector<int> order;
    while(not q.empty()) {
        order.push_back(q.top().second);
        q.pop();
    }
    for(int i = (int)order.size() - 1; i >= 0; --i) {
        int index = order[i];
        for(double elem: points[index]) {
            fout << elem << " ";
        }
        fout << "\n";
    }
}

// perform sequential scan to find the knn
inline void sequential_scan(priority_queue<pair<double, int>> &knn,
                            const vector<vector<double>> &points,
                            const vector<double> &point,
                            const int k) {
    for(int i = 0; i < ndata; ++i) {
        double dst = square_dist(points[i], point);
        knn.push({dst, i});
        if(knn.size() > (unsigned int)k) {
            knn.pop();
        }
    }
}

inline bool compare_lexi(const vector<double> &v1,
                         const vector<double> &v2) {
    for(int i = 0; i < ndim; ++i) {
        if(v1[i] < v2[i]) return true;
        if(v1[i] > v2[i]) return false;
    }
    return false;
}

int main(int argc, char *argv[]) {
    // init variables
    int k;
    vector<vector<double>> points;
    vector<vector<double>> querypoints;
    string query_file;
    priority_queue<pair<double, int>> knn;
    string dataset_file = argv[1];
    
    // read dataset and then flush 0 to STDOUT
    read_points(points, dataset_file);
    sort(points.begin(), points.end(), compare_lexi);
    cout << 0 << endl;
    
    // read the queryfile from STDIN
    cin >> query_file;
    cin >> k;
    read_points(querypoints, query_file);
    ndata = (int)points.size();

    clock_t start = clock();
    ofstream fout("results.txt");

    // perform the knn-search
    for(auto &querypoint: querypoints) {
        sequential_scan(knn, points, querypoint, k);
        write_knn(points, knn, fout);
    }
    clock_t end = clock();
    cerr << (double)(end - start) / CLOCKS_PER_SEC << " seconds for query" << endl;
    fout.close();
    // write 1 to STDOUT
    cout << 1 << endl;
}
