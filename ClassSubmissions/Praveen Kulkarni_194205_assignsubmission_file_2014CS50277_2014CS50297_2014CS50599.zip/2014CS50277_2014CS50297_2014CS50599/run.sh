g++ -std=c++14 -Ofast -march=native kdtree.cpp -o kdtree.out
./kdtree.out $1
#g++ -std=c++14 -Ofast -march=native kdtree2.cpp -o kdtree2.out
#./kdtree2.out $1
#g++ -std=c++14 -Ofast -march=native seqscan.cpp -o seqscan.out
#./seqscan.out $1

