#!/bin/bash
g++ Knn1.cpp -std=c++1y -Ofast; ./a.out $1
#g++ Knn1.cpp -O3 -std=c++1y; ./a.out $1
# python sample.py $1
