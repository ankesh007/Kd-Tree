#!/bin/bash

g++ tree.cpp -std=c++11 -O3
./a.out $1