#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cfloat>
#include <cmath>
#include <algorithm>
#include <vector>

using namespace std;

vector<vector<double> > whole_data;
vector<vector<double> > whole_queries;
vector<double> query;
int N, D, K, Nquery;

class Node{
	public:
		int index;
		double contributionofcuttingdimn;
		vector<double> lower_bound, upper_bound;
		int dimn;
		Node(vector<double> lower_bound, vector<double> upper_bound) {
			this->lower_bound = lower_bound;
			this->upper_bound = upper_bound;
			this->left = NULL;
			this->right = NULL;
		}
		
		Node *left;
		Node *right;
};

vector<pair<int, double> > answer_set;
vector<pair<Node*, double> > candidate;

struct less_than_ans {
	bool operator()(pair<int, double> const &a, pair<int, double> const &b) const{
		if(a.second == b.second)
			return whole_data[a.first] < whole_data[b.first];
		return a.second < b.second;
	}
};

struct more_than_cand {
	bool operator()(pair<Node*, double> const &a, pair<Node*, double> const &b) const{
		return a.second > b.second;
	}
};

void print_vec(vector<double> const &v);
double l2_norm_sq(vector<double> const &v1, vector<double> const &v2);
void read_data(char *filename, vector<vector<double> > &data);
double mbr_dist_sq(double resultofparent,int dimn,double contributionofcuttingdimn,vector<double> &point, Node *node);
void growtree(Node *root, int dimn, vector<int> data);
void find_nn(Node *root);
void initialize_nn(Node *root);
void print_helper(Node* root, int space);
void print_tree(Node* root);

int main(int argc, char* argv[]) {
	char* dataset_file = argv[1];
	read_data(dataset_file, whole_data);
	N = whole_data.size();
	D = whole_data[0].size();
	
	vector<int> ind(N);
	for(int i = 0; i < N; i++) {
		ind[i] = i;
	}
  
	vector<double> lower_bound, upper_bound;
	for(int i = 0; i < D; i++) {
		lower_bound.emplace_back(DBL_MIN);
		upper_bound.emplace_back(DBL_MAX);
	}
	
	Node *root = new Node(lower_bound, upper_bound);
	root->contributionofcuttingdimn = 0.0;
	growtree(root, 0, ind);

	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	char* query_file = new char[100];
	
	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	cin >> query_file >> K;
	read_data(query_file, whole_queries);
	Nquery = whole_queries.size();

	vector<int> answers(K);
		// ofstream ansfile("results.txt");
	FILE* ansfile = fopen("results.txt","w");
	for(int i = 0; i < Nquery; i++) {
		// cerr << i + 1 << endl;
		query = whole_queries[i];
		initialize_nn(root);
		root->contributionofcuttingdimn=0.0;
		find_nn(root);

		for(int i = 0; i < K; i++) {
			answers[K - 1 - i] = answer_set.front().first;
			pop_heap(answer_set.begin(), answer_set.end(), less_than_ans());
			answer_set.pop_back();
		}

		for(int i = 0; i < K; i++) {
		    int index = answers[i];
		    for(int j = 0; j < D; j++) {
		        // ansfile << whole_data[index][j] << " ";
		        fprintf(ansfile,"%f ",whole_data[index][j]);
		    }
		    // ansfile << endl;
		    fprintf(ansfile,"\n");
		}
	  	

		// for(int i = 0; i < K; i++) {
		// 	int index = answers[i];
		// 	ansfile << index << " ";
		// }
		// ansfile << endl;

	}
	fclose(ansfile);
  
	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
	return 0;
}

// void print_tree(Node* root){
// 	print_helper(root, 0);
// }

// void print_helper(Node* root, int space){
// 	if(root == NULL)
// 	  return;
// 	space += 5;
// 	print_helper(root->right, space);
// 	printf("\n");
// 	for(int i = 5; i < space; i++)
// 	  printf(" ");
// 	printf("%d\n", root->index + 1);
// 	print_helper(root->left, space);
// }


inline double l2_norm_sq(vector<double> const &v1, vector<double> const &v2) {
	// v1 and v2 must be of same size
	double accum = 0.0;
	for(int i = 0; i < v1.size(); i++) {
		accum += (v1[i] - v2[i]) * (v1[i] - v2[i]);
	}
	
	return accum;
}

void print_vec(vector<double> const &v) {
	for(double d: v) {
		cout << d << " ";
	}
	cout << endl;
	return;
}

void sortOverDimension(vector<int> &v, int dimn) {
	vector<pair<double, int> > tobesorted;
	for(int i = 0; i< v.size(); i++) {
		tobesorted.emplace_back(make_pair(whole_data[v[i]][dimn], v[i]));
	}
  
	sort(tobesorted.begin(),tobesorted.end());
  
	for(int i = 0; i < v.size(); i++) {
		v[i] = tobesorted[i].second;
	}
	return;
}

void growtree(Node *root, int dimn, vector<int> data) {
	root->dimn = dimn;
	if(data.size() == 1) {
		root->index = data[0];
		return; 
	}
	
	sortOverDimension(data, dimn);
	int mid = data.size() / 2;
	while(mid < data.size() - 1 && whole_data[data[mid + 1]][dimn] == whole_data[data[mid]][dimn])
		mid++;

	root->index = data[mid];
	
	vector<int> dataleft;
	for(int i = 0; i < mid; i++) {
		dataleft.emplace_back(data[i]);
	}
	vector<double> lower_bound_left = vector<double>(root->lower_bound);
	vector<double> upper_bound_left = vector<double>(root->upper_bound);
	upper_bound_left[dimn] = whole_data[data[mid]][dimn];

	root->left = new Node(lower_bound_left, upper_bound_left);
	growtree(root->left, (dimn + 1) % D, dataleft);
	
	if(mid + 1 < data.size()) {
		vector<int> dataright;
		for(int i = mid + 1; i < data.size(); i++) {
			dataright.emplace_back(data[i]);
		}
		vector<double> lower_bound_right = vector<double>(root->lower_bound);
		vector<double> upper_bound_right = vector<double>(root->upper_bound);
		lower_bound_right[dimn] = whole_data[data[mid]][dimn];
		
		root->right = new Node(lower_bound_right, upper_bound_right);
		growtree(root->right, (dimn + 1) % D, dataright);   
	}
	
	return;
}

void initialize_nn(Node *root) {
	candidate.clear();
	answer_set.clear();
	
	for(int i = 0; i < K; i++) {
		answer_set.emplace_back(make_pair(-i - 1, DBL_MAX / (i + 1)));
	}
	make_heap(answer_set.begin(), answer_set.end(), less_than_ans());
	
	candidate.emplace_back(make_pair(root, 0.0));
	make_heap(candidate.begin(), candidate.end(), more_than_cand());
	
	return;
}

void find_nn(Node *root) {
	while(candidate.size() > 0) {
		pair<Node*, double> best_candidate = candidate.front();
		pop_heap(candidate.begin(), candidate.end(), more_than_cand());
		candidate.pop_back();
		
		double dist_box = best_candidate.second;
		if(dist_box <= answer_set.front().second) {
			double dist_point = l2_norm_sq(whole_data[best_candidate.first->index], query);
			if(dist_point < answer_set.front().second || (dist_point == answer_set.front().second && whole_data[best_candidate.first->index] < whole_data[answer_set.front().first])) {   
				answer_set.push_back(make_pair(best_candidate.first->index, dist_point));
				pop_heap(answer_set.begin(), answer_set.end(), less_than_ans());
				answer_set.pop_back();
			}
									
			if(best_candidate.first->left != NULL) {
				double dis_left = mbr_dist_sq(dist_box , best_candidate.first->dimn , best_candidate.first->contributionofcuttingdimn , query , best_candidate.first->left);
				




				if(dis_left <= answer_set.front().second) {
					candidate.push_back(make_pair(best_candidate.first->left, dis_left));
					push_heap(candidate.begin(), candidate.end(), more_than_cand());
				}
			}
			if(best_candidate.first->right != NULL) {
				double dis_right = mbr_dist_sq(dist_box,best_candidate.first->dimn,best_candidate.first->contributionofcuttingdimn,query, best_candidate.first->right);
				if(dis_right <= answer_set.front().second) {
					candidate.push_back(make_pair(best_candidate.first->right, dis_right));
					push_heap(candidate.begin(), candidate.end(), more_than_cand());
				}
			}  
		
		} else {
			return;
		}
	}
  
	return;
}

inline double mbr_dist_sq(double resultofparent,int dimn,double contributionofcuttingdimn,vector<double> &point, Node *node) {
	// double accum = 0.0;

	// for(int i = 0; i < node->lower_bound.size(); i++) {
	// 	if(point[i] < node->lower_bound[i])
	// 		accum += (node->lower_bound[i] - point[i]) * (node->lower_bound[i] - point[i]);
	// 	else if(point[i] > node->upper_bound[i])
	// 		accum += (node->upper_bound[i] - point[i]) * (node->upper_bound[i] - point[i]);
	// }
	double newresult = resultofparent;
	newresult -= contributionofcuttingdimn;
	if(point[dimn] < node->lower_bound[dimn])
		newresult += (node->lower_bound[dimn] - point[dimn]) * (node->lower_bound[dimn] - point[dimn]);
	else if(point[dimn] > node->upper_bound[dimn])
		newresult += (node->upper_bound[dimn] - point[dimn]) * (node->upper_bound[dimn] - point[dimn]);
	

	if(point[node->dimn] < node->lower_bound[node->dimn])
		node->contributionofcuttingdimn = (node->lower_bound[node->dimn] - point[node->dimn]) * (node->lower_bound[node->dimn] - point[node->dimn]);
	else if(point[node->dimn] > node->upper_bound[node->dimn])
		node->contributionofcuttingdimn = (node->upper_bound[node->dimn] - point[node->dimn]) * (node->upper_bound[node->dimn] - point[node->dimn]);
	


	return newresult;
}

//https://github.com/abhi19gupta/KdTree-StarterCode
void read_data(char *filename, vector<vector<double> > &data) {
	ifstream datafile(filename);
	int d, n;
	double val;
	datafile >> d >> n;
	
	for(int i = 0; i < n; i++) {
		vector<double> datapoint;
		for(int j = 0; j < d; j++) {
			datafile >> val;
			datapoint.push_back(val);
		}
		data.push_back(datapoint);
	}
	datafile.close();
	return;
}