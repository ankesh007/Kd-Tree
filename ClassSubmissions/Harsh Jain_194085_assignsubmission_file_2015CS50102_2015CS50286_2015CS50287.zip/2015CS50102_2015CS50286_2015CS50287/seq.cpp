#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cfloat>
#include <algorithm>
#include <vector>

using namespace std;

vector<vector<double> > whole_data;
vector<vector<double> > whole_queries;
vector<double> query;
int N, D, K, Nquery;


vector<pair<int, double> > answer_set;

struct less_than_ans {
	bool operator()(pair<int, double> const &a, pair<int, double> const &b) const{
		if(a.second == b.second)
			return whole_data[a.first] < whole_data[b.first];
		return a.second < b.second;
	}
};

double l2_norm_sq(vector<double> const &v1, vector<double> const &v2);
void read_data(char *filename, vector<vector<double> > &data);
void initialize();

int main(int argc, char* argv[]) {
	char* dataset_file = argv[1];
	read_data(dataset_file, whole_data);
	N = whole_data.size();
	D = whole_data[0].size();
	
	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	char* query_file = new char[100];
	
	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	cin >> query_file >> K;
	read_data(query_file, whole_queries);
	Nquery = whole_queries.size();

	vector<int> answers(K);
	// ofstream ansfile("results_seq.txt");
	FILE* ansfile = fopen("results_seq.txt","w");

	for(int i = 0; i < Nquery; i++) {
		// cerr << i + 1 << endl;
		query = whole_queries[i];
		initialize();

		for(int i = 0; i < N; i++) {
			double dist = l2_norm_sq(query, whole_data[i]);
			if(dist < answer_set.front().second || (dist == answer_set.front().second && whole_data[i] < whole_data[answer_set.front().first])) {   
				answer_set.push_back(make_pair(i, dist));
				pop_heap(answer_set.begin(), answer_set.end(), less_than_ans());
				answer_set.pop_back();
			}
		}

		for(int i = 0; i < K; i++) {
			answers[K - 1 - i] = answer_set.front().first;
			pop_heap(answer_set.begin(), answer_set.end(), less_than_ans());
			answer_set.pop_back();
		}

		for(int i = 0; i < K; i++) {
		    int index = answers[i];
		    for(int j = 0; j < D; j++) {
		        // ansfile << whole_data[index][j] << " ";
		        fprintf(ansfile,"%f ",whole_data[index][j]);
		    }
		    // ansfile << endl;
		    fprintf(ansfile,"\n");
		}
	  	

		// for(int i = 0; i < K; i++) {
		// 	int index = answers[i];
		// 	ansfile << index << " ";
		// }
		// ansfile << endl;

	}
	fclose(ansfile);
  
	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
	return 0;
}


double l2_norm_sq(vector<double> const &v1, vector<double> const &v2) {
	// v1 and v2 must be of same size
	double accum = 0.0;
	for(int i = 0; i < v1.size(); i++) {
		accum += (v1[i] - v2[i]) * (v1[i] - v2[i]);
	}
	
	return accum;
}

void initialize() {
	answer_set.clear();
	
	for(int i = 0; i < K; i++) {
		answer_set.emplace_back(make_pair(-i - 1, DBL_MAX / (i + 1)));
	}
	make_heap(answer_set.begin(), answer_set.end(), less_than_ans());
	
	return;
}

//https://github.com/abhi19gupta/KdTree-StarterCode
void read_data(char *filename, vector<vector<double> > &data) {
	ifstream datafile(filename);
	int d, n;
	double val;
	datafile >> d >> n;
	
	for(int i = 0; i < n; i++) {
		vector<double> datapoint;
		for(int j = 0; j < d; j++) {
			datafile >> val;
			datapoint.push_back(val);
		}
		data.push_back(datapoint);
	}
	datafile.close();
	return;
}