#!/bin/bash
g++ -std=c++11 -O2 sample.cpp; ./a.out $1
# python sample.py $1
