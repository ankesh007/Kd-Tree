import random
import sys

num_points = 10

for i in xrange(2,20):
	filename = 'dd'+str(i)+'.txt'
	num_dim = i
	f = open('data/' + filename, 'w+')

	f.write(str(num_dim) + ' ' + str(num_points) + '\n')

	for i in range(num_points):
		
		for j in range(num_dim):
			temp = random.random()
			f.write(str(temp) + ' ')

		f.write('\n')

	f.close()