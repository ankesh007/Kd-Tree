#include <iostream>
#include <random>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <queue>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
#include <chrono>
#include <stack>

using namespace std;

// Few initial variables

int d = 2;
int bucket_size = 1;
// int buckets[] = {10, 10, 50, 50, 100, 100, 100, 200, 200, 200, 300, 500, 500, 500, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000};
// int buckets[]{0,   1,   2,   3,   4,   5,   6,   7,   8,   9,10,  11,   12,   13,   14,   15,   16,   17,   18,   19,   20,   21}
// Single dimension data points structure

struct pt{
    double val;
    int i;

    pt(){}

    pt(double val,int i):val(val),i(i) {}

    bool operator < (const pt& str) const
    {
        return (val < str.val);
    }

};

// KD tree structure

struct kdtree{

    int split_dim=0;
    double split_val=0;

    vector<vector<double>> box;
    vector<vector<double>> points;

    kdtree *l,*r,*t;

    kdtree(){
        l = r = t = 0;
        box.resize(d);

        for(int i = 0; i < d; i++) box[i].resize(2);
    }

    bool isLeaf(){
        return !points.empty();
    }

    bool isRoot(){
        return (t == nullptr)||(t->t == nullptr);
    }

}null;

// Distance between a point and box

double distB(vector<double> p, vector<vector<double >> box){

    double dis = 0, dx;

    for(int i = 0; i < d; i++){
        dx = max(0.0, max(box[i][0] - p[i], p[i] - box[i][1]));
        dis += dx*dx;
    }

    return sqrt(dis);
}

// Distance between 2 points

double distP(vector<double> p,vector<double> q){

    double dis=0;

    for(int i=0;i<d;i++)
        dis += (p[i]-q[i])*(p[i]-q[i]);

    return sqrt(dis);
}

// Bucket Point structure

struct bucket_point{

    kdtree *bucket;
    vector<double> pt;
    vector<double> origin;

    bucket_point(){
        bucket=0;
    }

    bucket_point(vector<double> &o,vector<double> &p){
        pt = p;
        origin = o;
    }

    bucket_point(vector<double> &o,kdtree *b){
        bucket = b;
        origin = o;
    }

    bool isPoint() const{
        return !pt.empty();
    }

    bool operator < (const bucket_point& str) const
    {
        if(isPoint()&&str.isPoint()){
            double p = distP(origin,pt), q = distP(origin,str.pt);
            if(abs(p-q)==0){
                for(int i=0;i<d;i++)
                    if(pt[i]>str.pt[i]) return true;
                    else if(pt[i]<str.pt[i]) return false;
            }
            return p>q;
        }
        else if(isPoint()&&!str.isPoint())
            return distP(origin,pt)>distB(origin,str.bucket->box);
        else if(!isPoint()&&str.isPoint())
            return distB(origin,bucket->box)>distP(origin,str.pt);
        else
            return distB(origin,bucket->box)>distB(origin,str.bucket->box);
    }

};

struct heap_point{

    vector<double> pt;
    vector<double> origin;

    heap_point(vector<double> &o,vector<double> &p){
        pt = p;
        origin = o;
    }

    bool operator < (const heap_point& str) const
    {
        return distP(origin,pt)<distP(origin,str.pt);
    }
};

vector<double> getPoint(vector<vector<pt>> &all_pts, int i){

    vector<double> pt(d);

    for(int j=0;j<d;j++)
        pt[j] = all_pts[j][i].val;

    return pt;
}

// Construct KD Tree

void makeKD(kdtree &node, kdtree &parent, int level, int d, unordered_set<int> &indices, vector<vector<pt>> &all_pts){

    vector<pt> pts;

    int ld = level % d, i;

    for(i: indices){
        pts.push_back(all_pts[ld][i]);
    }

    int s = pts.size();

    sort(pts.begin(), pts.end());

    node.split_dim = ld;
    node.split_val = pts[s/2].val;
    node.t = &parent;

    // cerr<<node.t<<endl;

    int mid = s/2;

    for(;mid + 1 < s && pts[mid].val == pts[mid+1].val; mid++);

    mid++;

    kdtree *l2 = new kdtree;
    kdtree *r2 = new kdtree;

//    if(s>=bucket_size)
//         TODO put alteast one point in the buckets or use fixed bucket size?
    if(mid > 0 && s - mid > 0 && s >= bucket_size){

        if(mid > 0){

            unordered_set<int> l;

            for(i = 0; i < mid; i++)
                l.insert(pts[i].i);

            node.l = l2;

            // cerr<<node.l<<endl;

            makeKD(*l2, node, level+1, d, l, all_pts);
        }

        if(s - mid> 0){

            unordered_set<int> r;

            for(i=mid;i<s;i++)
                r.insert(pts[i].i);

            node.r = r2;

            // cerr<<node.r<<endl;

            makeKD(*r2, node, level+1, d, r, all_pts);
        }
    }
    else{

        for(i = 0; i < s; i++)
            node.points.push_back(getPoint(all_pts,pts[i].i));
    }
}


// Set bounding box at every node

void setBoundingBox(kdtree &root){

    vector<vector<double>> lb,rb,bb = root.box;

    int i,j;

    if(!root.isLeaf()){

        setBoundingBox(*root.l);
        setBoundingBox(*root.r);

        lb = root.l->box;
        rb = root.r->box;

        for(i = 0; i < d; i++){

            bb[i][0] = min(lb[i][0], rb[i][0]);
            bb[i][1] = max(lb[i][1], rb[i][1]);
        }
    }
    else{

        for(i = 0; i < d; i++){

            bb[i][0] = bb[i][1] = root.points[0][i];

            for(j = 0;j < root.points.size(); j++){

                bb[i][0] = min(bb[i][0],root.points[j][i]);
                bb[i][1] = max(bb[i][1],root.points[j][i]);
            }
        }
    }

    root.box = bb;
}

// Traverse the kd tree

void traverse(kdtree &root){

    cerr<<root.box[0][0]<<" -  "<<root.box[0][1]<<"\n";

    if(root.isLeaf())
        return;

    // cerr<<(*root.l).size<<"\n";
    // cerr<<(*root.r).size<<"\n";

    traverse(*root.l);
    traverse(*root.r);
}

// Find the bucket containing the leaf

kdtree* findBucket(kdtree &root,vector<double> pt){

    if(root.isLeaf()){
        return &root;
    }

    if(pt[root.split_dim] <= root.split_val)
        return findBucket(*root.l,pt);
    else
        return findBucket(*root.r,pt);
}

// Print out a bucket

void printBucket(kdtree &root){

    if(root.isLeaf()){

        for(int i=0; i<root.points.size(); i++){
            for(int j=0;j<d;j++){
                cerr<<root.points[i][j]<<" | ";
            }
            cerr<<endl;
        }
    }
    else
        cerr<<"ain't a leaf\n";
}

// Get the sibling to a node

kdtree *sibling(kdtree *root){

    if(root->isRoot()) return root;
    if(root->t->l == root) return root->t->r;
    else return root->t->l;
}

// Perform knn search for a given point

vector<vector<double>> knn(kdtree &root,vector<double> pt, int k){

    kdtree *bucket = findBucket(root,pt);

    priority_queue <bucket_point> pq;

    pq.push(bucket_point(pt,bucket));
    kdtree *ancestory = bucket;

    while(!ancestory->isRoot()){

        pq.push(bucket_point(pt,sibling(ancestory)));
        ancestory = ancestory->t;
    }

    vector<vector<double>> res;

    while(res.size() < k && !pq.empty()){

        bucket_point bp = pq.top();
        pq.pop();

        if(bp.isPoint()){
            res.push_back(bp.pt);
        }
        else{

            if(bp.bucket->isLeaf()){

                for(int i=0;i<bp.bucket->points.size();i++){
                    pq.push(bucket_point(pt,bp.bucket->points[i]));
                }
            }
            else {
                pq.push(bucket_point(pt,bp.bucket->l));
                pq.push(bucket_point(pt,bp.bucket->r));
            }
        }
    }
    return res;
}


vector<vector<double> > seq_knn(vector<vector<double>> points, vector<double> pt, int k){
    priority_queue <heap_point> pq;
    vector<vector<double> > res;
    for(int i=0;i<points.size();i++){
        if(pq.size()<k){
            pq.push(heap_point(pt,points[i]));
        }
        else{
            heap_point top = pq.top();
            if(distP(top.pt,pt)>distP(points[i],pt)){
                pq.pop();
                pq.push(heap_point(pt,points[i]));
            }
        }
    }
    while(pq.size()>0){
        heap_point top = pq.top();
        pq.pop();
        res.insert(res.begin(),top.pt);
    }
    return res;
}


vector<vector<double> > seq_knn_kdtree(kdtree &root, vector<double> pt, int k){
    stack<kdtree*> traversal;
    kdtree* current = &root;
    vector<vector<double>> res;
    int done = 0;
    priority_queue <heap_point> pq;
    while(!done){
        if(current!=0){
            traversal.push(current);
            current = current->l;
        }
        else{
            if(!traversal.empty()){
                current = traversal.top();
                traversal.pop();
                // do knn
                for(int i=0;i<current->points.size();i++){
                    if(pq.size()<k){
                        pq.push(heap_point(pt,current->points[i]));
                    }
                    else{
                        heap_point top = pq.top();
                        if(distP(top.pt,pt)>distP(current->points[i],pt)){
                            pq.pop();
                            pq.push(heap_point(pt,current->points[i]));
                        }
                    }
                }
                current = current->r;
            }
            else done = 1;
        }
    }
    while(pq.size()>0){
        heap_point top = pq.top();
        pq.pop();
        res.insert(res.begin(),top.pt);
    }
    return res;
}


int main(int argc, char* argv[]) {

    char* dataset_file = argv[1];

    // [TODO] Construct kdTree using dataset_file here

    FILE *fp = fopen(dataset_file, "r+");

    int num_pts, num_dim;
    int temp, i, j;
    double val;

    temp = fscanf(fp, "%d %d\n", &num_dim, &num_pts);

    d = num_dim;

    vector<vector<pt>> pts(num_dim);
    vector<vector<double>> gp(num_pts,vector<double>(num_dim));

    unordered_set<int> init;

    for(j = 0; j < num_dim; j++){
        pts[j].resize(num_pts);
    }

    for(i = 0; i < num_pts; i++){

        for(j = 0; j < num_dim - 1; j++){

            temp = fscanf(fp, "%lf ", &val);
            pts[j][i].val = val;
            pts[j][i].i = i;
            gp[i][j] = val;
        }

        temp = fscanf(fp, "%lf\n", &val);
        pts[j][i].val = val;
        pts[j][i].i = i;
        gp[i][j] = val;

        init.insert(i);
    }

    kdtree root;

    makeKD(root, null, 0, num_dim, init, pts);
    setBoundingBox(root);

    // Request name/path of query_file from parent by just sending "0" on stdout

    cout << 0 << endl;

    // Wait till the parent responds with name/path of query_file and k | Timer will start now
    char* query_file = new char[100];
    int k;

    cin >> query_file >> k;
    // cerr << dataset_file << " " << query_file << " " << k << endl;

    // [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

    FILE *fp2 = fopen(query_file, "r+");
    FILE *fp3 = fopen("results.txt", "w+");

    int num_ptsq, num_dimq;
    int res_i;

    temp = fscanf(fp2, "%d %d\n", &num_dimq, &num_ptsq);

    vector<vector<double>> query_points(num_ptsq);
    vector<vector<vector<double>>> query_results(num_ptsq);

    // auto t1 = std::chrono::high_resolution_clock::now();

    for(i = 0; i < num_ptsq; i++){

        vector<double> q_pt(num_dimq);

        for(j = 0; j < num_dimq - 1; j++){
            temp = fscanf(fp2, "%lf ", &val);
            q_pt[j] = val;
        }

        temp = fscanf(fp2, "%lf\n", &val);
        q_pt[j] = val;

        query_points[i] = q_pt;

    }

    // auto t2 = std::chrono::high_resolution_clock::now();
    // std::cerr << std::chrono::duration_cast<std::chrono::nanoseconds>(t2-t1).count() * 1e-9 << "ns\n";

    for(i = 0; i < num_ptsq; i++){

        vector<vector<double>> q_res;

       if(num_dim < 9)
           q_res = knn(root, query_points[i], k);
       else
            q_res = seq_knn_kdtree(root, query_points[i], k);

        query_results[i] = q_res;
    }

    // cerr<<disC<<"\t"<<disF<<"\t"<<disC/disF<<endl;

    // auto t3 = std::chrono::high_resolution_clock::now();
    // std::cerr << std::chrono::duration_cast<std::chrono::nanoseconds>(t3-t2).count() * 1e-9 << "ns\n";

    for(i = 0; i < num_ptsq; i++){

        for(res_i = 0; res_i < query_results[i].size(); res_i++){

            for(j = 0; j < num_dimq - 1; j++)
                fprintf(fp3, "%lf ", query_results[i][res_i][j]);

            fprintf(fp3, "%lf\n", query_results[i][res_i][j]);

            // cerr<< query_points[i][0]<<"\t"<<query_points[i][1]<<endl;
            // fprintf(fp3, "%lf\n", distP(query_results[i][res_i],query_points[i]));
        }
        // cerr<<i<<endl;
    }

    fclose(fp3);
    // auto t4 = std::chrono::high_resolution_clock::now();
    // std::cerr << std::chrono::duration_cast<std::chrono::nanoseconds>(t4-t3).count() * 1e-9<< "ns\n";

    // Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
    cout << 1 << endl;

}
