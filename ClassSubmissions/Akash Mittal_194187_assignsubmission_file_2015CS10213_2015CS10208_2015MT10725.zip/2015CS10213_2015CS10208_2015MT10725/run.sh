#!/bin/bash
g++  -Ofast -std=c++11 1d.cpp; ./a.out $1