#include <bits/stdc++.h>
#include <chrono>
#define boost ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

vector<vector<double> > data;
int n, d; //n -> number of data points; d -> dimension
int globalDim;

struct Node{
	int splitDim; // 0 to (d-1)
	vector<double> minBound;
	vector<double> maxBound;
	int point;
	double ptDist;
	double mbrDist;
	Node *leftChild, *rightChild;
	bool isLeaf;

	Node(){
		leftChild= rightChild= NULL;
		isLeaf= false;
	}
};

void readInput(char* dataset_file){
	int i;
	double a;
	ifstream inFile;
	inFile.open(dataset_file);
	inFile>>d>>n;
	string line;
	
	getline(inFile, line);
	for (i = 0; i < n; i++)
	{
  		vector<double> temp;
    	temp.clear();
		getline(inFile, line);
		istringstream iss(line);
		while(iss>>a){
			temp.push_back(a);
		}
    	data.push_back(temp);
	}
	inFile.close();
	return;
}

inline bool comparator(const int idx1,const int idx2){
	return (data[idx1][globalDim] < data[idx2][globalDim]);
}

vector<vector<int> > sort_points(){
	vector<vector<int> > sorted_points;
	int i;
	for(i=0; i<d; i++)
	{
		vector<int> temp;
		for(int i=0; i< n; i++) temp.push_back(i);
		sort(temp.begin(), temp.end(), comparator);
		globalDim++;
		sorted_points.push_back(temp);
	}
	globalDim = 0;
	return sorted_points;
}

int nodeCount=0;
Node* createKDTree(vector<vector<int> > &sorted_points, vector<double> &MinBound, vector<double> &MaxBound, int currDim){
	if (sorted_points.size()==0 ||sorted_points[0].size()==0) return NULL;
	Node* root = new Node();
	root->splitDim = currDim;
	root->minBound = MinBound;
	root->maxBound = MaxBound;

	int numOfPoints = sorted_points[0].size();
	int medianIdx= sorted_points[currDim][numOfPoints/2]; 
	root->point = medianIdx;

	if (sorted_points[0].size()==1){ // base case
		root->isLeaf=true;
		return root;
	}

	// split the sorted points array into left and right halves
	set<int> leftHalf;
	set<int> rightHalf;
	for (int i=0; i< numOfPoints/2; i++){
		leftHalf.insert(sorted_points[currDim][i]);
	}
	for (int i= (numOfPoints/2) + 1; i< numOfPoints; i++){
		rightHalf.insert(sorted_points[currDim][i]);
	}

	vector<vector<int> > left_sorted_points(d, vector<int> ());
	vector<vector<int> > right_sorted_points(d, vector<int> ());
	for (int i=0; i<d ;i++){
		for (int j=0; j < sorted_points[i].size(); j++){
			int idx = sorted_points[i][j];
			if (leftHalf.find(idx) != leftHalf.end()){
				left_sorted_points[i].push_back(idx);
			}
			else if (rightHalf.find(idx)!= rightHalf.end()){
				right_sorted_points[i].push_back(idx);
			}
		}
	}
	
	vector<double> maxBoundLeft;
	vector<double> minBoundRight;
	for(int i=0; i<d; i++)
	{
		minBoundRight.push_back(MinBound[i]);
		maxBoundLeft.push_back(MaxBound[i]);
	}
	
	int medPt= sorted_points[currDim][sorted_points[0].size()/2];
	minBoundRight[currDim] = data[medPt][currDim];
	maxBoundLeft[currDim] = data[medPt][currDim];

	if (left_sorted_points.size()!=0 && left_sorted_points[0].size() != 0){
		int leftNum= left_sorted_points[0].size();
		for (int i=0; i < d; i++){
			MinBound[i]= data[left_sorted_points[i][0]][i];
			maxBoundLeft[i]= data[left_sorted_points[i][leftNum-1]][i];
		}
	}
	root->leftChild = createKDTree(left_sorted_points, MinBound, maxBoundLeft,(currDim+1)%d);

	if (right_sorted_points.size() !=0 && right_sorted_points[0].size() != 0){
		int rightNum= right_sorted_points[0].size();
		for (int i=0; i< d; i++){
			minBoundRight[i]= data[right_sorted_points[i][0]][i];
			MaxBound[i]= data[right_sorted_points[i][rightNum-1]][i];
		}
	}
	root->rightChild = createKDTree(right_sorted_points, minBoundRight, MaxBound,(currDim+1)%d); 
	return root;
}

Node* createKDTree_intermediate(){
	vector<vector<int> > sorted_points = sort_points();
	vector<double> minBound;
	vector<double> maxBound;
	int numOfPoints= sorted_points[0].size();
	for(int i=0; i<d; i++)
	{
		minBound.push_back(data[sorted_points[i][0]][i]);
		maxBound.push_back(data[sorted_points[i][numOfPoints-1]][i]);
	}
	Node* root = createKDTree(sorted_points,minBound, maxBound,0);
	return root;
}

//KNN Code Start
vector<double> queryPoint;
double eps= 1e-9;

inline double distPoint(int p){
	double ans =0;
	for (int i=0; i< d; i++){
		ans += (data[p][i] - queryPoint[i])*(data[p][i] - queryPoint[i]);
	}
	return sqrt(ans);
}

inline double minDistanceMBR(Node* nd){
	double ans= 0;
	for (int i=0; i< d; i++){
		double pI = queryPoint[i];
		double distI=0;
		if (pI < (nd->minBound[i])) distI= (nd->minBound[i] - pI);
		else if (pI > (nd->maxBound[i])) distI= pI- (nd->maxBound[i]);
		else distI= 0;
		ans += (distI*distI);
	}
	return sqrt(ans);
}

inline bool outputComparator(int idx1, int idx2){
	double d1= distPoint(idx1);
	double d2= distPoint(idx2);
	if (abs(d1-d2) > eps) return (d1 < d2);
	for (int i=0; i< d; i++){
		if (abs(data[idx1][i]-data[idx2][i]) > eps) return (data[idx1][i] < data[idx2][i]);
	}
	return true;
}

class MinPQCompare{
public:
	bool operator() (Node* nd1, Node* nd2){
		double d1= nd1->mbrDist;
		double d2= nd2->mbrDist;
		if (abs(d1-d2) > eps) return (d1 > d2);
		int idx1= nd1->point;
		int idx2= nd2->point;
		for (int i=0; i< d; i++){
			if (abs(data[idx1][i] -data[idx2][i]) > eps) return (data[idx1][i] > data[idx2][i]);
		} 
		return true;
	}
};

class MaxPQCompare{
public:
	bool operator() (Node* nd1, Node* nd2){
		double d1= nd1->ptDist;
		double d2= nd2->ptDist;
		if (abs(d1-d2) > eps) return (d1 < d2);
		int idx1= nd1->point;
		int idx2= nd2->point;
		for (int i=0; i< d; i++){
			if (abs(data[idx1][i]-data[idx2][i]) > eps ) return (data[idx1][i] < data[idx2][i]);
		} 
		return true;
	}
};

inline bool isPointLessMBR(Node* nd1, Node* nd2){
	double d1= nd1->ptDist;
	double d2= nd2->mbrDist;
	if (abs(d1-d2) > eps) return (d1 < d2);
	int idx1= nd1->point;
	int idx2= nd2->point;
	for (int i=0; i< d; i++){
		if (abs(data[idx1][i]-data[idx2][i]) > eps) return (data[idx1][i] < data[idx2][i]);
	}
	return true;
}

inline bool isPointLessPoint(Node* nd1, Node* nd2){
	double d1= nd1->ptDist;
	double d2= nd2->ptDist;
	if (abs(d1-d2) > eps) return (d1 < d2);
	int idx1= nd1->point;
	int idx2= nd2->point;
	for (int i=0; i< d; i++){
		if (abs(data[idx1][i]-data[idx2][i]) > eps) return (data[idx1][i] < data[idx2][i]);
	}
	return true;
}

#define minpq priority_queue<Node*, vector<Node*> , MinPQCompare> // min heap
#define maxpq priority_queue<Node*, vector<Node*> , MaxPQCompare> // max heap

void knnUtil(minpq &candidate, maxpq &answer, int k){
	int t=0;
	bool flag= false;

	while (answer.size() < k){
		Node* nd= candidate.top();
		candidate.pop();
		answer.push(nd);
		if (nd->isLeaf== false){
			if (nd->leftChild) {
				Node* child= nd->leftChild;
				child->ptDist= distPoint(child->point);
				child->mbrDist= minDistanceMBR(child);
				candidate.push(child);
			}
			if (nd->rightChild) {
				Node* child= nd->rightChild;
				child->ptDist= distPoint(child->point);
				child->mbrDist= minDistanceMBR(child);
				candidate.push(child);
			}
		}
	}

	while (true){
		t++;
		if (candidate.empty()) break;
		
		Node* nd = candidate.top();
		candidate.pop();
		if (isPointLessMBR(answer.top(),nd)) break;
		else {
			if (isPointLessPoint(nd,answer.top())) {
				answer.pop();
				answer.push(nd);
			}

			if ((nd->isLeaf) == false){
				Node* child= nd->leftChild;
				if (child){
					child->ptDist= distPoint(child->point);
					child->mbrDist= minDistanceMBR(child);
					if (child && (!isPointLessMBR(answer.top(),child))) {
						if (child->isLeaf){
							if (isPointLessPoint(child,answer.top())){
								answer.pop();
								answer.push(child);
							}
						}
						else candidate.push(child);
					}
				}
				
				child= nd->rightChild;
				if (child){
					child->ptDist= distPoint(child->point);
					child->mbrDist= minDistanceMBR(child);
					if (child && (!isPointLessMBR(answer.top(),child)) ) {
						if (child->isLeaf){
							if (isPointLessPoint(child,answer.top())){
								answer.pop();
								answer.push(child);
							}
						}
						else candidate.push(child);
					}
				}
			}
		}
	}
}

void knn(int k, Node* root, vector<int> &output){
	if (root==NULL) return;
	minpq candidate; //minHeap based on minimum distance from MBR
	maxpq answer; //maxHeap

	root->ptDist = distPoint(root->point);
	root->mbrDist = minDistanceMBR(root);
	candidate.push(root);

	knnUtil(candidate,answer,k);
	output.clear();
	
	while (!answer.empty()){
		Node* nd = answer.top();
		int idx = nd->point;
		answer.pop();
		output.push_back(idx);
	}
	reverse(output.begin(), output.end()); // ascending order
}

// KNN Sequential Scan
// 1,2 : true -> upar
class SeqMaxPQCompare{
public:
	bool operator() (pair<double,int> pr1,  pair<double,int> pr2){
		double d1= pr1.first;
		double d2= pr2.first;
		int idx1= pr1.second;
		int idx2= pr2.second;
		if (abs(d1-d2) > eps) return (d1 < d2);
		for (int i=0; i< d; i++){
			if (abs(data[idx1][i]-data[idx2][i]) > eps) return (data[idx1][i] < data[idx2][i]);
		}
		return true;
	}
};

// set the global queryPoint
void sequentialScan(int k, vector<int> &output){
	priority_queue<pair<double,int> , vector<pair<double,int> >,SeqMaxPQCompare > answer; // max pq
	
	for (int i=0; i< n; i++){
		if (answer.size() < k) answer.push(make_pair(distPoint(i),i) );
		else {
			int idx1= i;
			double dist1 = distPoint(i);
			int idx2= answer.top().second;
			double dist2 = answer.top().first;
			
			if (abs(dist1-dist2) > eps){
				if (dist1 < dist2) {
					answer.pop();
					answer.push(make_pair(dist1,idx1));
				}
			}
			else {
				for (int j=0; j< d; j++){
					if (abs(data[idx1][j]-data[idx2][j]) > eps) {
						if (data[idx1][j] < data[idx2][j]){
							answer.pop();
							answer.push(make_pair(distPoint(i),i));
							break;
						}
					}
				}
			}
		}
	}

	output.clear();
	while(!answer.empty()){
		output.push_back(answer.top().second);
		answer.pop();
	}
	reverse(output.begin(), output.end());
}

// KNN Code End

int main(int argc, char* argv[]) {
	boost
	// cout << "prog start" << endl;
	char* dataset_file = argv[1];
	readInput(dataset_file);

	// [TODO] Construct kdTree using dataset_file here
	Node* root = createKDTree_intermediate();

	cout << 0 << endl;
	// cout << "tree end" << endl;
	// Request name/path of query_file from parent by just sending "0" on stdout

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;

	k = min(k,n);
	// cerr << dataset_file << " " << query_file << " " << k << endl;
	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

	vector<vector<double> > querypoints;

	ifstream inFile;
	inFile.open(query_file);
	int nq;
	inFile>>d>>nq;

    FILE* fw = fopen("results.txt","w");
	

	string line;
	double a;
	int i;
	getline(inFile, line);
	for (i = 0; i < nq; i++)
	{
  		vector<double> temp;
    	temp.clear();
		getline(inFile, line);
		istringstream iss(line);
		while(iss>>a){
			temp.push_back(a);
		}
    	querypoints.push_back(temp);
	}
	
	inFile.close();

	for (i = 0; i < nq; i++)
	{
		vector<int> solution;
		queryPoint = querypoints[i];
		// sequentialScan(k,solution);
		knn(k,root,solution);
		int sol_size = solution.size();

		for (int j = 0; j < sol_size; j++){			
			for (int l = 0; l < d; l++){
				if (l!=(d-1))
				{
					fprintf(fw, "%lf ",data[solution[j]][l]);
				}
				else{
					fprintf(fw, "%lf",data[solution[j]][l]);	
				}
			}
			if (!((i==nq-1) && (j==(sol_size-1))))
			{
				fprintf(fw, "\n");
			}
		}
	}
	fclose(fw);
	cout << 1 << endl;
	return 0;
}
