import subprocess
from matplotlib import pyplot as plt

dims = [2,3,5,10,15,20]
kd_times = []
sc_times = []
for _dim in dims:
    kd_time,sc_time = 0,0
    for i in range(5):
        str_d = str(_dim)
        set_f_name = '.\\'+str_d+'_points.csv'
        pts_f_name = '.\\'+str_d+'_points.csv'

        p1 = subprocess.Popen(["java","-jar","q1_spl.jar",str_d,pts_f_name,set_f_name],stderr=subprocess.PIPE)
        a = p1.stderr.read()
        a = a.decode().strip()
        a = list(map(float,a.split(',')))
        kd_time += a[0]
        sc_time += a[1]
    kd_times.append(kd_time/5)
    sc_times.append(sc_time/5)

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(dims,kd_times,'-o',label="kNN using KD Tree",color='blue')
ax.plot(dims,sc_times,'-s',label="kNN using Seq Scan",color='red')
ax.set_title("Time comparison")
ax.set_xlabel("Number of Dimensions")
ax.set_ylabel("Average runtime in Mili Seconds")
ax.legend()
plt.savefig('q1_spl.png')
plt.show()