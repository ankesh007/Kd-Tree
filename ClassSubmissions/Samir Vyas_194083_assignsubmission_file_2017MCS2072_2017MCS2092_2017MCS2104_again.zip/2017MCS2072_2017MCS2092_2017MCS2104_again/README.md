#To run a part
## It must have .CSV files corresponding the 100000 points of each dimensions.
## To replicate this result mail me on vyassamir11@gmail.com, I can provide those data files as they are too big to be included in the submission.  
python q1_spl.py 

#To run b part
python q2.py 

#To run C part
python parent.py dataset.txt query.txt <k>

##For Example
python parent.py 20_points_ss.txt 20_set_ss.txt 100
