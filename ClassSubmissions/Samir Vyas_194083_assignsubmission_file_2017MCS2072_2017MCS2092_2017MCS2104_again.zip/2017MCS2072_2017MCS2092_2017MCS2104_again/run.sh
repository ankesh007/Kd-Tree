#!/bin/bash
# g++ sample.cpp; ./a.out $1
java -jar q3_spl.jar $1
