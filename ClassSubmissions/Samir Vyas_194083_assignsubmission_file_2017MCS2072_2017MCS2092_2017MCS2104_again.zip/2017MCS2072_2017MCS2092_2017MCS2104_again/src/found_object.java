
public class found_object {
	private kd_node node;
	private boolean found;
	
	public found_object(kd_node node, boolean found){
		this.node = node;
		this.found = found;
	}
	
	public kd_node get_node(){
		return this.node;
	}
	public boolean get_bool(){
		return this.found;
	}
	
	public String toString(){
		return "Status : "+this.found+"\t"+"Leaf Node : "+this.node.toString();
	}

}
