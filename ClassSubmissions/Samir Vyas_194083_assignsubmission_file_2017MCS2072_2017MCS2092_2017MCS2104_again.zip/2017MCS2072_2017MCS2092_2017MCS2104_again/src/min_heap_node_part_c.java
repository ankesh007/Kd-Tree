
public class min_heap_node_part_c implements Comparable<min_heap_node_part_c>{
	private kd_node_part_c node;
	private double query_dist;
	
	public min_heap_node_part_c(kd_node_part_c node,double query_dist){
		this.query_dist = query_dist;
		this.node = node;
	}
	
	
	public kd_node_part_c get_node(){
		return this.node;
	}
	
	public double get_qeury_dist(){
		return this.query_dist;
	}
	
	public int compareTo(min_heap_node_part_c node){
		//this is reverse comparable so priority queue becomes a max heap
		if(this.query_dist > node.query_dist){
			return 1;
		}
		else if (this.query_dist < node.query_dist){
			return -1;
		}
		else{
			return 0;
		}
	}

}
