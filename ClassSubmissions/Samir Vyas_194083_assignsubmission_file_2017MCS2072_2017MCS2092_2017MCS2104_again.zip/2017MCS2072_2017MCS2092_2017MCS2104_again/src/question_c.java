import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class question_c {
	private static double[][] test;
	private static int d;
	private static int n;
	
	private static void reading(String f_name){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(f_name));
			String[] head = br.readLine().split(" ");
			d = Integer.parseInt(head[0]);
			n = Integer.parseInt(head[1]);
			test = new double[n][d];
			for (int i = 0; i<n; i++){
			String[] values = br.readLine().split(" ");
				for (int j =0; j<d; j++){
					test[i][j] = Double.parseDouble(values[j]);
				}
			}
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (br != null){
				try{
					br.close();
				}
				catch (IOException e){
					e.printStackTrace();
				}
			}	
		}
		
	}
	
	public static void main(String[] args) throws IOException{
		String data_file_name = args[0];
		kd_tree_part_c tree = new kd_tree_part_c(data_file_name,1);
		PrintWriter writer = new PrintWriter("results.txt", "UTF-8");
		
		System.out.println("0");
		
		Scanner in = new Scanner(System.in);
		String test_file_name = in.next();
		int k = Integer.parseInt(in.next());
		in.close();
		
		reading(test_file_name);
		for (double[] query : test){
			ArrayList<max_heap_node> out = tree.kNN(k, query);
			for (max_heap_node node : out){
				String out_string = "";
				double[] point = node.get_point();
				for (int i = 0; i<point.length; i++){
					if (i != point.length-1){
						out_string += Double.toString(point[i])+" ";
					}
					else{
						out_string += Double.toString(point[i]);
					}
				}
				writer.println(out_string);
			}
		}
	
		writer.close();
		
		System.out.println("1");
	}
}
