import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.lang.Math;

public class kd_tree_part_c {
	private double[][] data = null;
	private String f_name = null;
	private int d = -1;
	private int n = -1;
	private kd_node_part_c root;
	private int samples_leaf;
	
	private static double norm(double[] q1, double[] q2){
		if (q1.length != q2.length){
			throw new RuntimeException("Unqeual lengths while computing norm.");
		}
		else{
			double out = 0;
			for (int i = 0; i<q1.length; i++){
				out += Math.pow((q1[i]-q2[i]),2);
			}
			out = Math.sqrt(out);
			return out;
		}
	}
	
	private void reading(String f_name){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(f_name));
			String[] head = br.readLine().split(" ");
			this.d = Integer.parseInt(head[0]);
			this.n = Integer.parseInt(head[1]);
			this.data = new double[this.n][this.d];
			for (int i = 0; i<this.n; i++){
			String[] values = br.readLine().split(" ");
				for (int j =0; j<d; j++){
					data[i][j] = Double.parseDouble(values[j]);
				}
			}
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (br != null){
				try{
					br.close();
				}
				catch (IOException e){
					e.printStackTrace();
				}
			}	
		}
		
	}
	
	
	public kd_tree_part_c(String f_name,int samples_leaf){
		this.f_name = f_name;
		this.samples_leaf = samples_leaf;
		this.reading(this.f_name);
		
		//generate root indices
		ArrayList<Integer> root_indices = new ArrayList<Integer>();
		for (int i = 0; i<this.n; i++){
			root_indices.add(i);
		}
		root = new kd_node_part_c(null,data,root_indices,0,this.d,this.samples_leaf);
		LinkedList<kd_node_part_c> queue = new LinkedList<kd_node_part_c>();
		queue.add(root);
		
		while(!queue.isEmpty()){
			kd_node_part_c current = queue.poll();
			if(!current.is_a_leaf()){
				kd_node_part_c[] children = current.split();
				for(kd_node_part_c node : children){
					queue.add(node);
				}
			}
		}
	}
	
//	public found_object find(double[] query){
//		if(query.length != this.d){
//			throw new RuntimeException("Invalid query size. Expected:"+this.d+" Got:"+query.length);
//		}
//		boolean found = false;
//		kd_node_part_c current = root;
//		while (!current.is_a_leaf()){
//			int dim_to_see = current.get_split_dimension();
//			double median = current.get_split_median();
//			if (query[dim_to_see] <= median){
//				current = current.get_child(0);
//			}
//			else{
//				current = current.get_child(1);
//			}
//		}
//		
//		found =  current.find_in_leaf(query);
//		return new found_object(current,found);
//	}
	
	public ArrayList<max_heap_node> kNN(int k, double[] query){
		PriorityQueue<min_heap_node_part_c> candidate = new PriorityQueue<min_heap_node_part_c>();
		candidate.add(new min_heap_node_part_c(this.root,this.root.get_dist_MBR_all(query)));
		fixed_k_max_heap answer_set = new fixed_k_max_heap(k);
		answer_set.insert(new max_heap_node(new double[this.d],Double.POSITIVE_INFINITY));
		
		while((!candidate.isEmpty()) && (candidate.peek().get_qeury_dist() <= answer_set.peek().fetch_distance())){
			min_heap_node_part_c candidate_node = candidate.poll();
			max_heap_node answer_set_node = answer_set.peek();
			
			if (candidate_node.get_qeury_dist() > answer_set_node.fetch_distance()){
				continue;
			}
			else{
				if (candidate_node.get_node().is_a_leaf()){
					for(int index : candidate_node.get_node().get_indices()){
						answer_set.insert(new max_heap_node(this.data[index],norm(query,this.data[index])));
					}
				}
				else{
					//put point of internal node in max heap now
					int point_index = candidate_node.get_node().get_point_index();
					answer_set.insert(new max_heap_node(this.data[point_index],norm(query,this.data[point_index])));
					
					for(kd_node_part_c child : candidate_node.get_node().get_children()){
						if(child.get_dist_MBR_all(query) <= answer_set_node.fetch_distance()){
							candidate.add(new min_heap_node_part_c(child,child.get_dist_MBR_all(query)));
						}
					}
				}
			}
		}
		ArrayList<max_heap_node> out_list = new ArrayList<max_heap_node>();
		for(int i = 0; i < k; i++){
			out_list.add(answer_set.poll());
		}
		Collections.sort(out_list);
		Collections.reverse(out_list);
		return out_list;
	}
}
