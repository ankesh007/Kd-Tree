import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class question_b {
	private static double[][] test;
	
	private static void reading(String f_name, int d){
		test = new double[100][d]; 
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(f_name));
			for (int i = 0; i<100; i++){
					String[] values = br.readLine().split(",");
					for (int j =0; j<d; j++){
						test[i][j] = Double.parseDouble(values[j]);
					}
			}
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (br != null){
				try{
					br.close();
				}
				catch (IOException e){
					e.printStackTrace();
				}
			}	
		}
		
	}
	
	public static void main(String[] args){
		String d = args[0]; 
		String pts_f_name = args[1];
		String set_f_name = args[2];
		seq_scan scan = new seq_scan(d,pts_f_name);
		
		reading(set_f_name,Integer.parseInt(d));
		
		double tot_2nd = 0;
		double tot_100th = 0;
		for(double[] query : test){
			ArrayList<max_heap_node> out = scan.kNN(100, query);
			tot_2nd += out.get(1).fetch_distance();
			tot_100th += out.get(out.size()-1).fetch_distance();
		}
		
		System.err.println(tot_2nd/tot_100th);
	}
}
