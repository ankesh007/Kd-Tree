import java.util.PriorityQueue;

public class fixed_k_max_heap {
	private int k;
	private int size;
	private PriorityQueue<max_heap_node> queue;
	
	public fixed_k_max_heap(int k){
		this.k = k;
		this.size = 0;
		this.queue = new PriorityQueue<max_heap_node>();
	}
	
	public max_heap_node peek(){
		return queue.peek();
	}
	
	public boolean insert(max_heap_node node){
		if (this.size < this.k){
			this.queue.add(node);
			this.size++;
			return true;
		}
		else{
			max_heap_node root = this.queue.peek();
			if(node.fetch_distance() < root.fetch_distance()){
				this.queue.poll();
				this.queue.add(node);
				return true;
			}
			else if (node.fetch_distance() == root.fetch_distance()){
				if (root.compareTo(node) != -1){
					this.queue.poll();
					this.queue.add(node);
					return true;
				}
			}
			return false;
		}
	}
	
	public max_heap_node poll(){
		return this.queue.poll();
	}
}
