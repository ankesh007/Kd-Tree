import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class question_a {
	private static double[][] test;
	
	private static void reading(String f_name, int d){
		test = new double[100][d]; 
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(f_name));
			for (int i = 0; i<100; i++){
					String[] values = br.readLine().split(",");
					for (int j =0; j<d; j++){
						test[i][j] = Double.parseDouble(values[j]);
					}
			}
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (br != null){
				try{
					br.close();
				}
				catch (IOException e){
					e.printStackTrace();
				}
			}	
		}
		
	}
	
	public static void main(String[] args){
		String d = args[0]; 
		String pts_f_name = args[1];
		String set_f_name = args[2];
		kd_tree tree = new kd_tree(pts_f_name,Integer.parseInt(d),1);
		seq_scan scan = new seq_scan(d,pts_f_name);
		
		reading(set_f_name,Integer.parseInt(d));
		long tot_time_kd = 0;
		long tot_time_sc = 0;
		
		for (int i = 0; i<100; i++){
			
			long start1 = System.nanoTime();
			tree.kNN(20, test[i]);
			long end1 = System.nanoTime();
			tot_time_kd += (end1-start1)/1000000.0;
			
			long start2 = System.nanoTime();
			scan.kNN(20, test[i]);
			long end2 = System.nanoTime();
			tot_time_sc += (end2-start2)/1000000.0;
		}
		System.err.println(tot_time_kd/100.0+","+tot_time_sc/100.0);
	}
}
