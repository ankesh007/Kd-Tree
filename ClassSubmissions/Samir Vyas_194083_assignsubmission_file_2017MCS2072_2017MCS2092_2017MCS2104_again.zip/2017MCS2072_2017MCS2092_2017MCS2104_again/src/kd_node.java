import java.util.ArrayList;
import java.util.Collections;
import java.util.Arrays;
import java.util.Random;

public class kd_node {
	private kd_node parent;
	private double[][] data;
	private ArrayList<Integer> indices;
	private int split_dim;
	private int depth;
	private kd_node[] children;
	private int d;
	private double split_med;
	private int samples_leaf;
	private boolean is_leaf;
	Random rand;
	///
	private double[] r_min_all;
	private double[] r_max_all;
	///
//	private double r_min;
//	private double r_max;
	///
	
	public kd_node(kd_node parent,double[][] data, ArrayList<Integer> indices,int depth, int d, int samples_leaf){
		this.parent = parent;
		this.data = data;
		this.indices = indices;
		this.split_dim = depth%d;
		this.depth = depth;
		this.d = d;
		this.samples_leaf = samples_leaf;
		///
		this.r_min_all = new double[this.d];
		this.r_max_all = new double[this.d];
		for (int i = 0; i<this.d; i++){
			this.r_min_all[i] = Double.POSITIVE_INFINITY;
			this.r_max_all[i] = Double.NEGATIVE_INFINITY;
		}
		///
//		this.r_min = double.POSITIVE_INFINITY;
//		this.r_max = double.NEGATIVE_INFINITY;
		this.check_leaf();
		this.init_MBR_all();
//		this.init_MBR_one();
		this.rand = new Random();
	}
	
	private void check_leaf(){
		if (this.indices.size() <= this.samples_leaf){
			this.is_leaf = true;
		}
	}
	
	public boolean is_a_leaf(){
		return this.is_leaf;
	}
	
	public String toString(){
		String s = "";
		s += "Depth : "+this.depth+" ";
		s += "Size : "+this.indices.size()+" ";
		s += "Split Dimension : "+this.split_dim+" ";
		s += "Split Median : "+this.split_med+" ";
		s += "Is a leaf : "+this.is_leaf+" ";
		return s;
	}
	

	public kd_node[] split(){
		if (this.is_leaf){
			throw new RuntimeException("Leaf cannot be split.") ;
		}
		ArrayList<Double> split_dim_of_points = new ArrayList<Double>();
		for (int index : this.indices){
			split_dim_of_points.add(this.data[index][this.split_dim]);
		}
		Collections.sort(split_dim_of_points);
		if(split_dim_of_points.size()%2 == 1){
			this.split_med = split_dim_of_points.get((split_dim_of_points.size()+1)/2);
		}
		else{
			this.split_med = split_dim_of_points.get((split_dim_of_points.size())/2);
			
		}
		
		ArrayList<Integer> left_indices = new ArrayList<Integer>();
		ArrayList<Integer> right_indices = new ArrayList<Integer>();
		
		for (int index : this.indices){
			// without randomness
//			if (this.data[index][this.split_dim] <= this.split_med){
//				left_indices.add(index);
//			}
//			else{
//				right_indices.add(index);
//			}
			
			if (this.data[index][this.split_dim] < this.split_med){
				left_indices.add(index);
			}
			else if (this.data[index][this.split_dim] > this.split_med){
				right_indices.add(index);
			}
			else{
				if (this.rand.nextBoolean()){
					left_indices.add(index);
				}
				else{
					right_indices.add(index);
				}
			}
		}
		
		kd_node left_child = new kd_node(this,this.data,left_indices,this.depth+1,this.d,this.samples_leaf);
		kd_node right_child = new kd_node(this,this.data,right_indices,this.depth+1,this.d,this.samples_leaf);
		
		this.children = new kd_node[2];
		this.children[0] = left_child;
		this.children[1] = right_child;
		return this.children;
	}
	
	public kd_node get_child(int i){
		return this.children[i];
	}
	
	public kd_node[] get_children(){
		return this.children;
	}
	
	public int get_split_dimension(){
		return this.split_dim;
	}
	
	public double get_split_median(){
		return this.split_med;
	}
	
	public ArrayList<Integer> get_indices(){
		return this.indices;
	}
	
	public int get_depth(){
		return this.depth;
	}
	
	public boolean find_in_leaf(double[] query){
		if(this.is_leaf){
			boolean found = false;
			for(int index : this.indices){
				if(Arrays.equals(query,this.data[index])){
					found = true;
					break;
				}
			}
			return found;
		}
		else{
			throw new RuntimeException("Cannot find in a non leaf node");
		}
	}
		
	public void init_MBR_all(){
		for(int index : this.indices){
			for(int i = 0; i<this.d; i++){
				if(this.data[index][i] < this.r_min_all[i]){
					this.r_min_all[i] = this.data[index][i];
				}
				if(this.data[index][i] > this.r_max_all[i]){
					this.r_max_all[i] = this.data[index][i];
				}
			}
		}
	}
	
	public double get_dist_MBR_all(double[] query){
		double tot = 0;
		for (int i = 0; i < this.d; i++){
			if (query[i] < this.r_min_all[i]){
				tot += Math.pow(this.r_min_all[i] - query[i],2);
			}
			else if (query[i] > this.r_max_all[i]){
				tot += Math.pow(query[i] - this.r_max_all[i],2);
			}
			else{
				tot += 0;
			}
		}
		return (double) Math.sqrt(tot);
	}
	
	
//	public void init_MBR_one(){
//		int parent_split_dim = -1;
//		if (this.parent == null){
//			parent_split_dim = 0;
//		}
//		else{
//			parent_split_dim = this.parent.get_split_dimension();
//		}
//		for (int index : this.indices){
//			if (this.data[index][parent_split_dim] < this.r_min){
//				this.r_min = this.data[index][parent_split_dim];
//			}
//			if (this.data[index][parent_split_dim] > this.r_max){
//				this.r_max = this.data[index][parent_split_dim];
//			}
//		}
//	}
	
	
//	public double get_dist_MBR_one(double[] query_point){
//		int parent_split_dim = -1;
//		if (this.parent == null){
//			parent_split_dim = 0;
//		}
//		else{
//			parent_split_dim = this.parent.get_split_dimension();
//		}
//		
//		if (query_point[parent_split_dim] > this.r_max){
//			return query_point[parent_split_dim] - this.r_max;
//		}
//		else if (query_point[parent_split_dim] < this.r_min){
//			return  this.r_min - query_point[parent_split_dim];
//		}
//		else{
//			return 0;
//		}
//		
//	}
}
