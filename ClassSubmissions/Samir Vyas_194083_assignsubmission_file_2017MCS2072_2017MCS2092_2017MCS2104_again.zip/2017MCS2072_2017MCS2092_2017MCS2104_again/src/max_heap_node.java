import java.util.Arrays;

public class max_heap_node implements Comparable<max_heap_node>{
	private double[] point;
	private double distance;
	
	public max_heap_node(double[] point, double distance){
		this.point = point;
		this.distance = distance;
	}
	
	public double fetch_distance(){
		return this.distance;
	}
	
	public double[] get_point(){
		return this.point;
	}
	
	public int compareTo(max_heap_node node){
		//this is reverse comparable so priority queue becomes a max heap
		if(this.distance > node.fetch_distance()){
			return -1;
		}
		else if (this.distance < node.fetch_distance()){
			return 1;
		}
		else{
			//tie resolution,actually reverse is needed considering one more reverse in kNN side
			//tested and correct
			double[] node_point = node.get_point();
			for (int i = 0; i<this.get_point().length; i++){
				if (node.get_point()[i] < this.get_point()[i]){
					return -1;
				}
				else if (node.get_point()[i]> this.get_point()[i]){
					return 1;
				}
			}
			return 1;
		}
	}
	
	public String toString(){
		String s = Arrays.toString(this.point)+"\t"+this.distance;
		return s;
	}
}
