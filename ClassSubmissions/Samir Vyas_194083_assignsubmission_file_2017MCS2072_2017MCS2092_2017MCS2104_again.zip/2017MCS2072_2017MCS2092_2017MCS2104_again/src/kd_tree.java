import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.lang.Math;

public class kd_tree {
	private double[][] data = null;
	private String f_name = null;
	private int d = -1;
	private kd_node root;
	private int samples_leaf;
	
	private static double norm(double[] q1, double[] q2){
		if (q1.length != q2.length){
			throw new RuntimeException("Unqeual lengths while computing norm.");
		}
		else{
			double out = 0;
			for (int i = 0; i<q1.length; i++){
				out += Math.pow((q1[i]-q2[i]),2);
			}
			out = (double) Math.sqrt(out);
			return out;
		}
	}
	
	private void reading(String f_name, int d){
		data = new double[100000][d]; 
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(f_name));
			for (int i = 0; i<100000; i++){
					String[] values = br.readLine().split(",");
					for (int j =0; j<d; j++){
						data[i][j] = Double.parseDouble(values[j]);
					}
			}
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (br != null){
				try{
					br.close();
				}
				catch (IOException e){
					e.printStackTrace();
				}
			}	
		}
		
	}
	
	
	public kd_tree(String f_name, int d, int samples_leaf){
		this.f_name = f_name;
		this.d = d;
		this.samples_leaf = samples_leaf;
		this.reading(this.f_name, this.d);
		
		//generate root indices
		ArrayList<Integer> root_indices = new ArrayList<Integer>();
		for (int i = 0; i<100000; i++){
			root_indices.add(i);
		}
		root = new kd_node(null,data,root_indices,0,this.d,this.samples_leaf);
		LinkedList<kd_node> queue = new LinkedList<kd_node>();
		queue.add(root);
		
		while(!queue.isEmpty()){
			kd_node current = queue.poll();
			//System.err.println(current);
			if(!current.is_a_leaf()){
				kd_node[] children = current.split();
				for(kd_node node : children){
					queue.add(node);
				}
			}
		}
	}
	
	public found_object find(double[] query){
		if(query.length != this.d){
			throw new RuntimeException("Invalid query size. Expected:"+this.d+" Got:"+query.length);
		}
		boolean found = false;
		kd_node current = root;
		while (!current.is_a_leaf()){
			int dim_to_see = current.get_split_dimension();
			double median = current.get_split_median();
			if (query[dim_to_see] <= median){
				current = current.get_child(0);
			}
			else{
				current = current.get_child(1);
			}
		}
		
		found =  current.find_in_leaf(query);
		return new found_object(current,found);
	}
	
	public ArrayList<max_heap_node> kNN(int k, double[] query){
		PriorityQueue<min_heap_node> candidate = new PriorityQueue<min_heap_node>();
		candidate.add(new min_heap_node(this.root,this.root.get_dist_MBR_all(query)));
		fixed_k_max_heap answer_set = new fixed_k_max_heap(k);
		answer_set.insert(new max_heap_node(new double[this.d],Double.POSITIVE_INFINITY));
		
		while((!candidate.isEmpty()) && (candidate.peek().get_qeury_dist() <= answer_set.peek().fetch_distance())){
			min_heap_node candidate_node = candidate.poll();
			max_heap_node answer_set_node = answer_set.peek();
			
			if (candidate_node.get_qeury_dist() > answer_set_node.fetch_distance()){
				continue;
			}
			else{
				if (candidate_node.get_node().is_a_leaf()){
					for(int index : candidate_node.get_node().get_indices()){
						answer_set.insert(new max_heap_node(this.data[index],norm(query,this.data[index])));
					}
				}
				else{
					for(kd_node child : candidate_node.get_node().get_children()){
						if(child.get_dist_MBR_all(query) <= answer_set_node.fetch_distance()){
							candidate.add(new min_heap_node(child,child.get_dist_MBR_all(query)));
						}
					}
				}
			}
		}
		ArrayList<max_heap_node> out_list = new ArrayList<max_heap_node>();
		for(int i = 0; i < k; i++){
			out_list.add(answer_set.poll());
		}
		Collections.sort(out_list);
		Collections.reverse(out_list);
		return out_list;
	}
}
