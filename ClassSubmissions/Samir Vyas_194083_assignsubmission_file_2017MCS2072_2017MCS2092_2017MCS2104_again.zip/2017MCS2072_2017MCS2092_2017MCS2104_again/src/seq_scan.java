import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class seq_scan {
	private String d = null;
	private String pts_f_name = null;
	private double[][] data;
	
	private static double norm(double[] q1, double[] q2){
		if (q1.length != q2.length){
			throw new RuntimeException("Unqeual lengths while computing norm.");
		}
		else{
			double out = 0;
			for (int i = 0; i<q1.length; i++){
				out += Math.pow((q1[i]-q2[i]),2);
			}
			out = Math.sqrt(out);
			return out;
		}
	}
	
	private void reading_data(String f_name, int d){
		data = new double[100000][d]; 
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new FileReader(f_name));
			for (int i = 0; i<100000; i++){
					String[] values = br.readLine().split(",");
					for (int j =0; j<d; j++){
						data[i][j] = Double.parseDouble(values[j]);
					}
			}
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (br != null){
				try{
					br.close();
				}
				catch (IOException e){
					e.printStackTrace();
				}
			}	
		}
		
	}
	
	
	public seq_scan(String d, String pts_f_name){
		this.d = d;
		this.pts_f_name = pts_f_name;
		this.reading_data(this.pts_f_name, Integer.parseInt(this.d));
	}
	
	public ArrayList<max_heap_node> kNN(int k, double[] query){
		fixed_k_max_heap heap = new fixed_k_max_heap(k);
		for (double[] point : this.data){
			heap.insert(new max_heap_node(point,norm(point,query)));
		}
		ArrayList<max_heap_node> out_list = new ArrayList<max_heap_node>();
		for(int i = 0; i < k; i++){
			out_list.add(heap.poll());
		}
		Collections.sort(out_list);
		Collections.reverse(out_list);
		return out_list;
	}
}
