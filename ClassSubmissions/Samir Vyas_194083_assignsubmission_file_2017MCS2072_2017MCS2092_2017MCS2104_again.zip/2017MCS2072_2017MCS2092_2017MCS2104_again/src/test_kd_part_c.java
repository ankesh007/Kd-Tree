import java.util.ArrayList;
import java.util.Arrays;
public class test_kd_part_c {
	
	public static void main(String[] args){		
		int d = 20;
		int knn = 100;
		String file_name = "E:\\Academics\\DBMS\\Assignments\\Assignment_3\\"+d+"_points_ss.txt";
		long start = System.nanoTime();
		kd_tree_part_c tree = new kd_tree_part_c(file_name,1);
		long end = System.nanoTime();
		System.err.println("Time taken to make tree : "+(end-start)/1000000.0+" mili seconds");
		
		//double[] query = new double[d];
		//double[] query = {0.15274223368590212,0.052885517858600295,0.7139812953694001,0.26387805619462856,0.5727380890649901,0.6608046175059821,0.1322844595228776,0.681760051389019,0.4606348819106406,0.9820178359618884,0.6761006747546473,0.05421194351430181,0.70268738578924,0.7934649219944248,0.38724376601902066,0.8992055052422416,0.9552591015260244,0.5711625297743189,0.7404749138674616,0.1807375285117755};
		
		double[] query = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		start = System.nanoTime();
//		System.err.println(tree.find(query));
//		end = System.nanoTime();
//		System.err.println("Finding time : "+(end-start)/1000000.0+" milli seconds");
		
		start = System.nanoTime();
		ArrayList<max_heap_node> out = tree.kNN(knn, query);
		end = System.nanoTime();
		System.err.println("Query run-time : "+(end-start)/1000000.0+" milli seconds");
		
		for(max_heap_node node : out){
			System.err.println(node);
		}
		
//		long tot = 0;
//		for (int i = 0; i<100; i++){
//			start = System.nanoTime();
//			ArrayList<max_heap_node> out = tree.kNN(knn, query);
//			end = System.nanoTime();
//			tot += (end-start)/1000000.0;
//		}
//		System.err.println("Average kNN time : "+(tot/100.0)+" miliseconds");
		

	}
}
