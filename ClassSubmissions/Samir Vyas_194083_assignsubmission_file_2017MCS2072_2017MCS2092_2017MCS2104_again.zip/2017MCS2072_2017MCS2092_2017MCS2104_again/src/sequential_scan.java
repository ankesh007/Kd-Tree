
public class sequential_scan {
	
	public sequential_scan(){
		
	}
}
