
public class min_heap_node implements Comparable<min_heap_node>{
	private kd_node node;
	private double query_dist;
	
	public min_heap_node(kd_node node,double query_dist){
		this.query_dist = query_dist;
		this.node = node;
	}
	
	
	public kd_node get_node(){
		return this.node;
	}
	
	public double get_qeury_dist(){
		return this.query_dist;
	}
	
	public int compareTo(min_heap_node node){
		//this is reverse comparable so priority queue becomes a max heap
		if(this.query_dist > node.query_dist){
			return 1;
		}
		else if (this.query_dist < node.query_dist){
			return -1;
		}
		else{
			return 0;
		}
	}

}
