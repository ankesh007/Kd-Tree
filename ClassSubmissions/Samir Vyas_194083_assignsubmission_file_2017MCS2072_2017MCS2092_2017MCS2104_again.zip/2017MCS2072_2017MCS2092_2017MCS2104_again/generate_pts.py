import random,sys
d = int(sys.argv[1])

f_name = str(d)+'_points.csv'
data = ''
for i in range(100000):
    line = ''
    for j in range(d):
        line += str(random.random())+','
    line = line[:-1]
    if i != 99999:
        line += '\n'
    data += line

open(f_name,'w').write(data)
print("Points CSV written")

f_name = str(d)+'_set.csv'
data = ''
for i in range(100):
    line = ''
    for j in range(d):
        line += str(random.random())+','
    line = line[:-1]
    if i != 99999:
        line += '\n'
    data += line

open(f_name,'w').write(data)
print("Qeury CSV written")
