import subprocess
from matplotlib import pyplot as plt

dims = [2,3,5,10,15,20]
ratio = []

for _dim in dims:
    _ratio = 0
    for i in range(5):
        str_d = str(_dim)
        set_f_name = '.\\'+str_d+'_points.csv'
        pts_f_name = '.\\'+str_d+'_points.csv'

        p1 = subprocess.Popen(["java","-jar","q2.jar",str_d,pts_f_name,set_f_name],stderr=subprocess.PIPE)
        a = p1.stderr.read()
        a = a.decode().strip()
        a = float(a)
        _ratio += a
    ratio.append(_ratio/5)

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(dims,ratio,'-o',label="average_distance_2nd_closet/average_distance_100th_closet",color='blue')
ax.set_title("Distance comparison")
ax.set_xlabel("Number of Dimensions")
ax.set_ylabel("Ratio")
ax.legend()
plt.savefig('q2.png')
plt.show()