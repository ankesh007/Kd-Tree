import random
import csv
import sys
import time
import os




def dataset(dimension,no_of_points): 
    with open(str(dimension)+'.txt', 'w', newline='') as csvfile:
        filewriter = csv.writer(csvfile, delimiter=' ', quotechar='|', quoting=csv.QUOTE_MINIMAL)
        filewriter.writerow([str(dimension),str(no_of_points)])
        for i in range(0,no_of_points):
            filewriter.writerow([str(random.uniform(0,1)) for number in range(dimension)])


def testset(dimension,no_of_points): 
    with open('test_' + str(dimension)+'.txt', 'w', newline='') as csvfile:
        filewriter = csv.writer(csvfile, delimiter=' ', quotechar='|', quoting=csv.QUOTE_MINIMAL)
        filewriter.writerow([str(dimension),str(no_of_points)])
        for i in range(0,no_of_points):
            filewriter.writerow([str(random.uniform(0,1)) for number in range(dimension)])




def make_kd_tree(points, dim, i=0):
    if len(points) > 1:
        points.sort(key=lambda x: x[i])
        i = (i + 1) % dim
        half = len(points) >> 1
        return (
            make_kd_tree(points[: half], dim, i),
            make_kd_tree(points[half + 1:], dim, i),
            points[half])
    elif len(points) == 1:
        return (None, None, points[0])


def search_kd_knn(kd_node, point, k, dim, distance_fn, output_distance=False, j=0, heap=None):
    import heapq
    boolroot = not heap
    if boolroot:
        heap = []
    if kd_node:
        dist = distance_fn(point, kd_node[2])
        dx = kd_node[2][j] - point[j]
        if len(heap) < k:
            heapq.heappush(heap, (-dist, kd_node[2]))
        elif dist < -heap[0][0]:
            heapq.heappushpop(heap, (-dist, kd_node[2]))
        j = (j + 1) % dim
        search_kd_knn(kd_node[dx < 0], point, k, dim, distance_fn, output_distance, j, heap)
        if dx * dx < -heap[0][0]:
            search_kd_knn(kd_node[dx >= 0], point, k, dim, distance_fn, output_distance, j, heap)
    if boolroot:
        next_point = sorted((-h[0], h[1]) for h in heap)
        return next_point if output_distance else [n[1] for n in next_point]


def knn_sequential(points, point, k, distance_fn, output_distance=False):
    next_point = []
    for i, pp in enumerate(points):
        dist = distance_fn(point, pp)
        next_point.append((dist, pp))
    next_point = sorted(next_point)[:k]
    return next_point if output_distance else [n[1] for n in next_point]


def direct_distance(x, y, dim):
    return sum((x[i] - y[i]) ** 2 for i in range(dim))


def distance_dimension(x, y):
    return direct_distance(x, y, dim)

def rand_point(dim):
    return [random.uniform(0, 1) for d in range(dim)]


class PointContainer(list):
    def __new__(self, value):
        return super(PointContainer, self).__new__(self, value)
    def set(self, label):
        self.label = label
        return self



def write_result(result_list): 
    with open("results.txt", "a", newline='') as f:
        writer = csv.writer(f, delimiter=' ', quotechar='|', quoting=csv.QUOTE_MINIMAL)
        writer.writerows(result_list)


if __name__ == '__main__':

    dataset_file = sys.argv[1]

    # [TODO] Construct kdTree using dataset_file here
    global points,test,dim,final_result,k
    datalines = tuple(open(str(dataset_file), 'r'))
    #
    dim = int(datalines[0].split()[0])
    no_of_points = int(datalines[0].split()[1])
    
    points = [PointContainer(float(x) for x in datalines[x].split()).set(label=datalines[x]) for x in range(1,no_of_points+1)]
    kd_tree = make_kd_tree(points, dim)
    final_result=[]

    # Request name/path of query_file from parent by just sending "0" on stdout
    sys.stdout.write('0\n')

    # Wait till the parent responds with name/path of query_file and k | Timer will start now
    query_file = input()
    k = int(input())

    # [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt
    testlines = tuple(open(str(query_file),'r'))
    no_of_test_points = int(testlines[0].split()[1])
    test = [PointContainer(float(x) for x in testlines[x].split()).set(label=testlines[x]) for x in range(1,no_of_test_points+1)]
    

    for t in test:
        final_result.append(tuple(search_kd_knn(kd_tree, t, k, dim, distance_dimension)))
    if os.path.exists("results.txt"):
        os.remove("results.txt")
    for i in range(len(final_result)):
        write_result(final_result[i])
    # Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
    sys.stdout.write('1\n')