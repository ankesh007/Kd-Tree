#!/bin/bash
g++ -std=c++11 -Ofast sample.cpp; ./a.out $1
# python sample.py $1