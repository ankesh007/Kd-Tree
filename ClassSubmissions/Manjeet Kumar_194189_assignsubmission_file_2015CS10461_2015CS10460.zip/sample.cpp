#include <bits/stdc++.h>
using namespace std;
#define MAX 100000

struct node  {
	int cd;
	float *p;
	pair<float,float> mbr;
	node *left,*right;
}root;

float distance(float *a,float *b);
float mbr_distance(node *a,float *q);
int compare_points(float *a,float *b);
int dimension,n1,n2;
float *input[MAX];
float *NN[100];

struct nn_compare {
	nn_compare (float *q) {this->q = q;}
	float *q;
	bool operator () (float *a,float *b) {
		float d = distance(a,q) - distance(b,q);
		if(d==0) {
			int c = compare_points(a,b);
			if(c==-1)
				return 1;
			else 
				return 0;
		}
		else {
			if(d > 0)
				return 0;
			else
				return 1;	
		}
	} 
};

struct mbr_compare {
	mbr_compare (float *q) {this->q = q;}
	float *q;
	int cd;
	bool operator () (node *a,node *b) {return mbr_distance(a,q) > mbr_distance(b,q);} 
};

struct Local {
	Local (int d) {this->d = d;}
	int d;
	bool operator () (float *a,float *b) {return *(a+d) < *(b+d);} 
};

float distance(float *a,float *b) {
	float d = 0.0,ai,bi;
	for(int i=0;i<dimension;i++) {
		ai = *(a+i);
		bi = *(b+i);
		d += (ai - bi)*(ai - bi);
	}
	return sqrt(d);
}

float mbr_distance(node *a,float *q) {
	pair<float,float> p = (*a).mbr;
	int cd = (*a).cd;
	if(p.first > *(q+cd))
		return p.first - *(q+cd);
	else if(p.second < *(q+cd))
		return *(q+cd) - p.second;
	else 
		return 0.0;
}

void preorder(node *n) {							// for dimension 2 only
	if(n!= NULL){
		cout<<"("<<*((*n).p)<<","<<*((*n).p+1)<<"), ";
		preorder((*n).left);
		preorder((*n).right);
	}
}

int compare_points(float *a,float *b) {
	for(int i=0;i<dimension;i++) {
		if(*(a+i) < *(b+i))
			return -1;
		else if(*(a+i) > *(b+i))
			return 1;
	}
}

node* create_kd_tree(int start,int end,int depth) {
	node *n = new node;
	int cd = depth % dimension,med = (end+start)/2;
	if(start == end)
		return NULL;
	else if(end-start == 1) {
		(*n).cd = cd;
		(*n).p = input[start];
		(*n).mbr = make_pair(*(input[start]+cd),*(input[start]+cd));
		(*n).left = (*n).right = NULL;
	}
	else {
		sort(input+start,input+end,Local(cd));
		(*n).cd = cd;
		(*n).p = input[med];
		(*n).mbr = make_pair(*(input[start]+cd),*(input[end-1]+cd));
		(*n).left = create_kd_tree(start,med,depth+1);
		(*n).right = create_kd_tree(med+1,end,depth+1);
	}
	return n;
}

void kNN(float q[],int k) {
	priority_queue<float*,vector<float *>,nn_compare> nearest_neighbours((nn_compare(q)));
	priority_queue<node *,vector<node *>,mbr_compare> MBR((mbr_compare(q))); 

	// initialising nearest_neighbours
	for(int i=0;i<k;i++)
		nearest_neighbours.push(input[i]);

	MBR.push(&root);
	float furthest_nn_dist = distance(nearest_neighbours.top(),q);
	while(!MBR.empty()){
		node *curr_node = MBR.top();
		MBR.pop();
		if(mbr_distance(curr_node,q) > furthest_nn_dist) {
			// return 
			for(int i=0;i<k;i++) {
				NN[k-1-i] = nearest_neighbours.top();
				nearest_neighbours.pop();
			}
			return;
		}
		else {
			if(distance((*curr_node).p,q) < furthest_nn_dist) {
				nearest_neighbours.pop();
				nearest_neighbours.push((*curr_node).p);
				furthest_nn_dist = distance(nearest_neighbours.top(),q);
			}
			else if(distance((*curr_node).p,q) == furthest_nn_dist) {
				nearest_neighbours.push((*curr_node).p);
				nearest_neighbours.pop();
			}	
			
			if((*curr_node).left != NULL && mbr_distance((*curr_node).left,q) <= furthest_nn_dist) 
				MBR.push((*curr_node).left);
			if((*curr_node).right != NULL && mbr_distance((*curr_node).right,q) <= furthest_nn_dist)
				MBR.push((*curr_node).right);
		}
	}
	// return since MBR is empty
	for(int i=0;i<k;i++) {
		NN[k-1-i] = nearest_neighbours.top();
		nearest_neighbours.pop();
	}
	return;
}

void sequential(float q[],int k) {
	priority_queue<float*,vector<float *>,nn_compare> nearest_neighbours((nn_compare(q)));

	// initialising nearest_neighbours
	for(int i=0;i<k;i++)
		nearest_neighbours.push(input[i]);

	for(int i=0;i<n1;i++) {
		nearest_neighbours.push(input[i]);
		nearest_neighbours.pop();
	}

 	for(int i=0;i<k;i++) {
		NN[k-1-i] = nearest_neighbours.top();
		nearest_neighbours.pop();
	}
	return;
}

int main(int argc, char* argv[])
{
	char* dataset_file = argv[1];

	ifstream infile;
	ofstream outfile;

	// reading file
	infile.open(dataset_file);
	infile>>dimension>>n1;
	float input_point[n1][20];
	for(int i=0;i<n1;i++)
		for(int j=0;j<dimension;j++) 
			infile>>input_point[i][j];
	infile.close();

	// creating an array of pointers
	for(int i=0;i<n1;i++)
		input[i]=&input_point[i][0];

	// creating kd tree
	root = *(create_kd_tree(0,n1,0));
	// preorder(&root);

	cout<<0<<endl;

	// reading query file
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;

	infile.open(query_file);
	infile>>dimension>>n2;
	float query_point[n2][20];
	for(int i=0;i<n2;i++)
		for(int j=0;j<dimension;j++) 
			infile>>query_point[i][j];
	infile.close();

	// for timing
	// double sum_times = 0,average_dist2 = 0,average_dist100 = 0,sequential_time = 0;
	// clock_t begin,end;

	// performing queried and writing output
	float *point;
	outfile.open("results.txt");
	for(int i=0;i<n2;i++) {
		// begin=clock();
		kNN(query_point[i],k);
		// end=clock();
		// sum_times += double(end-begin)/CLOCKS_PER_SEC;
		// average_dist2 += distance(&query_point[i][0],NN[1]);
		// average_dist100 += distance(&query_point[i][0],NN[99]);
		for(int j=0;j<k;j++) {
			for(int k=0;k<dimension;k++) 
				outfile<<*(NN[j]+k)<<" ";
			outfile<<endl;
		}
	}
	outfile.close();

	// sequential scan

	// outfile.open("results_seq.txt");
	// for(int i=0;i<n2;i++) {
	// 	begin=clock();
	// 	sequential(query_point[i],k);
	// 	end=clock();
	// 	sequential_time += double(end-begin)/CLOCKS_PER_SEC;
	// 	// average_dist2 += distance(&query_point[i][0],NN[1]);
	// 	// average_dist100 += distance(&query_point[i][0],NN[99]);
	// 	for(int j=0;j<k;j++) {
	// 		for(int k=0;k<dimension;k++) 
	// 			outfile<<*(NN[j]+k)<<" ";
	// 		outfile<<endl;
	// 	}
	// }
	// outfile.close();

	cout<<1<<endl;
	// sum_times /= n2;
	// average_dist2 /= n2;
	// average_dist100 /= n2; 
	// sequential_time /= n2;
	// cout<<"Average running time per point : "<< sum_times <<endl;
	// cout<<"Average distance from second nearest neighbour : "<<average_dist2<<endl;
	// cout<<"Average distance from 100 nearest neighbour : "<<average_dist100<<endl;
	// cout<<"Ratio : "<<average_dist2/average_dist100<<endl;
	// cout<<"~~~~~~~~~~SEQUENTIAL ANALYSIS~~~~~~~~~~~~\n";
	// cout<<"Average sequential running time per point : "<< sequential_time <<endl;
	// cout<<"Average distance from second nearest neighbour : "<<average_dist2<<endl;
	// cout<<"Average distance from 100 nearest neighbour : "<<average_dist100<<endl;
	// cout<<"Ratio : "<<average_dist2/average_dist100<<endl;
	return 0;
}