#include <iostream>
#include <stdlib.h>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>
#include <ctime>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

double *q;
int d, knearest;

struct node
{
	double *arr;
	int split_dim;
	node *left=NULL, *right=NULL;
	double *min, *max;
	double mbr,dis;
};


double mbr_dist(double min[], double max[])
{
	double mdist = 0;
	
	for(int i=0;i<d;i++)
	{
		if(q[i]<min[i])
			mdist+= (min[i]-q[i])*(min[i]-q[i]);

		else if(q[i]>max[i])
			mdist+= (q[i]-max[i])*(q[i]-max[i]);
	}

	return mdist;
}

double dist(double arr[])
{
	double edist = 0;
		
	for(int i=0;i<d;i++)
	{
		edist+= (q[i]-arr[i])*(q[i]-arr[i]);
	}

	return edist;
}	

bool func (node *a,node *b)
{
	for (int i = 0; i < d; ++i)
	{
		if ( a->arr[i] < b->arr[i] )
		{
			return true;
		}
		else if (a->arr[i] > b->arr[i])
		{
			return false;
		}
	}
	return true;
}

class compare_min
{	
public:
	bool operator()(node *a, node *b)
	{
		return ((a->mbr)>(b->mbr));   // see for equality -------------------
	}
};


class compare_max
{	
public:
	bool operator()(node *a, node *b)
	{
		if ( (a->dis) < (b->dis) )
		{
			return true ;
		}
		else if ( (a->dis) > (b->dis) )
		{
			return false;
		}
		else if ( (a->dis) == (b->dis) )
		{
			return func(a,b);
		}

		   // see for equality -------------------
	}
};


void bfs_algorithm(node *root, int k,FILE *fp)
{
	priority_queue <node*, vector<node*>, compare_min> candidates;
	priority_queue <node*, vector<node*>, compare_max> answer_set;

	root->mbr = mbr_dist(root->min,root->max);
	candidates.push(root);			

	while(answer_set.size()!=k)
	{
		node *temp = candidates.top();
		candidates.pop();

		temp->dis=dist(temp->arr);

		answer_set.push(temp);

		if(temp->left!=NULL)
		{
			temp->left->mbr = mbr_dist(temp->left->min,temp->left->max);
			candidates.push(temp->left);
		}

		if(temp->right!=NULL)
		{
			temp->right->mbr = mbr_dist(temp->right->min,temp->right->max);
			candidates.push(temp->right);
		}
	}

	while(!candidates.empty())
	{
		node *temp = candidates.top();
		candidates.pop();

		if((answer_set.top()->dis>temp->mbr))
		{
			temp->dis=dist(temp->arr);
			if(answer_set.top()->dis > temp->dis)
			{
				answer_set.pop();
				answer_set.push(temp);
			}
			else if (answer_set.top()->dis == temp->dis)
			{
				if (!func(answer_set.top(),temp))
				{
					answer_set.pop();
					answer_set.push(temp);		
				}
			}

			if(temp->left!=NULL)
			{
				temp->left->mbr = mbr_dist(temp->left->min,temp->left->max);
				if((temp->left->mbr)<=(answer_set.top()->dis))                        
					candidates.push(temp->left);
			}

			if(temp->right!=NULL)
			{	
				temp->right->mbr = mbr_dist(temp->right->min,temp->right->max);
				if((temp->right->mbr)<=(answer_set.top()->dis))
					candidates.push(temp->right);
			}
		}
		else
			break;
	}

	double ** ans;
	ans= new double *[knearest];
	
	int m=0;
	while(!answer_set.empty())     
	{
		node *temp = answer_set.top();
		answer_set.pop();
		ans[m++] = temp->arr;
	}

	for (int i=knearest-1; i >-1; i--)
	{
		for(int j=0;j<d;j++)
		{
			fprintf(fp,"%lf ",ans[i][j]);
		}
		fprintf(fp,"\n");	
	}	

	return;
}


void sequential(node *ptr, priority_queue <node*, vector<node*>, compare_max> &answer_set)
{
	if (ptr->left==NULL && ptr->right==NULL)
	{
		ptr->dis = dist(ptr->arr);

		if(answer_set.size()!=knearest)
		{
			answer_set.push(ptr);
		}

		else if(ptr->dis < answer_set.top()->dis)
		{
			answer_set.pop();	//resolve ties
			answer_set.push(ptr);
		}

		else if(ptr->dis == answer_set.top()->dis)
		{
			if (!func(answer_set.top(),ptr))
				{
					answer_set.pop();
					answer_set.push(ptr);		
				}
		}
		return;
	}

	else if (ptr->left!=NULL)
	{
		sequential(ptr->left,answer_set);
		
		ptr->dis = dist(ptr->arr);

		if(answer_set.size()!=knearest)
		{
			answer_set.push(ptr);
		}
		else if(ptr->dis < answer_set.top()->dis)
		{
			answer_set.pop();	//resolve ties
			answer_set.push(ptr);
		}
		else if(ptr->dis == answer_set.top()->dis)
		{
			if (!func(answer_set.top(),ptr))
				{
					answer_set.pop();
					answer_set.push(ptr);		
				}
		}


		if (ptr->right!=NULL)
		{
			sequential(ptr->right,answer_set);
		}
		return;
	}
	else
	{
		ptr->dis = dist(ptr->arr);

		if(answer_set.size()!=knearest)
		{
			answer_set.push(ptr);
		}
		else if(ptr->dis < answer_set.top()->dis)
		{
			answer_set.pop();	//resolve ties
			answer_set.push(ptr);
		}
		else if(ptr->dis == answer_set.top()->dis)
		{
			if (!func(answer_set.top(),ptr))
				{
					answer_set.pop();
					answer_set.push(ptr);		
				}
		}

		if (ptr->right!=NULL)
		{
			sequential(ptr->right,answer_set);
		}
		return;
	}
}


class compare1
{
    int cd,dim_1;

public:
    compare1(int d, int di)			// alternate syntax ->  compare(int d) : dim(d) {}
    {
    	cd = d;
    	dim_1 = di;
	}

    bool operator()(double *row1, double *row2)
    {
    	int c = 0;
    	int dim=dim_1-1;

    	for(c=0;c<dim;c++)
    	{
    		int idx = (c+cd-1)%dim;
    		if(idx<cd)idx+=1;

    		if(row1[idx]<row2[idx])
    			return true;
    		else if (row1[idx]>row2[idx])
    			return false;
    	}
        return (row1[dim]<row2[dim]);
    }
};


bool inequality(double *row1, double *row2, int cd, int dim)
{
	int c = 0;
    for(c=0;c<dim;c++)
   	{
    	if(row1[(c+cd)%dim]<row2[(c+cd)%dim])
    		return true;
   		else if (row1[(c+cd)%dim]>row2[(c+cd)%dim])
   			return false;
   	} 
   	
   	return (row1[dim]<row2[dim]);
}


node* kdtree (double** points, int ** a, int size, int dim, int depth,node *pare,bool l_or_r)
{
	if(size==1)
	{
		node *an = new node;
	    an->arr = new double[dim];
	    an->min = new double[dim];
	    an->max = new double[dim];
	    an->split_dim=-1;  //leaf node no split
	    
	    for (int i = 0; i < dim; ++i)
	    {
	    	an->arr[i]=points[a[0][0]][i];
	    }

	    if (pare==NULL)
	    {
	    	for (int i = 0; i < dim; ++i)
	    	{
	    		an->max[i]=1;
	    		an->min[i]=0;
	    	}
	    }
	    else
	    {
		    for (int i = 0; i < dim; ++i)
		    {
		    	an->max[i]=pare->max[i];
		    	an->min[i]=pare->min[i];
		    }
		    if (l_or_r==0) 
		    	an->max[pare->split_dim]=pare->arr[pare->split_dim];
		    else		   
		    	an->min[pare->split_dim]=pare->arr[pare->split_dim];
		}
	   return an;
	}
	else if(size==2)
	{
		node *an1 = new node;
	    an1->arr = new double[dim];
	    an1->min = new double[dim];
	    an1->max = new double[dim];
	    
	    an1->split_dim=depth%dim;
		int dts=depth%dim;	    
	    for (int i = 0; i < dim; ++i)
	    {
	    	an1->arr[i]=points[a[0][dts]][i];
	    }

	    if (pare==NULL)
	    {
	    	for (int i = 0; i < dim; ++i)
	    	{
	    		an1->max[i]=1;
	    		an1->min[i]=0;
	    	}
	    }
	    else
	    {
		    for (int i = 0; i < dim; ++i)
		    {
		    	an1->max[i]=pare->max[i];
		    	an1->min[i]=pare->min[i];
		    }
		    if (l_or_r==0) 
		    	an1->max[pare->split_dim]=pare->arr[pare->split_dim];
		    else		   
		    	an1->min[pare->split_dim]=pare->arr[pare->split_dim];
		}

	    node *an2 = new node;
	    an2->arr = new double[dim];
	    an2->min = new double[dim];
	    an2->max = new double[dim];
	    an2->split_dim=-1;  //leaf node no split

	    for (int i = 0; i < dim; ++i)
	    {
	    	an2->arr[i]=points[a[1][dts]][i];
	    }

	    an1->right=an2;

	    for (int i = 0; i < dim; ++i)
	    {
	    	an2->max[i]=an1->max[i];
	    	an2->min[i]=an1->min[i];
	    }
	    an2->min[dts]=an1->arr[dts];
	    return an1;
	}
	else
	{

		int dts=depth%dim;
		int indexmedian = (size%2) ? size/2 : size/2-1;
		double value=points[a[indexmedian][dts]][dts];
		
		//create node with point a[indexmedian][dts]
		node *an = new node;
	    an->arr = new double[dim];
	    an->min = new double[dim];
	    an->max = new double[dim];
	    
	    an->split_dim=dts;  //leaf node no split

	    for (int i = 0; i < dim; ++i)
	    {
	    	an->arr[i]=points[a[indexmedian][dts]][i];
	    }

		int ** left,** right;
		left =new int *[indexmedian];
		right=new int *[size-indexmedian-1];

		for(int i=0;i<indexmedian;i++)
		{
			left[i]=new int[dim];
			
		}
		for(int i=0;i<size-indexmedian-1;i++)
		{
			
			right[i]=new int[dim];
		}

		for (int i = 0; i < dim; i++)
		{
			int f=0,g=0; 
			for (int j = 0; j < size; j++)
			{
				double *tarr = points[a[j][i]];
				double *tarr2 = points[a[indexmedian][dts]];
				if (a[j][i]==a[indexmedian][dts])
				{
					//cout<<"abcd";
				}
				else if (inequality(tarr,tarr2,dts,dim)) //not = different for =
				{
					left[f][i]=a[j][i];
					f++;
				}
				else
				{
					right[g][i]=a[j][i];
					g++;
				}
			}

		}

        if (pare==NULL)
	    {
	    	for (int i = 0; i < dim; ++i)
	    	{
	    		an->max[i]=1;
	    		an->min[i]=0;
	    	}
	    }
	    else
	    {
		    for (int i = 0; i < dim; ++i)
		    {
		    	an->max[i]=pare->max[i];
		    	an->min[i]=pare->min[i];
		    }
		    if (l_or_r==0) 
		    	an->max[pare->split_dim]=pare->arr[pare->split_dim];
		    else		   
		    	an->min[pare->split_dim]=pare->arr[pare->split_dim];
		}

		an->left=kdtree(points,left,indexmedian,dim,depth+1,an,0);
		an->right=kdtree(points,right,size-indexmedian-1,dim,depth+1,an,1);

		return an;
	}
}


int main(int argc, char* argv[])
{
	FILE *fp;

	int ret;

	// char dataset_file[] = argv[1];
	// char dataset_file2[] = "10q.txt";


	fp = fopen(argv[1], "r");

	int dim,num;
	ret = fscanf(fp,"%d %d",&dim,&num);
	//cout<<dim<<" "<<num<<endl;


	double **data, **copy,**points;
	int **sorted;


	data = new double*[num];
	copy = new double*[num];
	sorted = new int*[num];
	points=new double*[num];

	for(int i=0;i<num;i++)
	{
		data[i]=new double[dim+1];
		copy[i]=new double[dim+1];
		sorted[i]=new int[dim];
		points[i]=new double[dim];
	}

	for(int i=0;i<num;i++)
	{
		data[i][0]=i;
		copy[i][0]=i;
		for(int j=1;j<dim+1;j++)
		{
			ret = fscanf(fp,"%lf",&data[i][j]);
			copy[i][j]=data[i][j];
			points[i][j-1]=data[i][j];
		}
	}
	
	fclose(fp);
	free(data);

	for(int i=1;i<dim+1;i++)
	{
		sort(copy,copy+num,compare1(i,dim+1));
		for(int j=0;j<num;j++)
		{
			sorted[j][i-1]=copy[j][0];
		}
	}
	free(copy);

	//clock_t start=clock();
	node* root=kdtree(points,sorted,num,dim,0,NULL,0);
	//clock_t end=clock();
	//cout<<endl<<"total construction time = "<<((end-start)/double(CLOCKS_PER_SEC))<<endl;

	free(points);
	free(sorted);
	cout<<0<<endl;


	string dataset_file2;
	cin>>dataset_file2;


	fp = fopen(dataset_file2.c_str(), "r");
	
	// knearest=100;
	cin>>knearest;

	double **qu;
	int noofqueries;

	ret = fscanf(fp,"%d %d",&dim,&noofqueries);
	//cout<<dim<<endl<<noofqueries<<endl;

	qu=new double *[noofqueries];
	for (int i = 0; i < noofqueries; ++i)
	{
		qu[i]=new double [dim];
	}

	for (int i = 0; i < noofqueries; ++i)
	{
		for (int j = 0; j < dim; ++j)
		{
			ret = fscanf(fp,"%lf",&qu[i][j]);
		}
	}

	fclose(fp);

	//double q[dim] = {0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5};

	char dataset_file3[] = "results.txt";
	
	fp=fopen(dataset_file3, "w+");

	// start=clock();
	d=dim;

	for (int i = 0; i < noofqueries; ++i)
	{
		q=qu[i];
		if(dim<12)
		{
			bfs_algorithm(root,knearest,fp);
		}
		else
		{
			priority_queue <node*, vector<node*>, compare_max> answer_set;
			sequential(root,answer_set);

			double ** ans;
			ans= new double *[knearest];
			int m=0;
	
			while(!answer_set.empty())     //using a for loop may be more efficient with i<k
			{
				node *temp = answer_set.top();
				answer_set.pop();
				ans[m++] = temp->arr;
			}

			for (int i = knearest-1; i >-1; i--)
			{
				for(int j=0;j<d;j++)
				{
					fprintf(fp,"%lf ",ans[i][j]);
				}
				fprintf(fp,"\n");
			}	
		}
	}
	
	// end=clock();
	fclose(fp);
	


	// cout<<endl<<"total query processing time = "<<((end-start)/(double(CLOCKS_PER_SEC)*noofqueries))<<endl;
	cout<<1;
	
	return 0;
}
