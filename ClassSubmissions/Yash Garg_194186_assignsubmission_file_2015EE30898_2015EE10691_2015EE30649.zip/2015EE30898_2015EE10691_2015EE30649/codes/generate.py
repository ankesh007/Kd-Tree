import numpy as np


dims = 1+np.array(range(20))
nums = 100000

for i in dims:
	mat = np.random.uniform(0.0,1.0,(nums,i))
	with open(str(i)+"_dim_data.txt","w+") as out:
		out.write(str(i)+" "+str(nums)+"\n")
		np.savetxt(out, mat, delimiter=" ",fmt='%.20f')


quer = 100

for i in dims:
	mat = np.random.uniform(0.0,1.0,(quer,i))
	with open(str(i)+"_dim_query.txt","w+") as out:
		out.write(str(i)+" "+str(quer)+"\n")
		np.savetxt(out, mat, delimiter=" ",fmt='%.20f')

