#include <iostream>
#include <stdlib.h>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>
#include <ctime>
#include <vector>
#include <string>
#include <fstream>
using namespace std;

double *q;
int d;
int knearest;
double d2ndclose=0,d100close=0;

struct node
{
	double *array;
	double dis;
};

double dist(double arr[])
{
	double edist = 0;
		
	for(int i=0;i<d;i++)
	{
		edist+= pow((q[i]-arr[i]),2);
	}

	edist = sqrt(edist);
	return edist;
}	

bool func (node *a,node *b)
{
	for (int i = 0; i < d; ++i)
	{
		if ( a->array[i] < b->array[i] )
		{
			return true;
		}
		else if (a->array[i] > b->array[i])
		{
			return false;
		}
	}
	return true;
}


class compare_max
{	
public:
	bool operator()(node *a, node *b)
	{
		if ( (a->dis) < (b->dis) )
		{
			return true ;
		}
		else if ( (a->dis) > (b->dis) )
		{
			return false;
		}
		else if ( (a->dis) == (b->dis) )
		{
			return func(a,b);
		}

		   // see for equality -------------------
	}
};


void knn_query(double **data, int n)
{
	priority_queue <node*, vector<node*>, compare_max> answer_set;

	for(int i=0;i<knearest;i++)
	{
		node *temp = new node;
		temp->array = data[i];
		temp->dis = dist(data[i]);
		answer_set.push(temp);
	}

	for(int i=knearest;i<n;i++)
	{
		node *temp = new node;
		temp->array = data[i];
		temp->dis = dist(data[i]);	

		if( temp->dis < answer_set.top()->dis ) // see for equality -------------------
		{
			answer_set.pop();
			answer_set.push(temp);
		}
		else if ( temp->dis == answer_set.top()->dis )
		{
			if ( !func(answer_set.top(),temp))
			{
				answer_set.pop();
				answer_set.push(temp);		
			}
		}
	}
	
	double ** ans;
	ans= new double *[knearest];
	int m=0;
	
	while(!answer_set.empty())     //using a for loop may be more efficient with i<k
	{
		double *temp = answer_set.top()->array;
		answer_set.pop();
		ans[m++] = temp;
		//free(temp);
	}
	
	for (int i = knearest-1; i >-1; i--)
	{
		for(int j=0;j<d;j++)
		{
			cout<<ans[i][j]<<" ";
		}
		cout<<endl;	
	}

	d2ndclose += dist(ans[knearest-2]);
	d100close += dist(ans[knearest-100]);
	return;

}

int main(int argc, char* argv[]) 
{
	char dataset_file[] = "d12.txt";
	freopen(dataset_file, "r", stdin);

	int dim,num;
	cin>>dim>>num;
	cout<<dim<<" "<<num<<endl;


	double **data;
	
	data = new double*[num];

	for(int i=0;i<num;i++)
	{
		data[i]=new double[dim];
	}

	for(int i=0;i<num;i++)
	{
		for(int j=0;j<dim;j++)
		{
			cin>>data[i][j];
		}
	}

	fclose(stdin);
	char dataset_file2[] = "q12.txt";
	freopen(dataset_file2, "r", stdin);
	
	knearest=100;
	
	d=dim;
	double **qu;
	int noofqueries;
	cin>>d;
	cin>>noofqueries;
	qu=new double *[noofqueries];
	for (int i = 0; i < noofqueries; ++i)
	{
		qu[i]=new double [dim];
	}

	for (int i = 0; i < noofqueries; ++i)
	{
		for (int j = 0; j < dim; ++j)
		{
			cin>>qu[i][j];
			//cout<<q[i][j];
		}
	}

	//double q[dim] = {0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5};
	fclose(stdin);
	char dataset_file3[] = "resultsequential.txt";
	freopen(dataset_file3, "w", stdout);
	//cout<<endl<<dim<<endl;
	clock_t start=clock();

	for (int i = 0; i < noofqueries; ++i)
	{
		q=qu[i];
		knn_query(data,num);
	}
	
	clock_t end=clock();
	fclose(stdout);
	freopen("/dev/tty","w",stdout);

	//cout<<"hello";
	cout<<endl<<"total query processing time = "<< (end-start)/(double(CLOCKS_PER_SEC)*noofqueries) <<endl;
	cout<<(d2ndclose/d100close);
	return 0;
}