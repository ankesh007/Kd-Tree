#!/bin/bash
g++ -O2 kdtree.cpp -std=c++11; 
./a.out $1
# python sample.py $1