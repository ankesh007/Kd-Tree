#include <bits/stdc++.h>
using namespace std;
using namespace std::chrono;

#define N 100000
#define d 20
#define K 100

typedef pair<double,int> Foo;

vector<vector<double> > points(N);
vector<vector<double> > query_points(100);

double dis(vector<double> a,vector<double> b)
{
    double ans=0.0;
    for(int i=0;i<d;i++)
        ans+=(a[i]-b[i])*(a[i]-b[i]);
    return sqrt(ans);
}

bool compare(Foo a,Foo b)
{
    if(a.first!=b.first)
        return (a.first<b.first);
    return (points[a.second]<points[b.second]);
}

int main()
{
    default_random_engine generator;
    uniform_real_distribution <double> uniform_dist(0,1);
    cout << fixed << setprecision(10);
    
    int i,j,k;

    for(i=0;i<N;i++)
    {
        points[i].resize(d);
        for(j=0;j<d;j++)
            points[i][j]=uniform_dist(generator);
    }
    for(i=0;i<100;i++)
    {
        query_points[i].resize(d);
        for(j=0;j<d;j++)
            query_points[i][j]=uniform_dist(generator);
    }
    // query_points[0][0]=0;
    // query_points[0][1]=0;
    // query_points[0][2]=0;

    // points[0][0]=1;
    // points[0][1]=0;
    // points[0][2]=0;
    // points[1][0]=0;
    // points[1][1]=1;
    // points[1][2]=0;
    // points[2][0]=0;
    // points[2][1]=0;
    // points[2][2]=1;
    // points[3][0]=-1;
    // points[3][1]=0;
    // points[3][2]=0;
    // points[4][0]=0;
    // points[4][1]=-1;
    // points[4][2]=0;
    // points[5][0]=0;
    // points[5][1]=0;
    // points[5][2]=-1;

    for(i=0;i<1;i++)
    {
        vector <double> v;
        high_resolution_clock::time_point t1 = high_resolution_clock::now();
        // for(j=0;j<N;j++)
        // {
        //     for(k=0;k<d;k++)
        //     {
        //         cout << points[j][k] << " ";
        //     }
        //     cout << dis(query_points[i],points[j]) << endl;
        //     v.push_back(dis(query_points[i],points[j]));
        // }
        priority_queue <Foo,vector<Foo>,function<bool(Foo,Foo)> > pq(compare);
        for(j=0;j<K;j++)
            pq.push({dis(query_points[i],points[j]),j});
        for(;j<N;j++)
        {
            auto temp=pq.top();
            double r=dis(query_points[i],points[j]);
            Foo pp={r,j};
            if(compare(pp,temp))
            {
                pq.pop();
                pq.push(pp);
            }
        }
        while(!pq.empty())
        {
            auto t=pq.top();
            cout << t.first << endl;
            for(auto x:points[t.second])
                cout << x << " ";
            cout << endl;
            pq.pop();
        }
        // sort(v.begin(), v.end());
        // for(auto x:v)
        //     cout << x << " ";
        cout << "queryfinished" << endl;
        high_resolution_clock::time_point t2 = high_resolution_clock::now();
        duration<double> time_span = duration_cast<duration<double>>(t2 - t1);
        cout << "It took me " << time_span.count() << " seconds.\n";
    }
}