#include <bits/stdc++.h>
using namespace std;
using namespace std::chrono;

// #define N 100000
// #define d 20
// #define K 100
int N,N2,d,K;
#define bucket_size 1

int dim=0;
vector<vector<double> > points;              //points[i][j]  i<N j<d
vector<vector<vector<double> > > sorted;              //sorted[k][i][j]  k<d i<N j<d
vector<vector<double> > query_points;

struct node
{
    int level;
    vector <double> median;
    vector<vector<double> > list;                   //list[i][j]    i<N j<d
    // vector <double> sorted_for_each_dimension[d];       //sorted_for_each_dimension[j][i] i<N j<d
    vector<vector <double> > sorted_for_each_dimension;       //sorted_for_each_dimension[j][i] i<N j<d
    
    node *left;
    node *right;
    node *parent;
    node()
    {
        median.resize(d);
        sorted_for_each_dimension.resize(d);
    }
};

typedef pair<double,vector<double> > Foo;
typedef pair<double,node* > Bar;

double dis(vector<double> &a,vector<double> &b)
{
    double ans=0.0;
    for(int i=0;i<d;i++)
        ans+=(a[i]-b[i])*(a[i]-b[i]);
    return sqrt(ans);
}

bool compare(vector <double> &a,vector <double> &b)
{
    return (a[dim]<b[dim]);
}

bool compare_for_heap(const Foo &a,const Foo &b)
{
    if(a.first!=b.first)
        return (a.first<b.first);
    // return (*(a.second) < *(b.second));
    return ((a.second) < (b.second));
}

void constructTree(node *root)
{
    int lev=root->level;

    node *lchild=new node;
    node *rchild=new node;
    root->left=lchild;
    root->right=rchild;
    lchild->parent=root;
    rchild->parent=root;

    //for(int i=0;i<d;i++)
    root->median[lev]=root->sorted_for_each_dimension[lev][(root->list.size())/2];
    // printf("med %f\n",root->median[lev] );

    lchild->level=(lev+1)%d;
    rchild->level=(lev+1)%d;

    lchild->left=NULL;
    lchild->right=NULL;
    rchild->left=NULL;
    rchild->right=NULL;

    
    {
        auto temp=root->list;
        dim=(lev+1)%d;
        //if(temp.size()>0)
        sort(temp.begin(),temp.end(),compare);

        for(int i=0;i<temp.size();i++)
        {
            if(temp[i][lev]<root->median[lev])
            {
                //int lsize=lchild->list.size();
                lchild->list.push_back(temp[i]);
            }
            else if(temp[i][lev]>root->median[lev])
            {
                //int rsize=rchild->list.size();
                rchild->list.push_back(temp[i]);
            }
            else
            {
                root->median=temp[i];
            }
        }
    }

    for(int i=0;i<d;i++)
    {
        vector <double> temp;
        for(int j=0;j<lchild->list.size();j++)
            temp.push_back(lchild->list[j][i]);
        sort(temp.begin(),temp.end());
        lchild->sorted_for_each_dimension[i] = temp;
    }

    for(int i=0;i<d;i++)
    {
        vector <double> temp;
        for(int j=0;j<rchild->list.size();j++)
            temp.push_back(rchild->list[j][i]);
        sort(temp.begin(),temp.end());
        rchild->sorted_for_each_dimension[i] = temp;
    }

    if(lchild->list.size()>bucket_size)
        constructTree(lchild);
    else if(lchild->list.size()==0)
    {
        root->left=NULL;
    }
    if(rchild->list.size()>bucket_size)
        constructTree(rchild);
    else if(rchild->list.size()==0)
    {
        root->right=NULL;
    }
}

void printTree(node *root)
{
    printf("level:%i median:",root->level);
    for(int i=0;i<d;i++)
    {
        printf("%f ",root->median[i]);
    }
    printf("\n");
    for(int i=0;i<root->list.size();i++)
    {
        for(int j=0;j<root->list[i].size();j++)
        {
            printf("%f ",root->list[i][j] );
        }
        printf("\n");
    }
    printf("\n");
    printf("Sorted for each dim\n");
    for(int i=0;i<d;i++)
    {
        printf("dim %i: ",i );
        for(int j=0;j<root->list.size();j++)
        {
            printf("%f ",root->sorted_for_each_dimension[i][j] );
        }
        printf("\n");
    }

    if(root->left!=NULL)
        printTree(root->left);
    if(root->right!=NULL)
        printTree(root->right);
}

double dis_from_MBR(vector <double> &p,node *currNode)
{
    vector <double> delta(d);
    for(int i=0;i<d;i++)
    {
        auto ls=currNode->sorted_for_each_dimension[i];
        double rmin = *ls.begin();
        double rmax = *ls.rbegin();
        if(p[i]<rmin)
            delta[i]=rmin-p[i];
        else if(p[i]>rmax)
            delta[i]=p[i]-rmax;
        else
            delta[i]=0;
    }
    double ans=0;
    for(auto x:delta)
        ans+=x*x;
    return sqrt(ans);
}

int main(int argc, char* argv[])
{
    // default_random_engine generator;
    // uniform_real_distribution <double> uniform_dist(0,1);
    // cout << fixed << setprecision(10);
    char* data = argv[1];
    string dataset_file(data);
    ifstream get_data(dataset_file);
    //edit
    get_data >> d >> N;
    points.resize(N);
    sorted.resize(d);
    
    int i,j,k;
    for(i=0;i<N;i++)
    {
        points[i].resize(d);
        for(j=0;j<d;j++)
        {
            double pt;
            get_data >> pt;
            // points[i][j]=uniform_dist(generator);
            points[i][j]=pt;
        }
    }


    high_resolution_clock::time_point tx = high_resolution_clock::now();
    
    for(i=0;i<d;i++)
    {
        auto temp=points;
        dim=i;
        sort(temp.begin(),temp.end(),compare);
        sorted[i]=temp;
    }
    // for(int i=0;i<d;i++)
    // {
    //     for(int j=0;j<N;j++)
    //     {
    //         for(int k=0;k<d;k++)
    //         {
    //             cout << sorted[i][j][k] << " ";
    //         }
    //         cout << endl;
    //     }
    //     cout << "next\n";
    // }

    node *root=new node;
    root->level = 0;
    root->list = sorted[0];
    for(int i=0;i<d;i++)
    {
        vector <double> temp;
        for(j=0;j<N;j++)
            temp.push_back(sorted[0][j][i]);
        sort(temp.begin(),temp.end());
        root->sorted_for_each_dimension[i] = temp;
    }
    root->parent = NULL;
    constructTree(root);
    // cout << "tree constructed" << endl;
    cout << 0;
    // printTree(root);
    high_resolution_clock::time_point ty = high_resolution_clock::now();
    duration<double> time_span2 = duration_cast<duration<double>>(ty - tx);
    // cout << "It took me " << time_span2.count() << " seconds.\n";

    string query_file;
    cin >> query_file >> K;
    ifstream get_query(query_file);
    get_query >> d >> N2;
    query_points.resize(N2);
    for(i=0;i<N2;i++)
    {
        query_points[i].resize(d);
        for(j=0;j<d;j++)
        {
            double pt;
            get_query >> pt;
            query_points[i][j]=pt;
        }
    }

    double ttt=0;
    ofstream result("results.txt");
    for(i=0;i<N2;i++)
    {
        high_resolution_clock::time_point t1 = high_resolution_clock::now();
        // vector <double> vec;
        // for(j=0;j<N;j++)
        // {
        //     for(k=0;k<d;k++)
        //     {
        //         cout << points[j][k] << " ";
        //     }
        //     cout << dis(query_points[i],points[j]) << endl;
        //     vec.push_back(dis(query_points[i],points[j]));
        // }

        //typedef pair<double,node*> Bar;
        priority_queue <Bar,vector<Bar>,greater<Bar> > candidateSet;
        
        //typedef pair<double,vector<double>* > Foo;
        priority_queue <Foo,vector<Foo>,function<bool(Foo,Foo)> > answerSet(compare_for_heap);
        
        // double temp=dis_from_MBR(query_points[i],root->list);
        double temp=dis_from_MBR(query_points[i],root);
        candidateSet.push({temp,root});
        // bool check=false; // true if top MBR in Candidate is further than the top data point in Answer set

        while(!candidateSet.empty())
        {
            auto candidate_top=candidateSet.top();
            candidateSet.pop();

            node* currNode=candidate_top.second;
            auto currList=currNode->list;
            // vector <double> *v;
            vector <double> currMedian;
            if(currList.size()==1)
                // v = &currList[0];
                currMedian=currList[0];
            else
                // v = &(currNode->median);
                currMedian=currNode->median;
            // currMedian = *v;
            double val=dis(currMedian,query_points[i]);
            // v = &currMedian;
            vector <double> v = currMedian;
                
            if(answerSet.size()!=K)
            {
                answerSet.push({val,v});

                if(currNode->right != NULL)
                    candidateSet.push({dis_from_MBR(query_points[i],currNode->right),currNode->right});
                    // candidateSet.push({dis_from_MBR(query_points[i],currNode->right->list),currNode->right});
                if(currNode->left != NULL)
                    candidateSet.push({dis_from_MBR(query_points[i],currNode->left),currNode->left});
                    // candidateSet.push({dis_from_MBR(query_points[i],currNode->left->list),currNode->left});
                continue;
            }

            bool check = candidate_top.first > answerSet.top().first;
            if(check)
                break;

            if(compare_for_heap({val,v},answerSet.top()))
            {
                answerSet.pop();
                answerSet.push({val,v});
            }

            if(currNode->right != NULL)
            {
                double val2=dis_from_MBR(query_points[i],currNode->right);
                // double val2=dis_from_MBR(query_points[i],currNode->right->list);
                if(val2 <= answerSet.top().first)
                    candidateSet.push({val2,currNode->right});
            }
            if(currNode->left != NULL)
            {
                double val2=dis_from_MBR(query_points[i],currNode->left);
                // double val2=dis_from_MBR(query_points[i],currNode->right->list);
                if(val2 <= answerSet.top().first)
                    candidateSet.push({val2,currNode->left});
            }
        }
        vector <vector <double> > ans;
        while(!answerSet.empty())
        {
            auto t=answerSet.top();
            // cout << t.first << endl;
            ans.push_back(t.second);
            // for(auto x : (t.second))
            //     cout << x << " ";
            // cout << endl;
            answerSet.pop();
        }
        for(auto it=ans.rbegin();it!=ans.rend();it++)
        {
            for(auto x : *it)
                result << x << " ";
            result << endl;
        }
        // sort(vec.begin(), vec.end());
        // for(auto x:vec)
        //     cout << x << " ";
        // cout << "queryfinished" << endl;
        // high_resolution_clock::time_point t2 = high_resolution_clock::now();
        // duration<double> time_span = duration_cast<duration<double>>(t2 - t1);
        // cout << "It took me " << time_span.count() << " seconds.\n";
        // ttt+=time_span.count();
    }
    cout << 1;
    // cout << ttt;
}