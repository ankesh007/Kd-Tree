#!/bin/bash
# g++ sample.cpp; ./a.out $1
# python sample.py $1

g++ -O3 KNN5.cpp;
./a.out $1;