#!/bin/bash
g++ -O2 sample.cpp; ./a.out $1
#python sample.py $1
