# !/bin/bash
c++ -std=c++11 sample.cpp; ./a.out $1
# python sample.py $1