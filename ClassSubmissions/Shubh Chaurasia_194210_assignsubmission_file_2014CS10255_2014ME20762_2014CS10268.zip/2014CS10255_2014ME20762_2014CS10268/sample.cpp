#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <map>
#include <random>
#include <queue>          // std::priority_queue
#include <vector>         // std::vector
#include <functional>     // std::greater
#include <sys/time.h>
#include <chrono>
#include <fstream>

using namespace std;

int k = 2;
const int K = 20;
int k_neigh = 3;
 
// A structure to represent node of kd tree
struct Node
{
    double point[K]; // To store k dimensional point
    int depth;   // depth%k = index of split 
    Node *left, *right, *parent;
};

struct data
{
	Node *node;
	double dis;
	data(Node *gnode, double gdistance)
	{
		node = gnode;
		dis = gdistance;
	}	
	
};
class myComparator
{
public:
    int operator() (const data& p1, const data& p2)
    {
		double dis1 = p1.dis;
		double dis2 = p2.dis;
		if(dis1 == dis2){
			Node *node1 = p1.node;
			Node *node2 = p2.node;
			for(int i = 0; i < K; i++){
				if(node1->point[i] == node2->point[i]){
					continue;
				}else{
					return node1->point[i] < node2->point[i];
				}
			}
			return true;
		}else{
			return p1.dis < p2.dis;
		}
        
    }
};
class Topk {
  public:
    Topk(int k) : k_(k) {}
    void insert(data value) {
		if (q_.size() < k_) q_.push(value);
		else if (value.dis <= q_.top().dis) {
			if(value.dis == q_.top().dis){
				Node *node1 = value.node;
				Node *node2 = q_.top().node;
				bool tell = false;
				for(int i = 0; i < K; i++){
					if(node1->point[i] == node2->point[i]){
						continue;
					}else{
						if(node1->point[i] < node2->point[i]){
							tell = true;
							
						}
						break;
					}
				}
				if(tell){
					q_.pop(); q_.push(value); 
				}
			}else{
				q_.pop(); q_.push(value); 
			}
			
		}
    }
    std::vector<data> finalize() {
      std::vector<data> result;
      while (q_.size()) {
        result.push_back(q_.top());
        q_.pop();
      }
      return result;
    }
    void empty() {   
      while (q_.size()) {
        q_.pop();
      }
      return ;
    }
    void setk(int given_k)
    {
    	k_ = given_k;
    }
 	double best_val()
    {
    	if( q_.size() == 0)
    		return 1000000;
    	return q_.top().dis;
    }
    int len()
    {
    	return q_.size();
    }
  private:
    int k_;
    std::priority_queue<data, vector<data>, myComparator> q_;
};

Topk q(k_neigh);// default 1 nearest neighbour

struct Node* newNode(double point[],int depth, Node* parent )
{
    struct Node* temp = new Node;
 	
    for (int i=0; i<k; i++)
       temp->point[i] = point[i];
    temp -> parent = parent;
   	temp -> depth = depth%k;
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}


struct Local {
    Local(int paramA) { this->paramA = paramA; }
    bool operator () (const vector<double>& v1, const vector<double>& v2) { return v1[paramA] < v2[paramA]; }

    int paramA;
};

void build_tree(vector< std::vector<double> > v, Node *nd, int dim)
{
	if(v.size() == 1)
	{
		for (int i = 0; i < k; ++i)
			nd->point[i] = v[0][i];
		nd->depth = dim;
		return;
	}
	if (v.size()==0)
	{
		nd = NULL;
		return;
	}
	sort(v.begin(), v.end(), Local(dim));
	int l_e, med; 
	l_e = med = v.size()/2;
	while (v[l_e][dim] == v[med][dim])
		--l_e;
	
	for (int i = 0; i < k; ++i)
		nd->point[i] = v[l_e][i];
	nd->depth = dim;
	
	int new_dim = (dim+1)%k;
	vector< std::vector<double> > v_l;
	for (int i = 0; i < l_e; ++i)
		v_l.push_back(v[i]);
	double *init1 = new double[k];
	for (int i=0; i<k; i++)
       init1[i] = 0;
    nd->left = newNode(init1, new_dim, nd);
	build_tree(v_l, nd->left, new_dim);

	vector< std::vector<double> > v_r;
	for (int i = l_e+1; i < v.size(); ++i)
	{
		v_r.push_back(v[i]);
	}
	double *init2 = new double[k];
	for (int i=0; i<k; i++)
       init2[i] = 0;
    nd->right = newNode(init2, new_dim, nd);
	build_tree(v_r, nd->right, new_dim);
}

struct Node* build_bal_tree(vector< std::vector<double> > v)
{
	double *init = new double[k];
	for (int i=0; i<k; i++)
       init[i] = 0;
    Node* root = newNode(init, 0, NULL);
    cout << "Root node created. \n";
    cout << "build_tree function called. \n";
	build_tree(v, root, 0);
	return root;
}


double dist(double *a1 , double *a2){
	double sum = 0;
	// assumed k to be the number of dimension in the point
	// cerr << "dist1" << endl;
	for(int i = 0; i < k; i++){
		double t = a1[i]- a2[i];
		t = t*t;
		sum += t;
	}
	// cerr << "dist2" << endl;

	return sqrt(sum);
}


void insert(Node *root, double point[])
{
	if(root == NULL){
		root = newNode(point,0,NULL);
		return;
	}

	int curr_index = root->depth % k;

	if(point[curr_index] < root->point[curr_index])
	{
		// root->left = insert(root->left,point);
		if(root -> left == NULL)
		{
			root->left = newNode(point,root->depth+1,root);
		}
		else
		{
			insert(root->left, point);
		}
	}else
	{
		// return insert(root->right,point);
		if(root -> right == NULL)
		{
			root->right = newNode(point,root->depth+1,root);
		}
		else
		{
			insert(root->right, point);
		}	
	}
	return ;
}

bool equalpoints(double point1[],double point2[])
{

	// cerr<<"eq called"<<endl;
	for (int i = 0; i < k; i++)
	{
		/* code */
		if(point1[i] != point2[i])
			return false;
	}
	return true;
}

int cnt = 0;
// search function returns ture if point is present in the tree
bool search(Node *root, double point[])
{
	int curr_index = root->depth;
	cerr << cnt <<" "<<  curr_index <<endl;
	cnt++;
	if(root == NULL)
		return false;
	if(equalpoints(root->point,point))
		return true;
	if( point[curr_index] < root->point[curr_index])
	{
		return search(root->left,point);
	}
	return search(root -> right, point);
}

int max_depth(Node *root){
	if (root == NULL)
		return 0;
	return 1 + max( max_depth(root->left), max_depth(root->right)); 

}


struct Node* search_leaf(Node *root, double point[])
{
	if(root == NULL)
		return NULL;
	Node *curr_node = root;
	int curr_index = curr_node->depth;
	Node *next_node = NULL;
	if(equalpoints(curr_node->point,point))  //buggy step
		return curr_node;

	if( point[curr_index] < root->point[curr_index])
	{
		next_node = curr_node -> left;
	}else
	{
		next_node = curr_node -> right;
	}
	while(next_node)
	{
		curr_node = next_node;
		curr_index = curr_node->depth;
		if(equalpoints(curr_node->point,point))  //buggy step
			return curr_node;
		if( point[curr_index] < root->point[curr_index])
		{
			next_node = curr_node -> left;
		}else
		{
			next_node = curr_node -> right;
		}
	}
	return curr_node;
}




void kNN(Node *curr_node,double point[])
{
	// q.setk(given_k);
	if ( curr_node == NULL)
		return;
	//cerr << "kNN1" << endl;
	double curr_dist = dist(curr_node->point,point);
	if(curr_dist <= q.best_val())
	{
	//	cerr << "kNN12" << endl;
		data d(curr_node,curr_dist);
	//	cerr << "kNN12" << endl;
		q.insert(d);
	//	cerr << "kNN13" << endl;
	}
	// cerr << "kNN2" << endl;
	int curr_index = curr_node->depth;
	bool left = true;
	if( point[curr_index] < curr_node->point[curr_index])
		kNN(curr_node->left,point);
	else
	{
		kNN(curr_node->right,point);
		left = false;
	}
	//cerr << "kNN3" << endl;
	// k is number of 
	if( (q.len() < k_neigh) || ( abs(point[curr_index] - curr_node->point[curr_index]) < q.best_val() ) )
	{
		if(left)
			kNN(curr_node->right,point);
		else
			kNN(curr_node->left,point);
	}
	// cerr << "kNN4" << endl;
	return;
}


int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];
	char* ar1 = argv[2];
	char* ar2 = argv[3];

	ifstream fi(dataset_file);
	int N;//number of data points
	fi >> k >> N;
	//cout << k << N << endl;
	double *dpoints[N];
	for(int i = 0; i<N; i++)
	{
		//dpoints[i] = new double[k];

		dpoints[i] = (double *) malloc( sizeof(double) * k);
		for(int j = 0; j<k; j++)
			fi >> dpoints[i][j];
		//cout << " train file done"<<endl;
	}
	fi.close();

	Node *Root = newNode(dpoints[0],0,NULL);
	for(int i = 1; i<N;i++)
	{
		insert(Root,dpoints[i]);

	}


	// vector< std::vector<double> > points1;
	// for(int i = 0; i<100000; i++)
	// {
	// 	vector<double> v;
	// 	for(int j = 0; j<k; j++)
	// 	{
	// 		// v.push_back((double)rand()/(double)RAND_MAX);
	// 		v.push_back(dpoints[i][j]);
	// 	}
	// 	points1.push_back(v);	
	// }
	// Node *root1 = build_bal_tree(points1);
	// cout << "Max Depth is - " << max_depth(root1) << '\n';



	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	cin >> query_file >> k_neigh;
	ifstream fii(query_file);
	int Nt;
	fii >> k >> Nt;
	double *tpoints [Nt];
	for(int i = 0; i<Nt;i++)
	{
		tpoints[i] = (double *) malloc( sizeof(double) * k);
		for(int j = 0;j<k;j++)
		{
			fii>>tpoints[i][j];
		}
	}
	fii.close();
	// k_neigh = 100;
	q.setk(k_neigh);


	ofstream outf("results.txt");
	int start = clock();
    auto begin = chrono::high_resolution_clock::now();
    for (int i = 0; i < Nt; i++)
    {
    	/* code */
    	q.empty();
    	kNN(Root,tpoints[i]);
    	vector<data> kl = q.finalize();
    	for(int i1  = k_neigh-1; i1>= 0; i1--)
		{
			for(int j= 0 ; j<k;j++)
				outf<< kl[i1].node->point[j]<<" ";
			outf <<endl;
		}
    }
    outf.close();
    cout << 1 << endl;
    return 0;
    // exit the program


    int en1d = clock();
    double t_ta = (en1d - start)/double (CLOCKS_PER_SEC)*1000;
    
    // cout << " test3"<<endl;
	auto end = chrono::high_resolution_clock::now();  
	auto dur = end - begin;
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(dur).count();
	cerr << "time taken "<< ms <<endl;
	cerr << "time taken - nilaksh "<< t_ta <<endl;


	// sequential
	q.empty();
	double d;
	ofstream outf1("res_seq.txt");

	double sec_sum = 0;
	double hsum = 0;
	begin = chrono::high_resolution_clock::now();
	for( int j = 0; j < Nt; j++)
	{
		for(int i = 0; i<N;i++)
		{
			d = dist(tpoints[j],dpoints[i]);
			Node *n = newNode(dpoints[i],0,NULL);
			data d1 = data(n,d);
			q.insert(d1);

		}
		vector<data> kl = q.finalize();
		sec_sum += kl[98].dis;
		hsum += kl[1].dis;

    	for(int i1  = k_neigh-1; i1>= 0; i1--)
		{
			for(int j= 0 ; j<k;j++)
				outf1<< kl[i1].node->point[j]<<" ";
			outf1 <<endl;
		}
	}
	cerr << "sec_sum " << sec_sum/Nt<<endl;
	cerr <<" hsum "   << hsum/Nt <<endl;
	end = chrono::high_resolution_clock::now();  
	dur = end - begin;
    ms = std::chrono::duration_cast<std::chrono::milliseconds>(dur).count();
	cerr << "time taken "<< ms <<endl;
	outf1.close();

	cerr<<"root index "<< Root->depth << " max_depth " << max_depth(Root)<< endl;
	cerr << dataset_file << " " << query_file << " " << k << endl;




	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	
}
