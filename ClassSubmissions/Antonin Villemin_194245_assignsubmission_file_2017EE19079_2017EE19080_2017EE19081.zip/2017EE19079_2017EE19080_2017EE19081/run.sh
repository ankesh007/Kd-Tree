#!/bin/bash

javac OpenQueryFile.java
java -Xss1024m OpenQueryFile $1