

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class data_creation  {
	public static void main(String args[]) throws IOException
	{
		BufferedWriter br=new BufferedWriter(new FileWriter("dataset_file"));
		int n=100000,d=20;
		String s;
		Random r=new Random();
		br.write("20 100000");
		br.newLine();
		for(int i=0;i<n;i++)
		{
			s=((Double)r.nextDouble()).toString();
			for(int j=1;j<d;j++)
			{
				s=s+" "+((Double)r.nextDouble()).toString();
			}
			br.write(s);
			br.newLine();
		}
		br.close();
	}
}
