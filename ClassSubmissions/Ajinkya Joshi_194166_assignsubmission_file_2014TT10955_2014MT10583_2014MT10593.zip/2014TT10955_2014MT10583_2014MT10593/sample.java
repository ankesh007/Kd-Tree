import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;


 class Node {
	int level;
	Double vp;
	Double data[];
	Double min[],max[];
	boolean leaf;
	Node left,right;
	public Node(int l,int d)
	{
		leaf=false;
		level=l;
		left=null;
		right=null;
		min=new Double[d];
		max=new Double[d];
	}
	void leaf(int d)
	{
		data=new Double[d];
	}
	
}

public class sample implements Comparator<ArrayList<Double>>{
	public sample(){}
	public sample(int dd)
	{
		d=dd;
	}
	static int level,d;
	public int compare(ArrayList<Double> arg0, ArrayList<Double> arg1) {
		//System.out.println(d+" "+level);
		//System.out.println(level%d);
		if(arg0.get(level%d)<arg1.get(level%d))
		return -1;
		if(arg0.get(level%d)>arg1.get(level%d))
			return 1;
		return 0;
	}
	void check(Node node)
	{
		if(node==null)
			return;
		if(node.left==null||node.right==null)
			{System.out.println(node.level);}
		check(node.left);
		check(node.right);
	}
	
	void create(Node node,ArrayList<Double> list[],int l,int dim)
	{
		d=dim;
		level=l;
		//System.out.println(level
		//System.out.println(d+" "+level);
		if(list.length==1)
		{
			node.leaf=true;
			node.leaf(dim);
			for(int j=0;j<d;j++)
				node.data[j]=list[0].get(j);
			return;
		}
		Arrays.sort(list,new sample());
		ArrayList<Double> l1[],l2[];
		int a,b;
		a=list.length/2;
		b=list.length-(list.length/2);
		l1=new ArrayList[a];
		l2=new ArrayList[b];
		for(int i=0;i<a;i++)
		{
			l1[i]=new ArrayList<Double>();
			for(int j=0;j<d;j++)
				l1[i].add(list[i].get(j));
		}
		int k=0;
		for(int i=a;i<list.length;i++)
		{
			l2[k]=new ArrayList<Double>();
			for(int j=0;j<d;j++)
			{
				l2[k].add(list[i].get(j));
			}
			k++;
		}
		node.vp=list[a].get(l%d);
		list=null;
		node.left =new Node(l+1,d);
		for(int i=0;i<d;i++)
		{
			node.left.min[i]=node.min[i];
			node.left.max[i]=node.max[i];
		}
		node.left.max[l%d]=node.vp;
		create(node.left,l1,l+1,d);
		
		node.right =new Node(l+1,d);
		for(int i=0;i<d;i++)
		{
			node.right.min[i]=node.min[i];
			node.right.max[i]=node.max[i];
		}
		node.right.min[l%d]=node.vp;
		create(node.right,l2,l+1,d);
	}
	Double mbrdist(Node o1,Double[] q)
	{
		Double t1=0.0;
		for(int i=0;i<q.length;i++)
		{
			if(q[i]<o1.min[i])
				t1=t1+(o1.min[i]-q[i])*(o1.min[i]-q[i]);
			else if(q[i]>o1.max[i])
				t1=t1+(q[i]-o1.max[i])*(q[i]-o1.max[i]);
		}
			return t1;
	}
	Double pointdist(Double[] o1,Double[] q)
	{
		 Double t1=0.0;
         for(int i=0;i<q.length;i++)
         {
         	t1=t1+(o1[i]-q[i])*(o1[i]-q[i]);
         }
         return t1;
	}
	ArrayList<Double>[] kNN(Node node, final Double[] q, int k, final int dd) {
		PriorityQueue<Double[]> ansheap=new PriorityQueue<Double[]>(k,new Comparator<Double[]>() {
	        public int compare(Double[] o1, Double[] o2) {
	            Double t1=0.0,t2=0.0;
	            for(int i=0;i<dd;i++)
	            {
	            	t1=t1+(o1[i]-q[i])*(o1[i]-q[i]);
	            	t2=t2+(o2[i]-q[i])*(o2[i]-q[i]);
	            }
	            if(t2-t1<0)
	            	return -1;
	            if(t2-t1>0)
	            	return 1;
	            for(int i=0;i<dd;i++)
	            {
	            	if(o2[i]<o1[i])
	            		return -1;
	            	if(o2[i]>o1[i])
	            		return 1;
	            }
	            return 0;
	        }
		});
		PriorityQueue<Node> cand=new PriorityQueue<Node>(20,new Comparator<Node>(){
			public int compare(Node o1,Node o2)
			{
				Double t1=0.0,t2=0.0;
				for(int i=0;i<dd;i++)
				{
					if(q[i]<o1.min[i])
						t1=t1+(o1.min[i]-q[i])*(o1.min[i]-q[i]);
					else if(q[i]>o1.max[i])
						t1=t1+(q[i]-o1.max[i])*(q[i]-o1.max[i]);
					if(q[i]<o2.min[i])
						t2=t2+(o2.min[i]-q[i])*(o2.min[i]-q[i]);
					else if(q[i]>o2.max[i])
						t2=t2+(q[i]-o2.max[i])*(q[i]-o2.max[i]);
				}
				if(t1-t2<0)
					return -1;
				if(t1-t2>0)
					return 1;
				return 0;
			}
		});
		cand.add(node);
		for(int i=0;i<k;i++)
		{
			Double[] temp=new Double[dd];
			for(int j=0;j<dd;j++)
				temp[j]=10.0;
			ansheap.add(temp);
		}
		
		
		Node n;
		while(!cand.isEmpty())
		{
			n=cand.remove();
			if(mbrdist(n,q)>pointdist(ansheap.peek(),q))
				break;
			if(n.leaf==true){
			if(pointdist(n.data,q)<=pointdist(ansheap.peek(),q))
			{
				ansheap.add(n.data);
				ansheap.remove();
			}
			continue;
			}
			if(mbrdist(n.left,q)<=pointdist(ansheap.peek(),q))
				cand.add(n.left);
			if(mbrdist(n.right,q)<=pointdist(ansheap.peek(),q))
				cand.add(n.right);
		}
		ArrayList<Double> ans[]=new ArrayList[k];
		for(int i=0;i<k;i++)
		{
			Double[] te=ansheap.remove();
			ans[i]=new ArrayList<Double>();
			for(int j=0;j<dd;j++)
			{
				ans[i].add(te[j]);
			}
		}
		return ans;
	}
	

	public static void main(String args[]) throws IOException
	{
		int d,n;
		String dataset_file = args[0];
		BufferedReader br;
		
		//Construction of K-d Tree
		
		br=new BufferedReader(new FileReader(dataset_file));
		String st=br.readLine(),s[];
		d=Integer.parseInt((st.split(" "))[0]);
		n=Integer.parseInt((st.split(" "))[1]);
		ArrayList<Double> list[]=new ArrayList[n];
		for(int i=0;i<n;i++)
		{
			list[i]=new ArrayList<Double>();
			st=br.readLine();
			s=st.split(" ");
			for(int j=0;j<d;j++)
			{
				list[i].add(Double.parseDouble(s[j]));
			}
		}
		Node root=new Node(0,d);
		for(int i=0;i<d;i++)
		{
			root.min[i]=0.0;
			root.max[i]=1.0;
		}
		sample ss=new sample(d);
		ss.create(root,list,0,d);
		list=null;
		//ss.check(root);
		
		
		// Request name/path of query_file from parent by just sending "0" on stdout
		System.out.println(0);

		// Wait till the parent responds with name/path of query_file and k | Timer will start now
		String query_file;
		int k;
		br = new BufferedReader(new InputStreamReader(System.in));
		query_file=br.readLine();
		k=Integer.parseInt(br.readLine());
		br=new BufferedReader(new FileReader(query_file));
		String rs=br.readLine();
		int dd=Integer.parseInt((rs.split(" "))[0]);
		int n2=Integer.parseInt((rs.split(" "))[1]);
		Double q[]=new Double[dd];
		BufferedWriter b=new BufferedWriter(new FileWriter("results.txt"));
		for(int qq=0;qq<n2;qq++){
		st=br.readLine();
		s=st.split(" ");
		for(int j=0;j<dd;j++)
		{
			q[j]=Double.parseDouble(s[j]);
		}
		
		
		// cerr << dataset_file << " " << query_file << " " << k << endl;

		// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt
		
		ArrayList<Double> ans[]=ss.kNN(root,q,k,dd);
		for(int i=k-1;i>=0;i--)
		{
			st=Double.toString(ans[i].get(0));
			for(int j=1;j<dd;j++)
			{
				st=st+" "+ans[i].get(j);
			}
			b.write(st);
			b.newLine();
		}
		}
		// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
		br.close();
		b.close();
		System.out.println(1);
	}
	


}
