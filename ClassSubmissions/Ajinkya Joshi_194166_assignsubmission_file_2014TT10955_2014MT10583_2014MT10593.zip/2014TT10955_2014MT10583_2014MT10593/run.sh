#!/bin/bash
# g++ sample.cpp; ./a.out $1
javac sample.java
java -cp . sample $1