

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;



public class sampleS{
	static int dim;
	static Double pointdist(Double[] o1,Double[] q)
	{
		 Double t1=0.0;
         for(int i=0;i<dim;i++)
         {
         	t1=t1+(o1[i]-q[i])*(o1[i]-q[i]);
         }
         return t1;
	}
	static Double pointdistl(ArrayList<Double> o1,Double[] q)
	{
		 Double t1=0.0;
         for(int i=0;i<dim;i++)
         {
         	t1=t1+(o1.get(i)-q[i])*(o1.get(i)-q[i]);
         }
         return t1;
	}
	void setdim(int d)
	{
		dim=d;
	}
	public static void main(String args[]) throws IOException
	{
		final int d;
		int n;
		String dataset_file = args[0];
		BufferedReader br;
		
		//Construction of K-d Tree
		
		br=new BufferedReader(new FileReader(dataset_file));
		String st=br.readLine(),s[];
		d=Integer.parseInt((st.split(" "))[0]);
		dim=d;
		n=Integer.parseInt((st.split(" "))[1]);
		ArrayList<Double> list[]=new ArrayList[n];
		for(int i=0;i<n;i++)
		{
			list[i]=new ArrayList<Double>();
			st=br.readLine();
			s=st.split(" ");
			for(int j=0;j<d;j++)
			{
				list[i].add(Double.parseDouble(s[j]));
			}
		}
		
		
		
		// Request name/path of query_file from parent by just sending "0" on stdout
		System.out.println(0);
		
		// Wait till the parent responds with name/path of query_file and k | Timer will start now
		String query_file;
		int k;
		br = new BufferedReader(new InputStreamReader(System.in));
		query_file=br.readLine();
		k=Integer.parseInt(br.readLine());
		br=new BufferedReader(new FileReader(query_file));
		String rs=br.readLine();
		int dd=Integer.parseInt((rs.split(" "))[0]);
		int n2=Integer.parseInt((rs.split(" "))[1]);
		final Double q[]=new Double[dd];
		BufferedWriter b=new BufferedWriter(new FileWriter("results.txt"));
		for(int qq=0;qq<n2;qq++){
		st=br.readLine();
		s=st.split(" ");
		for(int j=0;j<d;j++)
		{
			q[j]=Double.parseDouble(s[j]);
		}
		
		// cerr << dataset_file << " " << query_file << " " << k << endl;
		
		PriorityQueue<Double[]> ansheap=new PriorityQueue<Double[]>(k,new Comparator<Double[]>() {
	        public int compare(Double[] o1, Double[] o2) {
	            Double t1=0.0,t2=0.0;
	            for(int i=0;i<d;i++)
	            {
	            	t1=t1+(o1[i]-q[i])*(o1[i]-q[i]);
	            	t2=t2+(o2[i]-q[i])*(o2[i]-q[i]);
	            }
	            if(t2-t1<0)
	            	return -1;
	            if(t2-t1>0)
	            	return 1;
	            for(int i=0;i<d;i++)
	            {
	            	if(o2[i]<o1[i])
	            		return -1;
	            	if(o2[i]>o1[i])
	            		return 1;
	            }
	            return 0;
	        }
		});

		// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt
		
		ArrayList<Double> ans[]=new ArrayList[k];
		for(int i=0;i<k;i++)
		{
			Double[] temp=new Double[dd];
			for(int j=0;j<dd;j++)
				temp[j]=10.0;
			ansheap.add(temp);
		}
		for(int i=0;i<n;i++)
		{
			if(pointdistl(list[i],q)<=pointdist(q,ansheap.peek()))
			{
				
				Double[] te=new Double[d];
				for(int j=0;j<dd;j++)
				{
					te[j]=list[i].get(j);
				}
				ansheap.add(te);
				ansheap.remove();
			}
		}
		for(int i=0;i<k;i++)
		{
			Double[] te=ansheap.remove();
			ans[i]=new ArrayList<Double>();
			for(int j=0;j<dd;j++)
			{
				ans[i].add(te[j]);
			}
		}
		for(int i=k-1;i>=0;i--)
		{
			st=Double.toString(ans[i].get(0));
			for(int j=1;j<dd;j++)
			{
				st=st+" "+ans[i].get(j);
			}
			b.write(st);
			b.newLine();
		}
		}
		// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
		br.close();
		b.close();
		System.out.println(1);
	}
	


}
