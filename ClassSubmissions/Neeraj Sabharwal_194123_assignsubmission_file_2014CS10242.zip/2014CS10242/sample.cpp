#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <vector>
#include <fstream>
#include <string>
#include <random>
#include <algorithm>
#include <limits>
#include <iomanip>

using namespace std;

int dimension;

struct points{
	double *coordinates;
};

struct points *data_set;

struct points *query_set;

struct k_d_node{
	struct k_d_node *left, *right;
	double *x;
	double *min_mbr;
	double *max_mbr;
	double query_point_dis;
};

double distance(int dimension,struct k_d_node *first,struct k_d_node *second){

	double ans = 0.0;

	for (int i=0;i<dimension;i++){
		ans += (first->x[i]-second->x[i])*(first->x[i]-second->x[i]);
	}

	return sqrt(ans);

}

double distance_mbr(double * min_mbr_rec, double * max_mbr_rec, double * p)
{
	double s_temp = 0.0;
	for (int i = 0; i < dimension; i++)
	{
		if(p[i]>max_mbr_rec[i] || p[i]<min_mbr_rec[i])
		{
			double temp = min(abs(p[i]-max_mbr_rec[i]),abs(p[i]-min_mbr_rec[i]));
			s_temp = s_temp + temp*temp;
			// cout<<"here "<< s_temp<<endl;
		}
		// cout<<"here2 "<< s_temp<<endl;
/* code */
	}
  
	double temp_dis = sqrt(s_temp);
	// cout<<temp_dis<<"   distance   "<<dimension<<endl;
	return temp_dis;

}

double dist(int dimension,struct points first,struct points second){

	double ans = 0.0;

	for (int i=0;i<dimension;i++){
		ans += (first.coordinates[i]-second.coordinates[i])*(first.coordinates[i]-second.coordinates[i]);
	}

	return sqrt(ans);

}

struct heap_find{
	double distance;
	double *coordinates;
};

struct compare_fn_mbr{
	bool operator()(struct k_d_node * a,struct k_d_node * b) {
	    return (a->query_point_dis)<(b->query_point_dis);
	}
};

struct compare_fn{
	bool operator()(struct heap_find a,struct heap_find b) {
	    return a.distance<b.distance;
	}	
};

void fill_data(int dimension){

	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_real_distribution<> dis(0.0, 1.0);
	// data_set = (struct points *)malloc(100000* dimension * sizeof(double));
	for (int n = 0; n < 100000; n++) {
		data_set[n].coordinates = (double *)malloc(dimension * sizeof(double));
		for (int j = 0; j < dimension; j++){
			data_set[n].coordinates[j] = dis(gen);
		}
	}
}

vector<struct heap_find> our_fn(struct points a,int k, int data_s){

	vector<struct heap_find> ans = {};

	make_heap(ans.begin(), ans.end(),compare_fn());	

	double distnce = 0.0;
	struct heap_find o;

	o.coordinates = (double *)malloc(sizeof(double)*dimension);

	// cout << "q_x" << a.coordinates[0] << endl;
	// cout << "q_y" << a.coordinates[1] << endl;

	for(int i=0;i<data_s;i++){

		// cout << "d_x" << data_set[i].coordinates[0] << endl;
		// cout << "d_y" << data_set[i].coordinates[1] << endl;

		distnce = dist(dimension,a,data_set[i]);
		o.distance = distnce;
		// cout << "w " << distnce << endl;
		o.coordinates = data_set[i].coordinates;
		// if (distnce == 0.0){
		// 	continue;
		// }
		if (ans.size()<k){
		    ans.push_back(o);
			push_heap (ans.begin(),ans.end(),compare_fn());
		}
		else{
			if (ans.front().distance > distnce){
				pop_heap(ans.begin(),ans.end(),compare_fn());
				ans.pop_back();
			    ans.push_back(o);
				push_heap (ans.begin(),ans.end(),compare_fn());
			}
		}
	}

	sort(ans.begin(), ans.end(),compare_fn());

	return ans;

	// for(int i=0;i<10;i++){
	// 	cout << ans[i].distance << endl;
	// 	cout << " " << endl;
	// }

}


struct points * give_sorted_points (struct points *data , int dim , int len){  // pass 'dim' as actual dimension -1 
	// cout << "here8  " << len << endl;
	struct points * sorted_data = (struct points *)malloc(len*sizeof(struct points));

	double tmp_dim [len] ;
	int indices [len] ;

	for (int i=0 ; i < len ; i++)
	{
		tmp_dim[i] = data[i].coordinates[dim] ;
		indices[i] = i ;
	}

	for (int i=0 ; i< len ; i++)
	{
		double min = tmp_dim[i];
		int indx = i ; 

		for (int j= i+1 ; j<len ;j++)
		{
			if (tmp_dim[j] < min)
			{
				min = tmp_dim[j];
				indx = j ;
			}
		}

		tmp_dim[indx] = tmp_dim[i];
		tmp_dim [i] = min ;

		int tmp = indices[indx] ;
		indices[indx] = indices[i] ;
		indices[i] = tmp ; 
	}

	// cout << "here9  " << len << endl;

	for (int i = 0; i < len; i++)
	{
		sorted_data[i].coordinates = (double *)malloc(dimension*sizeof(double));
		for (int j = 0; j < dimension; j++)
		{
			sorted_data[i].coordinates[j] = data[indices[i]].coordinates[j];
		}
	}

		// cout << "here10  " << len << endl;

	return sorted_data ; 
		
}

double * give_min_mbr(double * min_mbr_left, double * min_mbr_right, double * p)
{
	// cout << "here11  " << endl;
	double * temp_min_mbr;
	temp_min_mbr = (double *)malloc(dimension*sizeof(double));
	for (int i = 0; i < dimension; i++)
	{
		// cout << "here1 " << endl;
		// cout << min_mbr_right[i] << endl;
		// cout << min_mbr_left[i] << endl;
		// cout << p[i] << endl;
		temp_min_mbr[i] = min(min(p[i],min_mbr_right[i]),min_mbr_left[i]);
		// cout << "here2 " << endl;
		/* code */
	}

	// cout << "here12  " << endl;
	
	return temp_min_mbr;
}

double * give_max_mbr(double * max_mbr_left, double * max_mbr_right, double * p)
{
	double * temp_max_mbr;
	temp_max_mbr = (double *)malloc(dimension*sizeof(double));
	for (int i = 0; i < dimension; i++)
	{
		temp_max_mbr[i] = max(max(p[i],max_mbr_right[i]),max_mbr_left[i]);
		/* code */
	}
	return temp_max_mbr;
}

double * give_min_mbr_dup(double * min_mbr_left, double * p)
{
	double * temp_min_mbr;
	temp_min_mbr = (double *)malloc(dimension*sizeof(double));
	for (int i = 0; i < dimension; i++)
	{
		temp_min_mbr[i] = min(p[i],min_mbr_left[i]);
		/* code */
	}
	return temp_min_mbr;
}

double * give_max_mbr_dup(double * max_mbr_left, double * p)
{
	double * temp_max_mbr;
	temp_max_mbr = (double *)malloc(dimension*sizeof(double));
	for (int i = 0; i < dimension; i++)
	{
		temp_max_mbr[i] = max(p[i],max_mbr_left[i]);
		/* code */
	}
	return temp_max_mbr;
}


struct k_d_node *generate_tree(struct points *data, int level, int dimen, int leng)
{
	// cout << "here1  " << leng << endl;
	if(leng == 1)
	{
 		struct k_d_node * new_node = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
		new_node->left = NULL;
		new_node->right = NULL;
		new_node->x = (double *)malloc(dimension*sizeof(double));
		new_node->x = data[0].coordinates;
		new_node->min_mbr = (double *)malloc(dimension*sizeof(double));
		new_node->min_mbr = data[0].coordinates;
		new_node->max_mbr = (double *)malloc(dimension*sizeof(double));
		new_node->max_mbr =	data[0].coordinates;
		new_node->query_point_dis = 10000.0;
		// cout << "here  " << new_node->x[0] << endl;
		// cout << "here  " << new_node->min_mbr[0] << endl;
		return new_node;
	}

	// cout << "here2  " << leng << endl;
	
	int curr_dim = level%dimen;
	struct points * sorted_points = (struct points *)malloc(leng*sizeof(struct points));
	sorted_points = give_sorted_points(data,curr_dim,leng);
	// cout << "here3 " << leng << endl;
	struct k_d_node * new_node = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
	new_node->x = sorted_points[leng/2].coordinates;
	struct points * first_half_sorted_points = (struct points *)malloc(leng/2*sizeof(struct points));
	struct points * second_half_sorted_points = (struct points *)malloc((leng/2)*sizeof(struct points));;

	for (int i = 0; i < leng/2; i++)
	{
		first_half_sorted_points[i].coordinates = (double *)malloc(dimension * sizeof(double));
		for (int j = 0; j < dimen; j++)
		{
			first_half_sorted_points[i].coordinates[j] = sorted_points[i].coordinates[j];
		}
	}
	// cout << "here4  " << leng << endl;
	new_node->left = generate_tree(first_half_sorted_points,level+1,dimen,leng/2);
	// cout << "here5  " << leng << endl;

	if (leng == 2)
	{
		new_node->right = NULL;
		new_node->min_mbr = give_min_mbr_dup(new_node->x,new_node->left->min_mbr);
		new_node->max_mbr = give_max_mbr_dup(new_node->x,new_node->left->max_mbr);
		new_node->query_point_dis = 10000.0;
		return new_node;
	}

	if(leng != 2)
	{
		int k;
		k = 0;
		for (int i = leng/2 + 1; i < leng; i++)
		{
			second_half_sorted_points[k].coordinates = (double *)malloc(dimension * sizeof(double));
			for (int j = 0; j < dimen; j++)
			{
				second_half_sorted_points[k].coordinates[j] = sorted_points[i].coordinates[j];
			}
			k++;
		}
		// cout << "here6  " << leng << endl;
		new_node->right = generate_tree(second_half_sorted_points,level+1,dimen,k);	
		// cout << "here7  " << leng << endl;
	}
	// cout << "here8  " << leng << endl;
	// cout << new_node->left->x[0] << endl;
	// cout << new_node->left->min_mbr[0] << endl;
	new_node->min_mbr = give_min_mbr(new_node->x,new_node->right->min_mbr,new_node->left->min_mbr);
	// cout << "here9  " << leng << endl;
	new_node->max_mbr = give_max_mbr(new_node->x,new_node->right->max_mbr,new_node->left->max_mbr);
	new_node->query_point_dis = 10000.0;
	// distance_mbr((new_node->min_mbr),(new_node->max_mbr),query_point);
	// cout << "here10  " << leng << endl;
	return new_node;
}

vector<struct heap_find> knn_bfs(struct k_d_node * main_n, int nn, double * query_p, int knn_size)
{
	int k = nn;
	double temp_distance=0.0;
	temp_distance = distance_mbr(main_n->min_mbr,main_n->max_mbr,query_p);
	// cout<<"main_nnnnnn  "<< temp_distance<<endl;

	main_n->query_point_dis = temp_distance;
	// cout<<"main_nnn  "<< temp_distance<<endl;

	vector<struct k_d_node * > mbr_heap = {};
	//compare_fn_mbr()

	mbr_heap.push_back(main_n);
	make_heap(mbr_heap.begin(), mbr_heap.end(),compare_fn_mbr());

	vector<struct heap_find> ans_set = {};

	make_heap(ans_set.begin(), ans_set.end(),compare_fn());

	while(mbr_heap.size() != 0)
	{
		struct k_d_node * best_node_from_mbr_heap = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
		best_node_from_mbr_heap = mbr_heap.front();
		// cout<<"best_node_from_mbr_heap  "<< best_node_from_mbr_heap->query_point_dis<<endl;
		struct k_d_node * left_mbr = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
		struct k_d_node * right_mbr = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
		left_mbr = best_node_from_mbr_heap->left;
		right_mbr = best_node_from_mbr_heap->right;

		if(ans_set.size() < k)
		{
			pop_heap(mbr_heap.begin(),mbr_heap.end(),compare_fn_mbr());
			mbr_heap.pop_back();

			struct heap_find popped_head;// = (struct heap_find)malloc(sizeof(struct heap_find));

			// cout << best_node_from_mbr_heap->query_point_dis << endl;

			popped_head.distance = best_node_from_mbr_heap->query_point_dis;
			popped_head.coordinates = (double *)malloc(sizeof(double)*dimension);
			popped_head.coordinates = best_node_from_mbr_heap->x;
			// cout << popped_head.distance << endl;
			ans_set.push_back(popped_head);
			push_heap (ans_set.begin(),ans_set.end(),compare_fn());
			if(left_mbr != NULL)
			{
				double temp_distance1 = distance_mbr(left_mbr->min_mbr,left_mbr->max_mbr,query_p);
				left_mbr->query_point_dis = temp_distance1;
				mbr_heap.push_back(left_mbr);
				push_heap (mbr_heap.begin(),mbr_heap.end(),compare_fn_mbr());
			}
			if(right_mbr != NULL)
			{
				double temp_distance2 = distance_mbr(right_mbr->min_mbr,right_mbr->max_mbr,query_p);
				right_mbr->query_point_dis = temp_distance2;
				mbr_heap.push_back(right_mbr);
				push_heap (mbr_heap.begin(),mbr_heap.end(),compare_fn_mbr());
			}
		}
		else if (best_node_from_mbr_heap->query_point_dis < ans_set.front().distance)
		{
			pop_heap(mbr_heap.begin(),mbr_heap.end(),compare_fn_mbr());
			mbr_heap.pop_back();
			struct heap_find popped_head;// = (struct heap_find)malloc(sizeof(struct heap_find));
			popped_head.coordinates = (double *)malloc(sizeof(double)*dimension);
			popped_head.distance = best_node_from_mbr_heap->query_point_dis;
			popped_head.coordinates = best_node_from_mbr_heap->x;
		    ans_set.push_back(popped_head);
			push_heap (ans_set.begin(),ans_set.end(),compare_fn());
			if(left_mbr != NULL)
			{
				double temp_distance1 = distance_mbr(left_mbr->min_mbr,left_mbr->max_mbr,query_p);
				left_mbr->query_point_dis = temp_distance1;
				
				mbr_heap.push_back(left_mbr);
				push_heap (mbr_heap.begin(),mbr_heap.end(),compare_fn_mbr());
			}
			if(right_mbr != NULL)
			{
				double temp_distance2 = distance_mbr(right_mbr->min_mbr,right_mbr->max_mbr,query_p);
				right_mbr->query_point_dis = temp_distance2;
				
				mbr_heap.push_back(right_mbr);
				push_heap (mbr_heap.begin(),mbr_heap.end(),compare_fn_mbr());
			}
			/* code */
		}
		else
		{
			break;
		}
	}

	struct points ats;// = (struct points)malloc(sizeof (struct points));
	ats.coordinates = (double *)malloc(sizeof (double)*dimension);

	for (int i = 0; i < dimension; i++)
	{
		ats.coordinates[i] = query_p[i];
		/* code */
	}

	vector<struct heap_find> fin_ans_set = our_fn(ats,k,knn_size);

// struct k_d_node *generate_tree(struct points *data, int level, int dimen, int leng, double * query_point)
// {
// 	cout << "here1" << leng << endl;
// 	// if (leng == 0){
// 	// 	return NULL;
// 	// }
// 	if(leng == 1)
// 	{
// 		struct k_d_node * new_node = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
// 		new_node->left = NULL;
// 		new_node->right = NULL;
// 		cout << "here8" << endl;
// 		new_node->x = data[0].coordinates;
// 		cout << "here9" << endl;
// 		return new_node;
// 	}
// 	if (4 > 3){
// 		cout << "here2" << endl;
// 		int curr_dim = level%dimen;
		// struct points * sorted_points = (struct points *)malloc(leng*sizeof(struct points));
// 		sorted_points = give_sorted_points(data,curr_dim,leng);
// 		cout << "here3" << endl;
		// struct k_d_node * new_node = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
// 		new_node->x = sorted_points[leng/2].coordinates;
// 		cout << "here4" << endl;
// 		struct points * first_half_sorted_points = (struct points *)malloc(leng/2*sizeof(struct points));
// 		struct points * second_half_sorted_points = (struct points *)malloc((leng/2-1)*sizeof(struct points));;
// 		cout << "here5" << endl;
// 		for (int i = 0; i < leng/2; i++)
// 		{
// 			first_half_sorted_points[i].coordinates = (double *)malloc(dimension * sizeof(double));
// 			for (int j = 0; j < dimen; j++)
// 			{
// 				first_half_sorted_points[i].coordinates[j] = sorted_points[i].coordinates[j];
// 			}
// 		}
// 		cout << "here6" << endl;
// 		new_node->left = generate_tree(first_half_sorted_points,level+1,dimen,leng/2,query_point);
// 		cout << "here7 " << leng  << endl;
// 		// if(leng/2 != 1 && leng != 0)
// 		// {
// 			int k;
// 			k = 0;
// 			for (int i = leng/2 + 1; i < leng; i++)
// 			{
// 				second_half_sorted_points[k].coordinates = (double *)malloc(dimension * sizeof(double));
// 				for (int j = 0; j < dimen; j++)
// 				{
// 					second_half_sorted_points[k].coordinates[j] = sorted_points[i].coordinates[j];
// 				}
// 				k++;
// 			}
// 			new_node->right = generate_tree(second_half_sorted_points,level+1,dimen,leng/2 - 1, query_point);	
// 		// }
		
// 		new_node->min_mbr = give_min_mbr(new_node->x,new_node->right->min_mbr,new_node->left->min_mbr);
// 		new_node->max_mbr = give_max_mbr(new_node->x,new_node->right->max_mbr,new_node->left->max_mbr);
// 		new_node->query_point_dis = distance_mbr((new_node->min_mbr),(new_node->max_mbr),query_point);
// 		return new_node;
// 	}

// }







// int * fn(int * data){

// 	int  ans[5];

// 	ans = (int *)malloc(5 * sizeof(int));

// 	for(int i=0;i<5;i++){
// 		ans[i] = data[i];
// 	}

// 	return ans;
// }

	// for(int i=0;i<k;i++){
	// 	cout << ans_set[i].distance << endl;
	// 	cout << " " << endl;
	// }
	

	return fin_ans_set;

}

int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];

	// [TODO] Construct kdTree using dataset_file here

	int size;

	double y;

	ifstream inFile;
    
    inFile.open(dataset_file);

    inFile >> dimension;

    inFile >> size;

    data_set = (struct points *)malloc(size*sizeof(struct points));

    for(int i=0;i<size;i++){
    	data_set[i].coordinates = (double *)malloc(dimension*sizeof(double));
    	for(int j=0;j<dimension;j++){
    		inFile >> y;
    		data_set[i].coordinates[j] = y;
    		// cout << "i " << i << "j " << j << " " << data_set[i].coordinates[j] << endl;
    	}
    }

    inFile.close();

	struct k_d_node * main_node = (struct k_d_node *)malloc(sizeof(struct k_d_node *));
	main_node = generate_tree(data_set,0,dimension,size);


	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	

	// char* query_file = "query_set.txt";
	// int k=2;
	

	// cin >> query_file >> k;
	// cerr << dataset_file << " " << query_file << " " << k << endl;




	int q_size;

	ifstream q_inFile;
    
    q_inFile.open(query_file);

    q_inFile >> dimension;

    q_inFile >> q_size;

    query_set = (struct points *)malloc(q_size*sizeof(struct points));

    for(int i=0;i<q_size;i++){
    	query_set[i].coordinates = (double *)malloc(dimension*sizeof(double));
    	for(int j=0;j<size;j++){
    		q_inFile >> y;
    		query_set[i].coordinates[j] = y;
    	}
    }

    q_inFile.close();

	ofstream myfile;
	myfile.open ("result.txt");

    for(int i=0;i<q_size;i++){

    	vector<struct heap_find> ansd = knn_bfs(main_node,k,query_set[i].coordinates,size);

    	for(int j=0;j<k;j++){
			
			for(int h=0;h<dimension;h++){

				myfile << ansd[j].coordinates[h];

				if(h != dimension-1){
					myfile << " ";
				}

			}

			myfile << "\n";

    	}

    }

	myfile.close();



	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt



	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
}
