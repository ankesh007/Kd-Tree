
import sys
queryfile = sys.argv[1]
file = sys.argv[2]

import numpy as np
count = 0

queries = []
with open(queryfile) as qf:
    for line in qf:
        queries.append(np.asarray([float(x) for x in line.split()]))
qf.close()
del queries[0]

with open(file) as f:
    sumdist2=0
    sumdist100 = 0
    for line in f:
        count+=1
        if (count%100==2):
            query = queries[int((count-1)/100)]
            second = np.asarray([float(x) for x in line.split()])
            sumdist2+=np.linalg.norm(query - second)
        elif (count%100==0):
            query = queries[int((count-1)/100)]
            hundred = np.asarray([float(x) for x in line.split()])
            sumdist100+=np.linalg.norm(query - hundred)
print("avg dist2, avg dist100:: ",sumdist2/sumdist100)