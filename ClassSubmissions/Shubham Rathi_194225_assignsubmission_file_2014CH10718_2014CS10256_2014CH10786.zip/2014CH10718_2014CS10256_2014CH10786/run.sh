#!/bin/bash
#nameofgeneratorfile dim size 
# echo "<input data filename> <dim> <size>"
# g++ -std=c++11 -o genex -O3 generator.cpp
# ./genex $1 $2 $3
# ./genex $4 $2 1
# cat $1
# cat $4
g++ -std=c++11 -Ofast  -o kdtree kdtree.cpp construction.cpp 
./kdtree $1
#g++ -std=c++11 -Ofast -fprofile-use -o kdtree kdtree.cpp construction.cpp
#./kdtree $1
# rm kdtree
# rm genex
#python3 plot2d.py
