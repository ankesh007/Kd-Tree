
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <string>
#include <ctime>
#include <bits/stdc++.h>
#include <iostream>
#include "kdtree.h"
#include <cmath>


#include <queue>

#include <assert.h>


using namespace std;

vector < vector <double> > data;
vector<double> myComparatorReference;

double epsilon=0.0000001;

int threshold=31;

double dist(vector<double> &first,vector<double> &second){

    double distance=0;
    // assert(first.size()==second.size());
    int size=first.size();
    //cerr << "dist " << size << endl;
    for(int i=0;i<size;i++){
            //cerr << "disttt " << size << endl;
        distance=distance + (first[i]-second[i])*(first[i]-second[i]);
    }
    distance=sqrt(distance);
    //cerr << distance << endl;
    return distance;
}

double MBRmindist(vector<double> &reference,Node *node){

    if(node->isLeaf()){
        return dist(reference,data[node->pivot]);
    }

    double distance=0;
    int size=reference.size();
    for(int i=0;i<size;i++){
        double temp=0;
        if(reference[i] < node->min[i] ){ temp=node->min[i]-reference[i];}
        else if(reference[i]> node->max[i]){temp=reference[i]-node->max[i];}
        else {temp=0;}

        distance=distance+temp*temp;
    }

    distance=sqrt(distance);
    return distance;
}

class myComparator1{
    public:
    
    bool operator() (vector<double> p1, vector<double> p2)
    {   
        // vector<double> *temp = &myComparatorReference;
        int size=p1.size();
        //cerr << "Compare 1" << endl;
        if(fabs(dist(p1,myComparatorReference)-dist(p2,myComparatorReference))<epsilon){
            //cerr << "Compare 2" << endl;
            for(int i=0;i<size;i++){
                if(fabs(p1[i]-p2[i])>epsilon){
                    if(p1[i]>p2[i]){return false; }    ///to be checked
                    
                    return true ;
                }

            }
        }
        else{
            //cerr << "Compare 3" << endl;
            return dist(p1,myComparatorReference) < dist(p2,myComparatorReference); //max heap
        }
    }
};

class myComparator2{
    public:
   
    int operator() (Node *p1,Node *p2)
    {
       
        return MBRmindist(myComparatorReference,p1) > MBRmindist(myComparatorReference, p2) ;//min heap
        
    }



};



vector<vector<double>> MBR(vector<double> &query,int k,Node *root){

    priority_queue <vector<double>,vector<vector<double> >,myComparator1 > answerSet;
    priority_queue <Node*,vector<Node*>,myComparator2> Candidates;

    Candidates.push(root);
    //cerr << "MBRcheck1" << endl;
    //cerr << "K: " << k << endl;
    

    while(Candidates.size()!=0){
        //cerr << "MBR while check1" << endl;

        if(answerSet.size()<k){
            Node *currentNode=Candidates.top();
            Candidates.pop();

      
            if(! currentNode->isLeaf()){
                Node *left=currentNode->lchd;
                Node *right=currentNode->rchd;

                if(left!=NULL){   
                    Candidates.push(left);   
                }
                if(right!=NULL){  
                    Candidates.push(right);    
                }
            }
            
            vector<double> currentAnswer=data[currentNode->pivot];
            answerSet.push(currentAnswer);
            
            

        }
        else{
            Node *currentNode=Candidates.top();
            Candidates.pop();  
            vector<double> worstAnswer=answerSet.top();
            double bestDistance=dist(query,worstAnswer);

            if(MBRmindist(query,currentNode)-bestDistance>epsilon){
                break;
            }
            if(! currentNode->isLeaf()){
                Node *left=currentNode->lchd;
                Node *right=currentNode->rchd;

                if(left!=NULL){
                   if( MBRmindist(query,left) - bestDistance < epsilon){
                    
                    Candidates.push(left);
                   }
                }
                if(right!=NULL){
                   if( MBRmindist(query,right) - bestDistance <epsilon){
                    Candidates.push(right);
                   }
                }
            }
            
            vector<double> currentAnswer=data[currentNode->pivot];
            
            if(fabs(dist(query,currentAnswer)-dist(query,worstAnswer))<epsilon){
                int size=currentAnswer.size();

                for(int i=0;i<size;i++){
                    if(fabs(currentAnswer[i]-worstAnswer[i])>epsilon){
                        if(worstAnswer[i]-currentAnswer[i] > epsilon){
                            answerSet.pop();
                            answerSet.push(currentAnswer);
                        }
                        break;
                    }
                }
            }
            else if(dist(query,worstAnswer)-dist(query,currentAnswer)> epsilon ){
                answerSet.pop();
                answerSet.push(currentAnswer);
            }

        }

       
        
    }

    vector<vector<double>> answerListReversed;
    while(answerSet.size()!=0){
        vector<double> topVector=answerSet.top();
        answerSet.pop();
        answerListReversed.push_back(topVector);
    }
    return answerListReversed;

}



void DFS(Node *currentNode,priority_queue <vector<double>,vector<vector<double> >,myComparator1 > &answerSet,vector<double> &query,int &k){

	if(answerSet.size()<k){
		//vector<double> currentAnswer=;
        answerSet.push(data[currentNode->pivot]);
		
	}
	else{
		vector<double> worstAnswer=answerSet.top();
     	double bestDistance=dist(query,worstAnswer);
		vector<double> currentAnswer=data[currentNode->pivot];

		double temp=dist(query,worstAnswer)-dist(query,currentAnswer);
		if(fabs(temp)<epsilon){
		    int size=currentAnswer.size();

		    for(int i=0;i<size;i++){
		        if(fabs(currentAnswer[i]-worstAnswer[i])>epsilon){
		            if(worstAnswer[i]-currentAnswer[i] > epsilon){
		                answerSet.pop();
		                answerSet.push(currentAnswer);
		            }
		            break;
		        }
		    }
		}
		else if(temp> epsilon ){
		    answerSet.pop();
		    answerSet.push(currentAnswer);
		}

	}


	if(! currentNode->isLeaf()){
		    Node *left=currentNode->lchd;
		    Node *right=currentNode->rchd;

		    if(left!=NULL){
		       	DFS(left,answerSet,query,k);
		       }
		    
		    if(right!=NULL){
		       	DFS(right,answerSet,query,k);
		       }
	}


	return;


	 

}

vector<vector<double>> treeTraversal(vector<double> &query,int k,Node *root){

    priority_queue <vector<double>,vector<vector<double> >,myComparator1 > answerSet;
    
    
    //cerr << "MBRcheck1" << endl;
    //cerr << "K: " << k << endl;
    


    DFS(root,answerSet,query,k);


    vector<vector<double>> answerListReversed;
    while(answerSet.size()!=0){
        vector<double> topVector=answerSet.top();
        answerSet.pop();
        answerListReversed.push_back(topVector);
    }
    return answerListReversed;

}




vector<vector<double>> SequentialScan(vector<double> &query,int k){

    priority_queue <vector<double>,vector<vector<double> >,myComparator1 > answerSet;
   

    // cout << data[0][0] << endl;
    for(int i=0;i<k;i++){
        answerSet.push(data[i]);
    }

    for(int i=k;i<data.size();i++){

        vector<double> worstAnswer=answerSet.top();
        vector<double> currentAnswer=data[i];
        // cerr<<"1 "<<dist(query,currentAnswer)<<endl;
        // cerr<<"2 "<<dist(query,worstAnswer)<<endl;
        
        if(fabs(dist(query,currentAnswer)-dist(query,worstAnswer))<epsilon){
            int size=currentAnswer.size();

            // cerr<<"currentAnswer "<<currentAnswer[0]<<" "<<currentAnswer[1]<<endl;
            // cerr<<"worstAnswer "<<worstAnswer[0]<<" "<<worstAnswer[1]<<endl;
            for(int j=0;j<size;j++){
                if(fabs(currentAnswer[j]-worstAnswer[j])>epsilon){
                    if(currentAnswer[j]<worstAnswer[j] ){
                        answerSet.pop();
                        answerSet.push(currentAnswer);
                    }
                    break;
                }
            }
        }
        else if(dist(query,worstAnswer)-dist(query,currentAnswer)>epsilon){
            // cerr << "hurrah"<<endl;
            answerSet.pop();
            answerSet.push(currentAnswer);
        }

    }


    vector<vector<double>> answerListReversed;
    while(answerSet.size()!=0){
        vector<double> topVector=answerSet.top();
        answerSet.pop();
        answerListReversed.push_back(topVector);
    }
    return answerListReversed;

}


vector<vector<double>> recursion(vector<double> &query,int k,Node *root){

    priority_queue <vector<double>,vector<vector<double> >,myComparator1 > answerSet;
    priority_queue <Node*,vector<Node*>,myComparator2> Candidates;

    Candidates.push(root);
    //cerr << "MBRcheck1" << endl;
    //cerr << "K: " << k << endl;
    

    while(Candidates.size()!=0){
        //cerr << "MBR while check1" << endl;

        if(answerSet.size()<k){
            Node *currentNode=Candidates.top();
            Candidates.pop();

            if(currentNode->list.size()<=threshold){
            	DFS(currentNode,answerSet,query,k);;
            }
            else{
      
            if(! currentNode->isLeaf()){
                Node *left=currentNode->lchd;
                Node *right=currentNode->rchd;

                if(left!=NULL){   
                    Candidates.push(left);   
                }
                if(right!=NULL){  
                    Candidates.push(right);    
                }
            }
            
            vector<double> currentAnswer=data[currentNode->pivot];
            answerSet.push(currentAnswer);
            }
            

        }
        else{

        	Node *currentNode=Candidates.top();
            Candidates.pop(); 

        	if(currentNode->list.size()<=threshold){
            	DFS(currentNode,answerSet,query,k);;
            }

        	else{
        		 
            vector<double> worstAnswer=answerSet.top();
            double bestDistance=dist(query,worstAnswer);

            if(MBRmindist(query,currentNode)-bestDistance>epsilon){
                break;
            }
            if(! currentNode->isLeaf()){
                Node *left=currentNode->lchd;
                Node *right=currentNode->rchd;

                if(left!=NULL){
                   if( MBRmindist(query,left) - bestDistance < epsilon){
                    
                    Candidates.push(left);
                   }
                }
                if(right!=NULL){
                   if( MBRmindist(query,right) - bestDistance <epsilon){
                    Candidates.push(right);
                   }
                }
            }
            
            vector<double> currentAnswer=data[currentNode->pivot];
            

            double temp=dist(query,worstAnswer)-dist(query,currentAnswer);
            if(fabs(temp)<epsilon){
                int size=currentAnswer.size();

                for(int i=0;i<size;i++){
                    if(fabs(currentAnswer[i]-worstAnswer[i])>epsilon){
                        if(worstAnswer[i]-currentAnswer[i] > epsilon){
                            answerSet.pop();
                            answerSet.push(currentAnswer);
                        }
                        break;
                    }
                }
            }
            else if(temp> epsilon ){
                answerSet.pop();
                answerSet.push(currentAnswer);
            }

        }
        	}
            

       
        
    }

    vector<vector<double>> answerListReversed;
    while(answerSet.size()!=0){
        vector<double> topVector=answerSet.top();
        answerSet.pop();
        answerListReversed.push_back(topVector);
    }
    return answerListReversed;

}


int main(int argc, char **argv){    

// clock_t start;
// double duration;
// start = clock();

int size;
int dim;
string s;
//vector < vector <double> > data;
vector<int> masterlist;
ifstream inFile;
inFile.open(argv[1]);
// cerr << "hello" << endl;
if (!inFile)
{
    //cerr<<"failed to open:";
    // cerr<<"Unable to open file";
    exit(1);
}
getline(inFile, s);
istringstream is (s);
is >> dim>> size;
//cerr<<"dim: "<<dim<<endl<<"size: "<<size<<endl;
int counter =0;
// cerr << "hello" << endl;

while (getline(inFile, s))
{
    vector <double> v;
    istringstream iss(s);
    ////cerr<<"s: "<<s<<endl;
    double d;
    while(iss >> d){
        v.push_back(d);
    }
    data.push_back(v);
    masterlist.push_back(counter++);
}
// cerr << "hello" << endl;

// for (int i=0; i<size; i++)
//     {for (int j=0; j<dim; j++)
//         //cerr<<data[i][j]<<" ";
//         //cerr<<endl;
//     }
int tracker = 0;
Node *root = kdconstruct(masterlist, data, 0, dim, tracker);
// cerr << "hello" << endl;

//Cue for parent.py to start timer
cout << 0 << endl;
char* query_file = new char[100];
int k;
cin >> query_file >> k;
// //cerr<<endl;
// //cerr<<"root: median "<<root->lchd->median<<" :"<<root->lchd->list.size();


// duration = ( std::clock() - start ) / (double) CLOCKS_PER_SEC;
// //cerr<<"duration (sec): "<< duration <<"sec \n";

// vector<graphvizNode*> gv;
// int starter=0;
// traverse(root, data, gv, starter);
// //cerr<<endl<<"gv size:"<<gv.size();


// ofstream file, edge;
// file.open("plotdata.txt");
// edge.open("plotedges.txt");
// for (auto&i: gv){
//     file<<"'"<<i->ID<<"'"<<"; "<<"'"<<i->display<<"'; \n";
// }
// for (auto&i: gv){
//     for(auto&j: i->adjlist){
//        edge<<"'"<<i->ID<<"'"<<","<<"'"<<j<<"'\n";//", constraint='false'"<<"\n";
//        //edge<<i->ID<<","<<j<<"\n";
//     }
// }

// file.close();
// edge.close();

// Query MBR

//cerr << "Construction Done #############" <<endl;

ifstream qfile;
qfile.open(query_file);
// int k = atoi(argv[3]);
int numQuery;

ofstream resultfile;
resultfile.open("results.txt");



string line;
getline(qfile,line);
istringstream first (s);
first >> dim>> numQuery;

// cerr << "Checkpoint1" << endl;

// Comment for only sequential###################

while (getline(qfile,line))
{
    // int check = 1;
    vector <double> v;
    istringstream second(line);
    double d;
    while(second >> d){
        v.push_back(d);
    }
    //cerr << "Vector Size: " << v.size() << endl;
    //cerr << check << " WhileCheckpoint1" << endl;
    myComparatorReference=v;
    vector<vector<double>> ReversedAnswerList;
    if(dim>=15)
   { //ReversedAnswerList=recursion(v,k,root);
   	ReversedAnswerList=treeTraversal(v,k,root);
   }
   	else{
   		ReversedAnswerList=recursion(v,k,root);	
   		 //ReversedAnswerList=MBR(v,k,root);
   	}//call mbr
    //vector<vector<double>> ReversedAnswerList2=SequentialScan(v,k,root);//call mbr

    //cerr << check << " WhileCheckpoint2" << endl;
    int siz = ReversedAnswerList.size();
    for(int i=siz-1;i>=0;i--){
        for(int j=0;j<dim;j++){
            resultfile << ReversedAnswerList[i][j] << " ";
        }
        resultfile << "\n";
    }

    
    // check++;
}

// // ##################################### End comment

//cerr << "Checkpoint2" << endl;

qfile.close();
resultfile.close();


// ############### Sequential Scan #####################

// qfile.open(query_file);
// getline(qfile,line);
// resultfile.open("results2.txt");

// while (getline(qfile,line))
// {
//  int check = 1;
//     vector <double> v;
//     istringstream second(line);
//     double d;
//     while(second >> d){
//         v.push_back(d);
//     }
//     //cerr << "Vector Size: " << v.size() << endl;
//      //cerr << check << " WhileCheckpoint1" << endl;
//     myComparatorReference=v;

//     //vector<vector<double>> ReversedAnswerList=MBR(v,k,root);//call mbr
//     vector<vector<double>> ReversedAnswerList2=SequentialScan(v,k);//call mbr

//     //cerr << check << " WhileCheckpoint2" << endl;
//     int siz = ReversedAnswerList2.size();
//     for(int i=siz-1;i>=0;i--){
//      for(int j=0;j<dim;j++){
//          resultfile << ReversedAnswerList2[i][j] << " ";
//      }
//      resultfile << "\n";
//     }

    
//     check++;
// }
// qfile.close();
// resultfile.close();

//############## End sequential scan ###################

//Cue to stop timer
cout << 1 << endl;
return 0;
}

