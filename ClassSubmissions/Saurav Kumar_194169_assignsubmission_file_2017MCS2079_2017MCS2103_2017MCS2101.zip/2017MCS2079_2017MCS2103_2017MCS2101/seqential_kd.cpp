#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <time.h>
#include<algorithm>
#include <ctime>
#include<math.h>
#include <queue>
#include<chrono>
#include<iomanip>
//#include<conio.h>
//#include <bits/stdc++.h>
using namespace std;

// working in 5-D space
int dim = 0;
int k = 100;
int no_of_data_points=0;
vector< vector<double> > data;
vector< vector<double> > data_sorted_temp;
int node_no = 0;
int dim_to_split_left = 1;
int dim_to_split_right = 1;
vector<double> query_point;
int counter = 0;
int iter = 0;

struct kdnode* right_child (vector<vector<double> > data_sorted_temp,int med);
struct kdnode* left_child(vector<vector<double> > data_sorted_temp,int med);
double min(vector<vector<double> > data,int column_no);
double max(vector<vector<double> > data,int column_no);
struct kdnode* newnode(vector<double> v, vector<vector<double> > node_data);
double euclidean(vector<double> query_point,double mbr[][2]);
double euclidean_answerSet(vector<double> query_point,vector<double> data);

bool sortcol(const vector<double>& v1,const vector<double>& v2 ) {
               	
 return v1[dim_to_split_left] < v2[dim_to_split_left];
}

struct kdnode
{
    vector<double> val; // To store k dimensional point
    kdnode *left, *right;
	double mbr[20][2];
};

class Point
{
   double x;
   struct kdnode* node;
public:
   Point(double x1, struct kdnode* node1)
   {
      x = x1;
      node = node1;
   }
   double getX() const { return x; }
   struct kdnode* getY() { return node;}
};
 
// To compare two points
class myComparatorMax
{
public:
    int operator() (const Point& p1, const Point& p2)
    {
        return p1.getX() < p2.getX();
    }
};

priority_queue <Point, vector<Point>, myComparatorMax > pq;

double min(vector<vector<double> > data,int column_no){
	
	double min_element = data[0][column_no];
	int i;
	for(i=1;i<data.size();++i){
		
		if(min_element>data[i][column_no])
		   min_element = data[i][column_no];
	}
	
	return min_element;	
}

double max(vector<vector<double> > data,int column_no){
	
	double max_element = data[0][column_no];
	int i;
	for(i=1;i<data.size();++i){
		
		if(max_element<data[i][column_no])
		   max_element = data[i][column_no];
	}
	return max_element;	
}

// function to create a new node

struct kdnode* newnode(vector<double> v, vector<vector<double> > node_data)
{
    struct kdnode* temp = new kdnode;
    node_no+=1;
    cout<<"Node created with node mumber "<<node_no<<endl;
 
    temp->val = v;
    temp->left = temp->right = NULL;
    int i;
    for(i=1;i<=dim;++i){
    	
    	temp->mbr[i-1][0] = min(node_data,i);
    	temp->mbr[i-1][1] = max(node_data,i);
    }
    return temp;
}

struct kdnode* left_child(vector<vector<double> > data_sorted_temp,int med){
	
	vector<vector<double> > data_left;
	int i;
	int cnt = 0;
	dim_to_split_left = (dim_to_split_left + 1)%(dim+1);
	if(dim_to_split_left==0)
	   dim_to_split_left = 1;
	dim_to_split_right = (dim_to_split_right + 1)%(dim+1);
	if(dim_to_split_right==0)
	   dim_to_split_right = 1;   
	for(i=0;i<data_sorted_temp.size()/2;++i){
	   	
	   	   vector<double> row(1,dim);
		   data_left.push_back(row);
		   data_left[cnt].assign(data_sorted_temp[i].begin(),data_sorted_temp[i].end());
		   cnt+=1;
	}
	
	sort(data_left.begin(),data_left.end(),sortcol);
	med = data_left.size()/2;
	if(data_left.size()==1){
		
		struct kdnode* leftc = newnode(data_left[med],data_left);
		dim_to_split_left = (dim_to_split_left-1)%(dim+1);
	    if(dim_to_split_left==0)
	       dim_to_split_left = dim;
	    dim_to_split_right = (dim_to_split_right-1)%(dim+1);
	    if(dim_to_split_right==0)
	       dim_to_split_right = dim;
		return leftc;
		
	}
	if(data_left.size()==2){
		
		struct kdnode* leftc = newnode(data_left[med],data_left);
		leftc->left = left_child(data_left,med);
	    dim_to_split_left = (dim_to_split_left-1)%(dim+1);
	    if(dim_to_split_left==0)
	       dim_to_split_left = dim;
	    dim_to_split_right = (dim_to_split_right-1)%(dim+1);
	    if(dim_to_split_right==0)
	       dim_to_split_right = dim;
		return leftc;	
	}
	struct kdnode* leftc = newnode(data_left[med],data_left);
	leftc->left = left_child(data_left,med);
	dim_to_split_left = (dim_to_split_left-1)%(dim+1);
	if(dim_to_split_left==0)
	   dim_to_split_left = dim;
	leftc->right = right_child(data_left,med);
	dim_to_split_right = (dim_to_split_right-1)%(dim+1);
	if(dim_to_split_right==0)
	   dim_to_split_right = dim;
	return leftc;
}

struct kdnode* right_child(vector<vector<double> > data_sorted_temp,int med){
	
	vector<vector<double> > data_right;
	int i;
	int cnt = 0;
	dim_to_split_left = (dim_to_split_left + 1)%(dim+1);
	if(dim_to_split_left==0)
	   dim_to_split_left = 1;
	dim_to_split_right = (dim_to_split_right + 1)%(dim+1);
	if(dim_to_split_right==0)
	   dim_to_split_right = 1;
	for(i=(data_sorted_temp.size()/2)+1;i<data_sorted_temp.size();++i){
	   	
	   	   vector<double> row(1,dim);
		   data_right.push_back(row);
		   data_right[cnt].assign(data_sorted_temp[i].begin(),data_sorted_temp[i].end());
		   cnt+=1;
	}
	
	sort(data_right.begin(),data_right.end(),sortcol);
	med = data_right.size()/2;
	if(data_right.size()==1){
		
		struct kdnode* rightc = newnode(data_right[med],data_right);
		dim_to_split_left = (dim_to_split_left-1)%(dim+1);
	    if(dim_to_split_left==0)
	       dim_to_split_left = dim;
	    dim_to_split_right = (dim_to_split_right-1)%(dim+1);
	    if(dim_to_split_right==0)
	       dim_to_split_right = dim;
		return rightc;
		
	}
	if(data_right.size()==2){
		
		struct kdnode* rightc = newnode(data_right[med],data_right);
		rightc->left = left_child(data_right,med);
	    dim_to_split_left = (dim_to_split_left-1)%(dim+1);
	    if(dim_to_split_left==0)
	       dim_to_split_left = dim;
	    dim_to_split_right = (dim_to_split_right-1)%(dim+1);
	    if(dim_to_split_right==0)
	       dim_to_split_right = dim;
		return rightc;	
	}
	struct kdnode* rightc = newnode(data_right[med],data_right);
	rightc->left = left_child(data_right,med);
	dim_to_split_left = (dim_to_split_left-1)%(dim+1);
	if(dim_to_split_left==0)
	   dim_to_split_left = dim;
	rightc->right = right_child(data_right,med);
	dim_to_split_right = (dim_to_split_right-1)%(dim+1);
	if(dim_to_split_right==0)
	   dim_to_split_right = dim;
	return rightc;
}

double euclidean_answerSet(vector<double> query_point,vector<double> data){
		
	double dist = 0;
	double temp=0;
	int i;
	for(i=1;i<=dim;++i){
		
		temp = query_point[i]-data[i];
		dist = dist + (temp*temp);
	}
	dist = pow(dist,0.5);
	return dist;
}

struct kdnode* sequentialSearch(vector<double> query_point,struct kdnode* node){
	
	iter+=1;
	double dist_minheap;
	dist_minheap = euclidean_answerSet(query_point,node->val);
               
	if(iter<=k){
	   pq.push(Point(dist_minheap,node));
	   if((node->left)!=NULL){
	
	       node->left = sequentialSearch(query_point,node->left);
	   }
	   if((node->right)!=NULL){
		     
		   node->right = sequentialSearch(query_point,node->right);
	   }
    }
    else{
    	
    	Point p = pq.top();
    	if(dist_minheap<(p.getX())){
    		pq.pop();
    		pq.push(Point(dist_minheap,node));
    	}
    	if((node->left)!=NULL){
	
	       node->left = sequentialSearch(query_point,node->left);
	    }
	    if((node->right)!=NULL){
		     
		   node->right = sequentialSearch(query_point,node->right);
	    }
    }
    return node;
}

int main(){
		
	// BASIC INPUT TAKING PLACE
	//**********************************************************
	 char* query_file_path = new char[100];   
                    int k;
                    char* dataset_file="20_points.txt";
                    query_file_path="20_set.txt";
                            k=20;
                    // char* dataset_file=argv[1];
                    fstream file;
                    file.open(dataset_file);
                    string line;
                    getline(file,line);
                    istringstream iss(line); 
                    iss>>dim;    iss>>no_of_data_points;     
                    double r;
                    int i, j;
                    for (i = 0; i<no_of_data_points; ++i) { 
                        getline(file,line);
                        istringstream iss(line); 
                        vector<double> row(1, dim);
                        data.push_back(row);
                        for (j = 0; j<dim; ++j){
                            iss>>r;                               
                            data[i].push_back(r);
                        }        
                    }
                    file.close();   
	
	//************************************************************
	//GENERATING THE K-D TREE
	
	for(i=0;i<no_of_data_points;++i){
	   	
	   	   vector<double> row(1,dim);
		   data_sorted_temp.push_back(row);
		   data_sorted_temp[i].assign(data[i].begin(),data[i].end());
	}
	
	sort(data_sorted_temp.begin(), data_sorted_temp.end(), sortcol);

	int med = data_sorted_temp.size()/2;
	struct kdnode* node = newnode(data_sorted_temp[med],data_sorted_temp);
	node->left = left_child(data_sorted_temp,med);
	node->right = right_child(data_sorted_temp,med);
	
	// doing Sequential KNN Query
        
        
        /***Var****/
        double dist,dist_minheap,dist_maxheap,dist_left,dist_right;
    int iter;
    struct kdnode* ptr;
    vector<double> query_point;
    vector< vector<double> > query_pt;
    fstream query_file;
    ofstream result_file;
    result_file.open("results.txt");
    int itr,no_of_query_points;     
    
    string query_line;
    vector<double> row(1, dim);
    vector<double> vec;
    struct kdnode* temp;
    string result;
    //*****//
    auto start = chrono::steady_clock::now();    
    cout << 0 << endl;    
    //cin >> query_file_path >> k;       
    
    
    
    query_file.open(query_file_path);    
    getline(query_file,query_line);
    istringstream iss_query(query_line); 
    iss_query>>dim;    iss_query>>no_of_query_points;     
    for (i = 0; i<no_of_query_points; ++i)  {   
        getline(query_file,query_line);
       istringstream iss_query(query_line); 
        //vector<double> row(1, dim);
        query_pt.push_back(row);
        for (j = 0; j<dim; ++j)
        {
            iss_query>>r;                               
            query_pt[i].push_back(r);
        }        
    }    
    for(itr=0;itr<no_of_query_points;++itr){
    query_point = query_pt[itr];      	
	
	node = sequentialSearch(query_point,node);
    }
     auto stop = chrono::steady_clock::now();	
   // printing points and their distances
   /*vector<double> vec;
   while (pq.empty() == false){
     Point p = pq.top();
     cout<< p.getX() << " , ";
     struct kdnode* temp = p.getY();
     vec = temp->val;
     for(i=1;i<=dim;++i){
       cout<<vec[i]<<" ";
     }
     cout << endl;
     pq.pop();
  }*/
  cout << 1 << endl;
    // result_file.close();    
        
    cerr<<"ns:-"<<chrono::duration_cast<chrono::nanoseconds>(stop-start).count()<<"ns"<<endl;
    cerr<<"micros:-"<<chrono::duration_cast<chrono::microseconds>(stop-start).count()<<"micros"<<endl;
    cerr<<"millis:-"<<chrono::duration_cast<chrono::milliseconds>(stop-start).count()<<"millis"<<endl;
    cerr<<"s:-"<<chrono::duration_cast<chrono::seconds>(stop-start).count()<<"s"<<endl;
    for(double n : query_point) 
        std::cerr << std::setprecision(20)<< n << '\t';
    return 0;
}