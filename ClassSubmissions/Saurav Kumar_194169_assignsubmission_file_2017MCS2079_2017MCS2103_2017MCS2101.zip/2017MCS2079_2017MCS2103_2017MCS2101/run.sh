#!/bin/bash
g++ -O3 -std=c++14 main.cpp; ./a.out $1
#python sample.py $1