#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <time.h>
#include<algorithm>
#include <ctime>
#include<math.h>
#include <queue>
#include<chrono>
#include<iomanip>
#define endl "\n"
//#include<conio.h>
//#include <bits/stdc++.h>
using namespace std;

// working in 5-D space
int dim = 0;
int k = 20;
int no_of_data_points=0;
vector< vector<double> > data;
vector<double> dist_list;
double dist_minheap;

double euclidean_answerSet(vector<double>& query_point,vector<double>& data){
		
	double dist = 0;
	double temp=0;
	int i;
	for(i=1;i<=dim;++i){
		
		temp = query_point[i]-data[i];
		dist = dist + (temp*temp);
	}
	dist = pow(dist,0.5);
	return dist;
}

void  sequentialSearch(vector<double>& query_point,vector<vector<double> >& datap){
	
    int i,j;
    for(i=0;i<datap.size();++i){
        
        dist_minheap = euclidean_answerSet(query_point,datap[i]);
        dist_list.push_back(dist_minheap);
    }
	
	
}

int main(){
		
	// BASIC INPUT TAKING PLACE
	//**********************************************************
	 char* query_file_path = new char[100];   
                    int k;
                    char* dataset_file="2_points.txt";
                    query_file_path="2_set.txt";
                            k=20;
                    // char* dataset_file=argv[1];
                    fstream file;
                    file.open(dataset_file);
                    string line;
                    getline(file,line);
                    istringstream iss(line); 
                    iss>>dim;    iss>>no_of_data_points;     
                    double r;
                    int i, j;
                    for (i = 0; i<no_of_data_points; ++i) { 
                        getline(file,line);
                        istringstream iss(line); 
                        vector<double> row(1, dim);
                        data.push_back(row);
                        for (j = 0; j<dim; ++j){
                            iss>>r;                               
                            data[i].push_back(r);
                        }        
                    }
                    file.close();   
	
	//************************************************************
	
	// doing Sequential KNN Query
        
        
        /***Var****/
    vector<double> query_point;
    vector< vector<double> > query_pt;
    fstream query_file;
    ofstream result_file;
    result_file.open("results.txt");
    int itr,no_of_query_points;     
    
    string query_line;
    vector<double> row(1, dim);
    vector<double> vec;
    struct kdnode* temp;
    string result;
    //*****//
    
    cout << 0 << endl;    
    //cin >> query_file_path >> k;       
    
    
    
    query_file.open(query_file_path);    
    getline(query_file,query_line);
    istringstream iss_query(query_line); 
    iss_query>>dim;    iss_query>>no_of_query_points;     
    for (i = 0; i<no_of_query_points; ++i)  {   
        getline(query_file,query_line);
       istringstream iss_query(query_line); 
        //vector<double> row(1, dim);
        query_pt.push_back(row);
        
        for (j = 0; j<dim; ++j)
        {
            iss_query>>r;                               
            query_pt[i].push_back(r);
        }        
    }    
    auto start = chrono::steady_clock::now();   
    for(itr=0;itr<no_of_query_points;++itr){
      
   query_point = query_pt[itr];   	
	
	sequentialSearch(query_point,data);
                   sort(dist_list.begin(),dist_list.end());
                   dist_list.clear();
    }
     auto stop = chrono::steady_clock::now();	
   // printing points and their distances
     
     
   /*vector<double> vec;
   while (pq.empty() == false){
     Point p = pq.top();
     cout<< p.getX() << " , ";
     struct kdnode* temp = p.getY();
     vec = temp->val;
     for(i=1;i<=dim;++i){
       cout<<vec[i]<<" ";
     }
     cout << endl;
     pq.pop();
  }*/
  cout << 1 << endl;
    // result_file.close();    
        
    cerr<<"ns:-"<<chrono::duration_cast<chrono::nanoseconds>(stop-start).count()<<"ns"<<endl;
    cerr<<"micros:-"<<chrono::duration_cast<chrono::microseconds>(stop-start).count()<<"micros"<<endl;
    cerr<<"millis:-"<<chrono::duration_cast<chrono::milliseconds>(stop-start).count()<<"millis"<<endl;
    cerr<<"s:-"<<chrono::duration_cast<chrono::seconds>(stop-start).count()<<"s"<<endl;
    for(double n : query_point) 
        std::cerr << std::setprecision(20)<< n << '\t';
    return 0;
}
