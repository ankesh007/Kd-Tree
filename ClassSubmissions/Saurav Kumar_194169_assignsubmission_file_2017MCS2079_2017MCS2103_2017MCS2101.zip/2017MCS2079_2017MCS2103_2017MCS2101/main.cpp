#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <time.h>
#include<algorithm>
#include <ctime>
#include<math.h>
#include <queue>
#include<chrono>
#include<iomanip>
//#include<conio.h>
#define space " "
#define endl "\n"
using namespace std;

// working in 20-D space
int dim = 0;
int no_of_data_points = 0;
vector< vector<double> > datap;
vector< vector<double> > data_sorted_temp;
int node_no = 0;
int dim_to_split_left = 1;
int dim_to_split_right = 1;


struct kdnode* right_child (vector<vector<double> > data_sorted_temp,int med);
struct kdnode* left_child(vector<vector<double> > data_sorted_temp,int med);
double min(vector<vector<double> > datap,int column_no);
double max(vector<vector<double> > datap,int column_no);
struct kdnode* newnode(vector<double> v, vector<vector<double> > node_data);


bool sortcol(const vector<double>& v1,const vector<double>& v2 ) {
    
    return v1[dim_to_split_left] < v2[dim_to_split_left];
}

struct kdnode
{
    vector<double> val; // To store k dimensional point
    kdnode *left, *right;
    double mbr[20][2];
};

class Point
{
    double x;
    struct kdnode* node;
public:
    Point(double x1, struct kdnode* node1)
    {
        x = x1;
        node = node1;
    }
    double getX() const { return x; }
    struct kdnode* getY() { return node;}
};

// To compare two points
class myComparatorMax
{
public:
    int operator() (const Point& p1, const Point& p2)
    {
        return p1.getX() < p2.getX();
    }
};

class myComparatorMin
{
public:
    int operator() (const Point& p1, const Point& p2)
    {
        return p1.getX() > p2.getX();
    }
};

priority_queue <Point, vector<Point>, myComparatorMax > pq;
priority_queue <Point, vector<Point>, myComparatorMin > pq_min;

double min(vector<vector<double> > datap,int column_no){
    
    double min_element = datap[0][column_no];
    int i;
    for(i=1;i<datap.size();++i){
        
        if(min_element>datap[i][column_no])
            min_element = datap[i][column_no];
    }
    
    return min_element;	
}

double max(vector<vector<double> > datap,int column_no){
    
    double max_element = datap[0][column_no];
    int i;
    for(i=1;i<datap.size();++i){
        
        if(max_element<datap[i][column_no])
            max_element = datap[i][column_no];
    }
    return max_element;	
}

// function to create a new node

struct kdnode* newnode(vector<double> v, vector<vector<double> > node_data)
{
    struct kdnode* temp = new kdnode;
    node_no+=1;
    //cerr<<"Node created with node mumber "<<node_no<<endl;
    
    temp->val = v;
    temp->left = temp->right = NULL;
    int i;
    for(i=1;i<=dim;++i){
    	
    	temp->mbr[i-1][0] = min(node_data,i);
    	temp->mbr[i-1][1] = max(node_data,i);
    }
    return temp;
}

struct kdnode* left_child(vector<vector<double> > data_sorted_temp,int med){
    
    vector<vector<double> > data_left;
    int i;
    int cnt = 0;
    dim_to_split_left = (dim_to_split_left + 1)%(dim+1);
    if(dim_to_split_left==0)
        dim_to_split_left = 1;
    dim_to_split_right = (dim_to_split_right + 1)%(dim+1);
    if(dim_to_split_right==0)
        dim_to_split_right = 1;   
    for(i=0;i<data_sorted_temp.size()/2;++i){
        
        vector<double> row(1,dim);
        data_left.push_back(row);
        data_left[cnt].assign(data_sorted_temp[i].begin(),data_sorted_temp[i].end());
        cnt+=1;
    }
    
    sort(data_left.begin(),data_left.end(),sortcol);
    med = data_left.size()/2;
    if(data_left.size()==1){
        
        struct kdnode* leftc = newnode(data_left[med],data_left);
        dim_to_split_left = (dim_to_split_left-1)%(dim+1);
        if(dim_to_split_left==0)
            dim_to_split_left = dim;
        dim_to_split_right = (dim_to_split_right-1)%(dim+1);
        if(dim_to_split_right==0)
            dim_to_split_right = dim;
        return leftc;
        
    }
    if(data_left.size()==2){
        
        struct kdnode* leftc = newnode(data_left[med],data_left);
        leftc->left = left_child(data_left,med);
        dim_to_split_left = (dim_to_split_left-1)%(dim+1);
        if(dim_to_split_left==0)
            dim_to_split_left = dim;
        dim_to_split_right = (dim_to_split_right-1)%(dim+1);
        if(dim_to_split_right==0)
            dim_to_split_right = dim;
        return leftc;	
    }
    struct kdnode* leftc = newnode(data_left[med],data_left);
    leftc->left = left_child(data_left,med);
    dim_to_split_left = (dim_to_split_left-1)%(dim+1);
    if(dim_to_split_left==0)
        dim_to_split_left = dim;
    leftc->right = right_child(data_left,med);
    dim_to_split_right = (dim_to_split_right-1)%(dim+1);
    if(dim_to_split_right==0)
        dim_to_split_right = dim;
    return leftc;
}

struct kdnode* right_child(vector<vector<double> > data_sorted_temp,int med){
    
    vector<vector<double> > data_right;
    int i;
    int cnt = 0;
    dim_to_split_left = (dim_to_split_left + 1)%(dim+1);
    if(dim_to_split_left==0)
        dim_to_split_left = 1;
    dim_to_split_right = (dim_to_split_right + 1)%(dim+1);
    if(dim_to_split_right==0)
        dim_to_split_right = 1;
    for(i=(data_sorted_temp.size()/2)+1;i<data_sorted_temp.size();++i){
        
        vector<double> row(1,dim);
        data_right.push_back(row);
        data_right[cnt].assign(data_sorted_temp[i].begin(),data_sorted_temp[i].end());
        cnt+=1;
    }
    
    sort(data_right.begin(),data_right.end(),sortcol);
    med = data_right.size()/2;
    if(data_right.size()==1){
        
        struct kdnode* rightc = newnode(data_right[med],data_right);
        dim_to_split_left = (dim_to_split_left-1)%(dim+1);
        if(dim_to_split_left==0)
            dim_to_split_left = dim;
        dim_to_split_right = (dim_to_split_right-1)%(dim+1);
        if(dim_to_split_right==0)
            dim_to_split_right = dim;
        return rightc;
        
    }
    if(data_right.size()==2){
        
        struct kdnode* rightc = newnode(data_right[med],data_right);
        rightc->left = left_child(data_right,med);
        dim_to_split_left = (dim_to_split_left-1)%(dim+1);
        if(dim_to_split_left==0)
            dim_to_split_left = dim;
        dim_to_split_right = (dim_to_split_right-1)%(dim+1);
        if(dim_to_split_right==0)
            dim_to_split_right = dim;
        return rightc;	
    }
    struct kdnode* rightc = newnode(data_right[med],data_right);
    rightc->left = left_child(data_right,med);
    dim_to_split_left = (dim_to_split_left-1)%(dim+1);
    if(dim_to_split_left==0)
        dim_to_split_left = dim;
    rightc->right = right_child(data_right,med);
    dim_to_split_right = (dim_to_split_right-1)%(dim+1);
    if(dim_to_split_right==0)
        dim_to_split_right = dim;
    return rightc;
}

double mbr_dist,mbr_temp;

inline double euclidean(vector<double>& query_point , double mbr[][2] ){    
    mbr_dist = 0;
    // mbr_temp=0;
    int i,j;
    for(i=0,j=1;i<dim;++i,++j)
    {             
        if(query_point[j]<mbr[i][0])
	    mbr_temp = mbr[i][0]-query_point[j];
        else if(query_point[j]>mbr[i][1])
	    mbr_temp = query_point[j]-mbr[i][1];
        else
	    mbr_temp = 0;        
        // mbr_dist = mbr_dist + (mbr_temp*mbr_temp);
        mbr_dist = mbr_dist +pow (mbr_temp,2);
    }
    mbr_dist = sqrt(mbr_dist);
    return mbr_dist;	
}


double orig_dist,orig_temp;
inline double euclidean_answerSet(vector<double>& query_point,vector<double>& datap){    
    orig_dist = 0;
    //orig_temp=0;
    int i;
    for(i=1;i<=dim;++i){        
        orig_temp = query_point[i]-datap[i];
        //orig_dist = orig_dist + (orig_temp*orig_temp);
        orig_dist = orig_dist +pow (orig_temp,2);
    }
    orig_dist = sqrt(orig_dist);
    return orig_dist;
}


int main(int argc, char* argv[]){
    ios_base::sync_with_stdio(false);
    /*******BASIC INPUT TAKING PLACE************/    
    char* query_file_path = new char[100];   
    int k;
    //char* dataset_file="20_points.txt";
    
    char* dataset_file=argv[1];
    fstream file;
    file.open(dataset_file);
    string line;
    getline(file,line);
    istringstream iss(line); 
    iss>>dim;    iss>>no_of_data_points;     
    double r;
    int i, j;
    for (i = 0; i<no_of_data_points; ++i) { 
        getline(file,line);
        istringstream iss(line); 
        vector<double> row(1, dim);
        datap.push_back(row);
        for (j = 0; j<dim; ++j){
            iss>>r;                               
            datap[i].push_back(r);
        }        
    }
    file.close();      
    
    
    /*****************GENERATING THE K-D TREE********************/    
    for(i=0;i<no_of_data_points;++i){        
        vector<double> row(1,dim);
        data_sorted_temp.push_back(row);
        data_sorted_temp[i].assign(datap[i].begin(),datap[i].end());
    }
    
    sort(data_sorted_temp.begin(), data_sorted_temp.end(), sortcol);
    
    int med = data_sorted_temp.size()/2;
    struct kdnode* node = newnode(data_sorted_temp[med],data_sorted_temp);
    node->left = left_child(data_sorted_temp,med);
    node->right = right_child(data_sorted_temp,med);
    
    /*******VARIABLES******/
    double dist,dist_minheap,dist_maxheap,dist_left,dist_right;
    int iter;
    struct kdnode* ptr;
    vector<double> query_point;
    vector< vector<double> > query_pt;
    fstream query_file;
    ofstream result_file;
    result_file.open("results.txt");
    int itr,no_of_query_points,count;     
    
    string query_line;
    vector<double> row(1, dim);
    vector<double> vec;
    struct kdnode* temp;
    
    /************************Doing KNN Query*****************************/    
    /***Reading Query File***/
    
    auto start = chrono::steady_clock::now();   
    cout << 0 << endl;    
    cin >> query_file_path >> k; 
	//query_file_path="20_set.txt";
	//k=100;	
    
    query_file.open(query_file_path);    
    getline(query_file,query_line);
    istringstream iss_query(query_line); 
    iss_query>>dim;    iss_query>>no_of_query_points;     
    for (i = 0; i<no_of_query_points; ++i)  {   
        getline(query_file,query_line);
        istringstream iss_query(query_line);         
        query_pt.push_back(row);
        for (j = 0; j<dim; ++j)
        {
            iss_query>>r;                               
            query_pt[i].push_back(r);
        }        
    }    
    
     for(itr=0;itr<no_of_query_points;++itr){
      
        query_point = query_pt[itr];   
        
        /***Initializing min heap of MBR***/
        dist = euclidean(query_point,node->mbr);
        pq_min.push(Point(dist,node));
        /*** Main algo of KNN***/    
        /*****Filling k size MAX HEAP********/
        iter = 1;
        while(iter<=(k+1)) {
            //if(pq_min.empty())
             //   break;  
            Point p = pq_min.top();
            pq_min.pop();       
            ptr=p.getY();
            dist_minheap = euclidean_answerSet(query_point,ptr->val);
            pq.push(Point(dist_minheap,ptr));
            if(ptr->left){                
                dist_left = euclidean( query_point,(ptr->left)->mbr );
                pq_min.push(Point(dist_left,ptr->left));
		
            }
            if(ptr->right){
                dist_right = euclidean( query_point,(ptr->right)->mbr );
                pq_min.push(  Point( dist_right,ptr->right)    );
		
            }
            ++iter;
        }
		
        while(true){        
            if(pq_min.empty())
                break;        
            Point p = pq_min.top();
            pq_min.pop();
            ptr = p.getY();
            dist_minheap = euclidean_answerSet(query_point,ptr->val);
            Point p1 = pq.top();
            dist_maxheap = p1.getX();
            //if(p.getX()>dist_maxheap)
               // break;
            if(p.getX()<dist_maxheap){            
				pq.pop();
				pq.push(Point(dist_minheap,ptr));        
				if(ptr->left)
				{
					dist_left = euclidean(query_point,((ptr->left)->mbr));
					if(dist_left<(pq.top()).getX())
						pq_min.push(Point(dist_left,(ptr->left)));
	
					
				}
				if(ptr->right)
				{
					dist_right = euclidean(query_point,((ptr->right)->mbr));
					if(dist_right<(pq.top()).getX())                
						pq_min.push(Point(dist_right,(ptr->right)));     
                  					
				}  
			}
			
        }
        
        // Printing points and their distances
        
        /*while (pq.empty() == false){
            Point p = pq.top();
            result_file<< p.getX() << "   ";
            struct kdnode* temp = p.getY();
            vec = temp->val;
            for(i=1;i<=dim;++i)
                result_file<<vec[i]<<" ";     
            result_file << endl;
            pq.pop();
        }*/
		list<list<double>> l;
        list<double> tempList; 
        pq.pop();		
        while (pq.empty() == false)
        {
            Point p = pq.top();
            //result_file<< p.getX() << space;
             temp = p.getY();
            vec = temp->val;
            for(i=1;i<=dim;++i)
            {    //result_file<<vec[i]<<space;     
                tempList.push_back(vec[i]);
                //v[counter].push_back(vec[i]);
            }            
            //result_file << endl;            
            l.push_front(tempList);
            tempList.clear();            
            pq.pop();
        }
        count=1;
        for(auto it=l.begin(); it!=l.end(); ++it)
        {
            for(auto jt = (*it).begin(); jt!=(*it).end(); ++jt)
                result_file<< std::setprecision(20)<<*jt<<space;
            result_file<<endl;
        }
    }
    auto stop = chrono::steady_clock::now();
    
    cout << 1 << endl;
    query_file.close();     
    result_file.close();        
    cerr<<"ns:-"<<chrono::duration_cast<chrono::nanoseconds>(stop-start).count()<<"ns"<<endl;
    cerr<<"micros:-"<<chrono::duration_cast<chrono::microseconds>(stop-start).count()<<"micros"<<endl;
    cerr<<"millis:-"<<chrono::duration_cast<chrono::milliseconds>(stop-start).count()<<"millis"<<endl;
    cerr<<"s:-"<<chrono::duration_cast<chrono::seconds>(stop-start).count()<<"s"<<endl;
    //for(double n : query_point) 
       //std::cerr << std::setprecision(20)<< n << '\t';
    //getch();
    return 0;
}