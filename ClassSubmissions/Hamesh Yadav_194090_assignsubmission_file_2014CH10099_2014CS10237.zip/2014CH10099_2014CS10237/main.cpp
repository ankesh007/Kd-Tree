#include <iostream>
#include <stdlib.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <tuple>
#include "sequential_scan.cpp"

using namespace std;


class Compare
{
public:
  explicit Compare(int column) : m_column(column) {}
  bool operator()(const vector<double>& lhs, const vector<double>& rhs)
  {
    // what do we do if lhs or rhs don't have (m_column + 1) elements?
    return lhs[m_column] < rhs[m_column];
  }
private:
  int m_column;
};



int D;
bool globalk = true;

struct Node{
    vector<double> point;
    int index;
    vector<double> min;
    vector<double> max;
    bool child ;
    Node *left, *right, *parent;
    Node(): point(D) {}
};

struct Node* newNode(vector<double> arr, Node* root, int cd, bool child, int index){
    struct Node* temp = new Node;

    for (unsigned int i=0; i<arr.size(); ++i) {
        temp->point[i] = arr[i];
    }

    if(globalk){
        temp->left = temp->right = temp->parent = NULL;
        temp->index = index;
        globalk = false;
        return temp;
    }

    temp->left = temp->right = NULL;
    temp->index = index;
    temp->parent = root;
    temp->min = temp->parent->min;
    temp->max = temp->parent->max;
    if(child == false){
        if(cd == 0){
            temp->max[D-1] = temp->parent->point[D-1];
            temp->child = false;    
        }
        else{
            temp->max[cd-1] = temp->parent->point[cd-1];
            temp->child = false;
        }
    }
    if(child == true){
        if(cd == 0){
            temp->min[D-1] = temp->parent->point[D-1];
            temp->child = true;    
        }
        else{
            temp->min[cd-1] = temp->parent->point[cd-1];
            temp->child = true;
        }
    }
    return temp;
}

Node *insertRec(Node* root, vector<double> &point, unsigned depth, Node* parent, bool child, int index){

    unsigned cd = depth % D;
    if (root == NULL) return newNode(point, parent, cd, child,index);


    if (point[cd] < (root->point[cd])) root->left = insertRec(root->left, point, depth + 1, root, false, index);
    else root->right = insertRec(root->right, point, depth + 1, root, true, index);

    return root;
}


struct max_heap {
    public:
    /*bool operator()(pair< double , int > n1,pair< double , int > n2) {
        return n1.first<n2.first;
    }*/
    bool operator()(pair< double , pair<int, vector<double> > > n1, pair< double , pair<int, vector<double> > > n2) {
        //cout<<n1.second.second[0]<<" "<<n2.second.second[0]<<" "<<(n1.first - n2.first)<<endl;
        //if((n1.first - n2.first) == 0.0) cout<<"yes"<<endl;
        if(fabs(n1.first - n2.first) < 0.00000000000000001){
            //cout<<"here in comp "<<endl;
            for(int i=0; i<n1.second.second.size(); ++i){
                if(n1.second.second[i] != n2.second.second[i]) return n1.second.second[i] < n2.second.second[i] ;
            }
        }
        else return n1.first<n2.first;
    }
};

struct min_heap {
    public:
    bool operator()(pair< double , Node* > n1,pair< double , Node* > n2) {
        return n1.first>n2.first;
    }
};


double min_dist(vector<double> &query,Node* n)
{
    int len = query.size();
    double dist = 0,temp=0;
    for (int i = 0; i < len; ++i)
    {
        if(query[i] < n->min[i])
        {
            temp = n->min[i] -query[i];
        }
        else if(query[i] > n->max[i])
        {
            temp = query[i] - n->max[i];
        }
        else
        {
            temp = 0;
        }
        dist += pow(temp,2);
    }
    return dist;
}



queue<int> order_of_input(vector<vector<double> > &store)
{
    queue<int> ans;
    queue<vector<int> > temp;
    sort(store.begin(),store.end(),Compare(0));
    int len = store.size();
    
    ans.push(store[(len-1)/2].back());
    
    std::vector<int> t1,t2;
    t1.push_back(0);
    t1.push_back((len-3)/2);
    t1.push_back(1);
    t2.push_back((len+1)/2);
    t2.push_back(len-1);
    t2.push_back(1);
    temp.push(t1);
    temp.push(t2);
    t1.clear();
    t2.clear();
    std::vector<int> p;
    int dim = store[0].size() - 1;
    int l;
    while(!temp.empty())
    {
        p = temp.front();
        l = p[0];
        if(p[0] <p[1])
        {   
            sort(store.begin()+p[0],store.begin()+p[1]+1,Compare(p[2]%dim));
            l = (p[0] + p[1])/2;    
        }
        
        ans.push(store[l].back());
        if(p[1] == p[0] + 1)
        {
            t2.push_back(p[1]);
            t2.push_back(p[1]);
            t2.push_back(p[2]+1);
            temp.push(t2);
            t2.clear();   
        }
        else if(p[0] < p[1])
        {
            t1.push_back(p[0]);
            t1.push_back(l-1);
            t1.push_back(p[2]+1);
            t2.push_back(l+1);
            t2.push_back(p[1]);
            t2.push_back(p[2]+1);
            temp.push(t1);
            temp.push(t2);
            t1.clear();
            t2.clear();
        }
        temp.pop();
    }
    return ans;
}



// //bfa starts here
// vector<vector<double> > bfa(Node* root, vector<vector<double> > &store, vector<double> &query, int k)
// {
//     priority_queue< pair<double,int>,vector< pair<double,int> >,max_heap > ans_set;
//     double dist;
//     int index;
//     std::pair<double, int> a;
//     priority_queue< pair<double,Node*>,vector< pair<double,Node*> >,min_heap > candidate_mbr;
//     dist = min_dist(query,root);
//     std::pair<double, Node*> b = std::make_pair(dist,root);
//     candidate_mbr.push(b);
//     std::pair<double, Node*> temp;
//     while(!candidate_mbr.empty())
//     {
//         b = candidate_mbr.top();
//         candidate_mbr.pop();
//         if(ans_set.size()<k)
//         {
//             dist = L2_dist(b.second->point,query);
//             a = std::make_pair(dist,b.second->index);
//             ans_set.push(a);
//             if(b.second->left){
//                 dist = min_dist(query,b.second->left);
//                 temp = std::make_pair(dist,b.second->left);
//                 candidate_mbr.push(temp);
//             }
//             if (b.second->right)
//             {
//                 dist = min_dist(query,b.second->right);
//                 temp = std::make_pair(dist,b.second->right);
//                 candidate_mbr.push(temp);
//             }
//         }
//         else
//         {    
//             if(b.second->left) 
//             {
//                 dist = min_dist(query,b.second->left);
//                 if(dist < ans_set.top().first)
//                 {
//                     temp = std::make_pair(dist,b.second->left);
//                     candidate_mbr.push(temp);
//                 }   
//             }
//             if(b.second->right) 
//             {
//                 dist = min_dist(query,b.second->right);
//                 if(dist < ans_set.top().first)
//                 {
//                     temp = std::make_pair(dist,b.second->right);
//                     candidate_mbr.push(temp);
//                 }
//             }
//             dist = L2_dist(b.second->point,query);    
//             if( dist < ans_set.top().first)
//             {
//                 a = std::make_pair(dist,b.second->index);
//                 ans_set.push(a);
//                 ans_set.pop();
//             }
//         }
//     }
//     vector<vector<double> > ans;
//     vector<double> t;
//     while (!ans_set.empty()) {
//         ans.push_back(store[ans_set.top().second]);
//         ans_set.pop();
//     }
//     std::reverse(ans.begin(),ans.end());
//     return ans;
// }
// //bfa ends








vector<vector<double> > bfa(Node* root, vector<vector<double> > &store, vector<double> &query, int k)
{
    priority_queue< pair<double,pair<int, vector<double>>>,vector< pair<double,pair<int, vector<double>>> >,max_heap > ans_set;
    double dist;
    int index;
    std::pair<double, pair<int, vector<double>>> a;
    priority_queue< pair<double,Node*>,vector< pair<double,Node*> >,min_heap > candidate_mbr;
    dist = min_dist(query,root);
    std::pair<double, Node*> b = std::make_pair(dist,root);
    candidate_mbr.push(b);
    std::pair<double, Node*> temp;
    while(!candidate_mbr.empty())
    {
        b = candidate_mbr.top();
        candidate_mbr.pop();
        if(ans_set.size()<k)
        {
            dist = L2_dist(b.second->point,query);
            a = std::make_pair(dist,make_pair(b.second->index, store[b.second->index]));
            ans_set.push(a);
            if(b.second->left){
                dist = min_dist(query,b.second->left);
                temp = std::make_pair(dist,b.second->left);
                candidate_mbr.push(temp);
            }
            if (b.second->right)
            {
                dist = min_dist(query,b.second->right);
                temp = std::make_pair(dist,b.second->right);
                candidate_mbr.push(temp);
            }
        }
        else
        {    
            if(b.second->left) 
            {
                dist = min_dist(query,b.second->left);
                if(dist < ans_set.top().first)
                {
                    temp = std::make_pair(dist,b.second->left);
                    candidate_mbr.push(temp);
                }   
            }
            if(b.second->right) 
            {
                dist = min_dist(query,b.second->right);
                if(dist < ans_set.top().first)
                {
                    temp = std::make_pair(dist,b.second->right);
                    candidate_mbr.push(temp);
                }
            }
            dist = L2_dist(b.second->point,query);    
            if( dist < ans_set.top().first)
            {
                a = std::make_pair(dist,make_pair(b.second->index, store[b.second->index]));
                ans_set.push(a);
                ans_set.pop();
            }
        }
    }
    vector<vector<double> > ans;
    vector<double> t;
    while (!ans_set.empty()) {
        ans.push_back(store[ans_set.top().second.first]);
        ans_set.pop();
    }
    std::reverse(ans.begin(),ans.end());
    return ans;
}








int main(int argc, char* argv[]) {

    char* dataset_file = argv[1];

    // [TODO] Construct kdTree using dataset_file here

    //reading from input file
    std::fstream myfile(dataset_file, std::ios_base::in);

    double a;
    myfile >> a;
    int Dimension = a;
    D = Dimension;
    myfile >> a;
    int number_of_lines = a;
    vector<vector<double> > store ;
    vector<vector<double> > store_seq ;
    vector<vector<double> > store_copy ;
    std::vector<double> vqsaq;
    
    for (int i = 0; i < number_of_lines; i++)
    {
        for(int j = 0;j<Dimension;j++)
        {
            myfile >>a;
            vqsaq.push_back(a);
        }
        store.push_back(vqsaq);
        store_seq.push_back(vqsaq);
        store_copy.push_back(vqsaq);
        vqsaq.clear();
    }
    //done reading from input file



    struct Node *root = NULL;  


    vector<double> root_min;
    vector<double> root_max;
    for(int i=0; i<D; ++i){
        sort(store_copy.begin(), store_copy.end(), Compare(i));
        root_min.push_back(store_copy[0][i]);
        root_max.push_back(store_copy[store_copy.size()-1][i]);
    }


    for (int i = 0; i < store_seq.size(); ++i)
    {
        store_seq[i].push_back(i);
    }

    queue<int> vqsa = order_of_input(store_seq);
    int i = 0;
    while(!vqsa.empty())
    {
        root = insertRec(root,store[vqsa.front()], 0, NULL, false, vqsa.front());
        if(i==0){
            root->min = root_min;
            root->max = root_max;
            i++;
        }
        vqsa.pop();
    }

    /*vector<Node*> test;
    test.push_back(root);
    Node nb;
    while(!test.empty())
    {
        for (int i = 0; i < test[0]->point.size(); ++i)
        {
            cout << test[0]->point[i]<<" ";
        }
        if(test[0]->child) cout<<"right"<<endl;
        else cout<<"left"<<endl;

        for (int i = 0; i < test[0]->point.size(); ++i)
        {
            cout << test[0]->min[i]<<","<<test[0]->max[i]<<"   ";
        }
        cout << endl;
        if(test[0]->left) test.push_back(test[0]->left);
        if(test[0]->right) test.push_back(test[0]->right);
        test.erase(test.begin());
    }*/
    // Request name/path of query_file from parent by just sending "0" on stdout
    cout << 0 << endl;

    // Wait till the parent responds with name/path of query_file and k | Timer will start now
    char* query_file = new char[100];
    int k = 5;
    cin >> query_file >> k;
    cerr << query_file << " " << dataset_file << " " << k << endl;

    // [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

    //reading from query_file
    std::fstream queryfile(query_file, std::ios_base::in);

    queryfile >> a;
    Dimension = a;
    queryfile >> a;
    number_of_lines = a;
    vector<vector<double> > query_store;
    for (int i = 0; i < number_of_lines; i++)
    {
        for(int j = 0;j<Dimension;j++)
        {
            queryfile >>a;
            vqsaq.push_back(a);
        }
        query_store.push_back(vqsaq);
        vqsaq.clear();
    }
    //done reading from query file


    /*string outputfilename = "results_seq.txt";
    ofstream resultfile;
    resultfile.open(outputfilename);
    double two, hundred = 0;

    vector<vector<double> > result_store;

    for(int l=0; l<query_store.size(); ++l){
        result_store = seq_scan(store, query_store[l], k);

        //two += sqrt(L2_dist(result_store[1], query_store[l]));
        //hundred += sqrt(L2_dist(result_store[99], query_store[l]));

        for(int i=0; i<result_store.size(); ++i){
            for(int j=0; j<result_store[i].size(); ++j){
                resultfile<<result_store[i][j]<<" ";
        }
        resultfile<<"\n";
    }
    result_store.clear();
    }*/

    //cout<<double(two/hundred)<<endl;
    //resultfile.close();


    //computing results from mbr
    string outputfilename = "results.txt";
    ofstream resultfile;
    resultfile.open(outputfilename);
    vector<vector<double> > result_store;

    for(int l=0; l<query_store.size(); ++l){
        result_store = bfa(root, store, query_store[l], k);

        for(int i=0; i<result_store.size(); ++i){
            for(int j=0; j<result_store[i].size(); ++j){
                resultfile<<result_store[i][j]<<" ";
        }
        resultfile<<"\n";
    }
    result_store.clear();
    }   

    resultfile.close();
    //computation of results from mbr done

    // Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
    cout << 1 << endl;
}
