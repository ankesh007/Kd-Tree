#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;

struct CompareByFirst {
    public:
    bool operator()(pair< double , pair<int, vector<double> > > n1, pair< double , pair<int, vector<double> > > n2) {
    	//cout<<n1.second.second[0]<<" "<<n2.second.second[0]<<" "<<(n1.first - n2.first)<<endl;
    	//if((n1.first - n2.first) == 0.0) cout<<"yes"<<endl;
        if(fabs(n1.first - n2.first) < 0.00000000000000001){
        	//cout<<"here in comp "<<endl;
        	for(int i=0; i<n1.second.second.size(); ++i){
        		if(n1.second.second[i] != n2.second.second[i]) return n1.second.second[i] < n2.second.second[i] ;
        	}
        }
        else return n1.first<n2.first;
    }
};

double L2_dist(vector<double> &v,vector<double> &q)
{
	double ans = 0;
	int len = v.size();
	for (int i = 0; i < len; ++i)
	{
		ans += pow(v[i] - q[i],2);
	}
	return ans;
}


//lexicographic function
/*vector<double> lexicographic(vector<double> &p1, vector<double> &p2){
	for(int i=0; i<p1.size(); ++i){
		if(p1[i]<p2[i]) return p1;
		else if (p1[i]>p2[i]) return p2;
	}
}*/
//done lexicographic


vector<vector<double> > seq_scan(vector<vector<double> > &store, vector<double> &query, int k)
{
	vector<double> dist;
	vector<int> index;
	int len = store.size();
	for(int i = 0; i < len; i++)
	{
		index.push_back(i);
		dist.push_back(L2_dist(store[i],query)); 
	}
	priority_queue<pair<double, pair<int, vector<double> >>, vector<pair<double, pair<int, vector<double> >> >,CompareByFirst > q;
	for(int i=0;i<k;i++)
	{
		std::pair<double, pair<int, vector<double> >> a = std::make_pair(dist[i], make_pair(index[i], store[index[i]]));
		//cout << "holaa"<<endl;		
		q.push(a);
		//cout << "byee"<<endl;
	}
	for(int i=k;i<len;i++)
	{	
		//making changes
		/*if(q.top().first == dist[i]){
			cout<<"same distance"<<endl;
			vector<double> lv = lexicographic(store[i], store[q.top().second]);
			//q.pop();
			//std::pair<double, int> a = std::make_pair(dist[i],index[i]);
			//q.push(a);
		}*/
		//done with changes

		if(q.top().first >= dist[i])
		{
			std::pair<double, pair<int, vector<double> >> a = std::make_pair(dist[i], make_pair(index[i], store[index[i]]));
			//cout << "holaa 2 "<<endl;
			q.push(a);
			q.pop();
			//cout << "byee 2"<<endl;
		}
	}
	//cout << "here"<<endl;
	vector<vector<double> > ans;
	vector<double> t;
	while (!q.empty()) {
        // t.push_back(q.top().first);
        // t.push_back(q.top().second);
        ans.push_back(q.top().second.second);
        // t.clear();
        q.pop();
    }
    std::reverse(ans.begin(),ans.end());
    return ans;
}
