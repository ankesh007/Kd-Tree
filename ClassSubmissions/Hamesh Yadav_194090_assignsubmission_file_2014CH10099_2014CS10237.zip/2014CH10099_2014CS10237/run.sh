#!/bin/bash
g++ -O3 main.cpp; ./a.out $1
#python sample.py $1