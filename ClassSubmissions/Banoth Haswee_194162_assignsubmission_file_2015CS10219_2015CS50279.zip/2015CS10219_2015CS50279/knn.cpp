#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <sstream>
#include<math.h>
#include <bits/stdc++.h>
#include <cstdio>
#include <ctime>

using namespace std;

int n;
int k;

struct node{
	double point[20];
	node *left = NULL;
	node *right = NULL;
	double median;
	bool leaf;
	int depth;
	double minMax[20][2];
};


struct  maxHeap_node{
    double key;
    int height;
    int size;
    maxHeap_node *left;
    maxHeap_node *right;
    double point[20];
};
 

struct minHeap_node
{
	node* vertex;
	double key;
};


double distance(double p1[], double p2[]){
	double ans=0.0;
	for (int i = 0; i < n; ++i)
	{
		ans = ans + (p1[i]-p2[i])*(p1[i]-p2[i]);
	}
	return sqrt(ans);
}


void copyArrayElements(double to[],double from[]){
	for (int i = 0; i < n; ++i)
	{
		to[i] = from[i];
	}
}

void swap(double *a, double *b)
{
    double t = *a; *a = *b; *b = t;
}

void swapArrays(double to[],double from[]){
	double temp[20];
	copyArrayElements(temp,from);
	copyArrayElements(from,to);
	copyArrayElements(to,temp);
}
 

int prior(double point1[],double point2[]){

    for(int i=0;i<n;i++){
        if(point1[i]<point2[i]){
            return 1;
        }
        else if(point1[i]>point2[i]){
            return 2;
        }
    }
    return 0;

}

// start of min heap

void printArray(double array[]){
	for (int i = 0; i < n; ++i)
	{
		cout<<array[i]<<",";
	}	
	cout<<"\n";

}


struct PriorityQueue 
{
private:
	// vector to store heap elements
	vector<minHeap_node *> A;

	// return parent of A[i]
	// don't call this function if it is already a root minHeap_node
	int PARENT(int i) 
	{ 
		return (i - 1) / 2; 
	}

	// return left child of A[i]	
	int LEFT(int i) 
	{ 
		return (2 * i + 1); 
	}

	// return right child of A[i]	
	int RIGHT(int i) 
	{ 
		return (2 * i + 2); 
	}

	// Recursive Heapify-down algorithm
	// the minHeap_node at index i and its two direct children
	// violates the heap property
	void heapify_down(int i)
	{
		// get left and right child of minHeap_node at index i
		int left = LEFT(i);
		int right = RIGHT(i);

		int smallest = i;

		// compare A[i] with its left and right child
		// and find smallest value
		if (left < size() && A[left]->key < A[i]->key)
			smallest = left;

		if (right < size() && A[right]->key < A[smallest]->key)
			smallest = right;

		// swap with child having lesser value and 
		// call heapify-down on the child
		if (smallest != i) {
			swap(A[i]->key, A[smallest]->key);
			// swapArrays(A[i]->point,A[smallest]->point);
			node *temp = new node();
			temp = A[smallest]->vertex;
			A[smallest]->vertex = A[i]->vertex;
			A[i]->vertex = temp;
			heapify_down(smallest);
		}
	}

	// Recursive Heapify-up algorithm
	void heapify_up(int i)
	{
		// check if minHeap_node at index i and its parent violates 
		// the heap property
		if (i && A[PARENT(i)]->key > A[i]->key) 
		{
			// swap the two if heap property is violated
			swap(A[i]->key, A[PARENT(i)]->key);
			// swapArrays(A[i]->point, A[PARENT(i)]->point);			
			node *temp = new node();
			temp =  A[PARENT(i)]->vertex;
			A[PARENT(i)]->vertex = A[i]->vertex;
			A[i]->vertex = temp;		
			heapify_up(PARENT(i));
		}
	}
	
public:
	// return size of the heap
	unsigned int size()
	{
		return A.size();
	}

	// function to check if heap is empty or not
	bool empty()
	{
		return size() == 0;
	}
	
	// insert key into the heap
	void push(minHeap_node *key)
	{
		// insert the new element to the end of the vector
		A.push_back(key);

		// get element index and call heapify-up procedure
		int index = size() - 1;
		heapify_up(index);
	}

	// function to remove element with highest priority (present at root)
	void pop()
	{
		try {
			// if heap has no elements, throw an exception
			if (size() == 0)
				throw out_of_range("Vector<X>::at() : "
						"index is out of range(Heap underflow)");

			// replace the root of the heap with the last element
			// of the vector
			A[0] = A.back();
			A.pop_back();

			// call heapify-down on root minHeap_node
			heapify_down(0);
		}
		// catch and print the exception
		catch (const out_of_range& oor) {
			cout << "\n" << oor.what();
		}
	}

	// function to return element with highest priority (present at root)
	minHeap_node* top()
	{
		try {
			// if heap has no elements, throw an exception
			if (size() == 0)
				throw out_of_range("Vector<X>::at() : "
						"index is out of range(Heap underflow)");

			// else return the top (first) element
			return A[0];	// or return A[0];
		}
		// catch and print the exception
		catch (const out_of_range& oor) {
			cout << "\n" << oor.what();
		}
	}
};

// end of min heap
//start of max heap

int max(int a, int b){
    return (a>b)?a:b;
}
 
maxHeap_node* createmaxHeap_node(double val,double point[])
{
    maxHeap_node *temp = new maxHeap_node();
    temp->key=val;
    temp->size=1;
    temp->height=0;
    temp->left=NULL;
    temp->right=NULL;
    copyArrayElements(temp->point,point);
    return temp;
}
 
int Size(maxHeap_node *t)
{
    if(t==NULL)
        return 0;
    else
        return t->size;
}
 
int Height(maxHeap_node *t)
{
    if(t==NULL)
        return -1;
    else
        return t->height;
}
 
void updateHeightSize(maxHeap_node *t)
{
    t->height = max(Height(t->left),
                        Height(t->right))+1;
    t->size = Size(t->left) + Size(t->right)+1;
}
 
maxHeap_node* insert(maxHeap_node *n, double key,double point[])
{
    if(n==NULL){
    	// cout<<"bitch";
        n = createmaxHeap_node(key,point);
    	// cout<<"bitch";

    	// cout<<n->key<<","<<n->point[0]<<endl;        
        return n;
    }
    if(n->left==NULL ||
           Size(n->left)< int(pow(2, Height(n->left)+1))-1 ||
           Size(n->right)==Size(n->left)) 
        n->left = insert(n->left, key,point);
    else
        n->right = insert(n->right,key,point);
 
    if((n->left!=NULL && n->left->key >= n->key) ||
            (n->right!=NULL && n->right->key >= n->key)){
        if(n->left==NULL){
            if(n->key==n->right->key){
                if(prior(n->point,n->right->point)==1){

                    swap(n->key, n->right->key);
                    swapArrays(n->point,n->right->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->right->key);
                    swapArrays(n->point,n->right->point);                    

            }

        }
        else if(n->right==NULL){
            if(n->key==n->left->key){
                if(prior(n->point,n->left->point)==1){
                    swap(n->key, n->left->key);
                    swapArrays(n->point,n->left->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->left->key);
                    swapArrays(n->point,n->left->point);                    
                
            }
            }
        else{
            if(n->left->key > n->right->key){
            if(n->key==n->left->key){
                if(prior(n->point,n->left->point)==1){
                    swap(n->key, n->left->key);
                    swapArrays(n->point,n->left->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->left->key);
                    swapArrays(n->point,n->left->point);                    
                
            }                }
            // if(n->left->key == n->right->key){
            // 		if(n->left)
            // }
            else{
            if(n->key==n->right->key){
                if(prior(n->point,n->right->point)==1){
                    swap(n->key, n->right->key);
                    swapArrays(n->point,n->right->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->right->key);
                    swapArrays(n->point,n->right->point);                    

            }                }
        }
    }
 
    updateHeightSize(n);
    return n;
}
 
maxHeap_node* top(maxHeap_node *root){
    return root;
}
 
void heapify(maxHeap_node *n)
{
    if(!n)
        return;
    while((n->left!=NULL && n->left->key>n->key) ||
              (n->right!=NULL && n->right->key>n->key)){
        if(n->left==NULL){
            swap(n->key, n->right->key);
            swapArrays(n->point,n->right->point);
            n = n->right;
        }
        else if(n->right==NULL){
            swap(n->key, n->left->key);
            swapArrays(n->point,n->left->point);
            n = n->left;
        }
        else{
            if(n->left->key > n->right->key){
                swap(n->key, n->left->key);
            	swapArrays(n->point,n->left->point);
                n = n->left;
            }
            else{
                swap(n->key, n->right->key);
            	swapArrays(n->point,n->right->point);
                n = n->right;
            }
        }
    }
}
 
maxHeap_node* remove(maxHeap_node *n, maxHeap_node *root)
{
    if(n==NULL)
        return NULL;
    if(n->left==NULL && n->right==NULL){
        swap(root->key, n->key);
        swapArrays(root->point,n->point);
        delete n;
        return NULL;
    }
    else if(Size(n->left) > Size(n->right))
        n->left = remove(n->left, root);
    else
        n->right = remove(n->right, root);
 
    updateHeightSize(n);
}
 
void pop(maxHeap_node **heap)
{
    *heap = remove(*heap, *heap);
    heapify(*heap);
}
 
void display(maxHeap_node *x)
{
    // cout<<x->key<<"->";
    for (int i = 0; i < n; ++i)
    {
    	cout<<x->point[i]<<",";
    }
    cout<<endl;
}
 
// void printArray(double point[]){
// 	for (int i = 0; i < n; ++i)
//     {
//     	cout<<point[i]<<",";
//     }
//     cout<<endl;
// }

//end of max heap

double maxOfThree(double a, double b,double c){
	if(a>b){
		if(a>c) return a;
		else return c;
	}
	else{
		if(b>c) return b;
		else return c;
	}

	return a;
}

double minOfThree(double a, double b,double c){
	if(a<b){
		if(a<c) return a;
		else return c;
	}
	else{
		if(b<c) return b;
		else return c;
	}

	return a;
}
//start
// A function to merge the two half into a sorted data.
void Merge(double** a, int low, int high, int mid,int axis)
{
	// We have low to mid and mid+1 to high already sorted.
	int i, j, k;
	double temp[high-low+1][20];
	i = low;
	k = 0;
	j = mid + 1;
 
	// Merge the two parts into temp[].
	while (i <= mid && j <= high)
	{
		if (a[i][axis] < a[j][axis])
		{
		 	copyArrayElements(temp[k],a[i]);	// temp[k] = a[i];
			k++;
			i++;
		}
		else
		{
			copyArrayElements(temp[k],a[j]); // temp[k] = a[j];
			k++;
			j++;
		}
	}
 
	// Insert all the remaining values from i to mid into temp[].
	while (i <= mid)
	{
		copyArrayElements(temp[k],a[i]);	// temp[k] = a[i];
		k++;
		i++;
	}
 
	// Insert all the remaining values from j to high into temp[].
	while (j <= high)
	{
		copyArrayElements(temp[k],a[j]);	// temp[k] = a[j];
		k++;
		j++;
	}
 
 
	// Assign sorted data stored in temp[] to a[].
	for (i = low; i <= high; i++)
	{
		copyArrayElements(a[i],temp[i-low]);	// a[i] = temp[i-low];
	}
}
 
// A function to split array into two parts.
void MergeSort(double** a, int low, int high,int axis)
{
	// cout<<"1wtf"<<"\n";

	int mid;
	if (low < high)
	{
		mid=(low+high)/2;
		// Split the data into two half.
		MergeSort(a, low, mid,axis);
		MergeSort(a, mid+1, high,axis);
 
		// Merge them to get sorted output.
		Merge(a, low, high, mid,axis);
	}
}
 
//end



double mbrDistance(double point[],node *tree_node){
	double ans = 0;
	for (int i = 0; i < n; ++i)
	{
		if(point[i] < tree_node->minMax[i][0]){
			ans =  ans + (tree_node->minMax[i][0] - point[i])*(tree_node->minMax[i][0] - point[i])*(1.0);			
		}
		else if(point[i] > tree_node->minMax[i][1]){
			ans =  ans + (point[i] - tree_node->minMax[i][1])*(point[i] - tree_node->minMax[i][1])*(1.0);
		}
		else{
			ans = ans;
		}		
	}
	return sqrt(ans);
}	

// len = length of the points(how many points are there)
node* build_kdtree(double** points,int depth,int len)
{
	if(len==0){
		return NULL;
	}

	if(len == 1){
		node *leaf = new node();
		leaf->depth=depth;
		leaf->leaf=true;
		copyArrayElements(leaf->point,points[0]);
		return leaf;
	}

	int axis = depth % n;
	// cout<<"wtf"<<"\n";
	// cout<<"len:"<<len<<"\n";

	MergeSort(points,0,len-1,axis);
	// cout<<"MERGESORT"<<"\n";
	// for (int i = 0; i < len; ++i)
	// {
	// 	printArray(points[i]);
	// }
	double mid= 0;
	int leftLength=0;
	int rightLength = 0;
	int i=0;
	node *head= new node();

	// double leftArray[20000][20],rightArray[20000][20];
	   double **leftArray = new double*[len/2 +100];
	   double **rightArray = new double*[len/2 +100];
	  
	   for (int i = 0; i < (len/2+100); i++) {
	      leftArray[i] = new double[20];
	      rightArray[i] = new double[20];
	   }
	if (len%2==0)
	{
		mid = points[len/2 -1][axis];
		copyArrayElements(head->point,points[len/2 -1]);
		while(i < (len/2) -1)
		{
			copyArrayElements(leftArray[i],points[i]);
			leftLength++;
			i++;
		}
		int x = i+1;
		i=0;
		while((i+x)<len)
		{
			copyArrayElements(rightArray[i],points[x+i]);
			rightLength++;
			i++;
		}
	}

	else{

		mid = points[len/2][axis];
		copyArrayElements(head->point,points[len/2]);
		i=0;
		while(i< (len/2))
		{
			copyArrayElements(leftArray[i],points[i]);
			leftLength++;
			i++;
		}
		int x = i+1;
		i=0;
		while((i+x)<len)
		{
			copyArrayElements(rightArray[i],points[x+i]);
			rightLength++;
			i++;
		}

	}
	// cout<<"leftArray:"<<"\n";
	// for (int i = 0; i < leftLength; ++i)
	// {
	// 	printArray(leftArray[i]);
	// }
	// cout<<"rightArray:"<<"\n";
	// for (int i = 0; i < rightLength; ++i)
	// {
	// 	printArray(rightArray[i]);
	// }
	head->median = mid;
	head->leaf = false;
	head->depth=depth;
	
	if(leftLength==0) head->left = NULL;
	else head->left = build_kdtree(leftArray,depth+1,leftLength);
	if(rightLength==0) head->right = NULL;
	else head->right = build_kdtree(rightArray,depth+1,rightLength);
}

void printTree(node *root, int space)
{
    // Base case
    if (root == NULL)
        return;
 
    // Increase distance between levels
    space += 10;
 
    printTree(root->right, space); 
    cout<<"\n";
    for (int i = 10; i < space; i++)
        cout<<" ";
    	for (int j = 0; j < n; ++j)
    	{
    		cout<<root->point[j]<<",";	
    	}
    	cout<<" MinMax:";
    	for (int j = 0; j < n; ++j)
    	{
    		cout<<"(";    		
    		cout<<root->minMax[j][0]<<".";
    		cout<<root->minMax[j][1]<<".";
    		cout<<")";    		
    	}
    cout<<"\n";
 	
    printTree(root->left, space);
}
	
void updateMinMax(node *root){
	// cout<<"why not?";
	if(root->leaf ==  1){
		for (int i = 0; i < n; ++i)
		{
			root->minMax[i][0] = root->point[i];
			root->minMax[i][1] = root->point[i];
		}
		return;
	}
	if(root->left == NULL) {
		// cout<<"1:here?";
		if(root->right != NULL) updateMinMax(root->right);
		for (int i = 0; i < n; ++i)
		{
			root->minMax[i][0] = root->point[i];
			root->minMax[i][1] = root->point[i];
		}
		for (int i = 0; i < n; ++i)
		{
			if(root->minMax[i][0]>root->right->minMax[i][0]){
				root->minMax[i][0] = root->right->minMax[i][0];
			}
			if(root->minMax[i][1]<root->right->minMax[i][1]){
				root->minMax[i][1] = root->right->minMax[i][1];
			}
		}
		return;
	}
	if(root->right == NULL) {
		// cout<<"2:here?";
		if(root->left != NULL) updateMinMax(root->left);
		for (int i = 0; i < n; ++i)
		{
			root->minMax[i][0] = root->point[i];
			root->minMax[i][1] = root->point[i];
		}
		for (int i = 0; i < n; ++i)
		{
			if(root->minMax[i][0]>root->left->minMax[i][0]){
				root->minMax[i][0] = root->left->minMax[i][0];
			}
			if(root->minMax[i][1]<root->left->minMax[i][1]){
				root->minMax[i][1] = root->left->minMax[i][1];
			}
		}
		return;

	}
	else{
		if(root->left != NULL) updateMinMax(root->left);
		if(root->right != NULL) updateMinMax(root->right);

		for (int i = 0; i < n; ++i)
		{
			root->minMax[i][0] = root->point[i];
			root->minMax[i][1] = root->point[i];
		}
		for (int i = 0; i < n; ++i)
		{
			root->minMax[i][0] = minOfThree(root->point[i],root->left->minMax[i][0],root->right->minMax[i][0]);
			root->minMax[i][1] = maxOfThree(root->point[i],root->left->minMax[i][1],root->right->minMax[i][1]);			
		}

	}
	return;
}

void findingKNN(node *tree_head,maxHeap_node *max_heap,PriorityQueue min_heap,double query[]){

    minHeap_node *head = new minHeap_node();
    head->vertex = tree_head;
    head->key = distance(tree_head->point,query);
    min_heap.push(head); //min heap is updated

    while(!min_heap.empty()){
    	minHeap_node *temp = min_heap.top();
    	if (max_heap == NULL)
    	{
    		max_heap = insert(max_heap,distance(temp->vertex->point,query),temp->vertex->point);
    		min_heap.pop();
   			
   			if(temp->vertex->left != NULL){
    			double mbrDist = mbrDistance(query,temp->vertex->left);
				
					minHeap_node *temp1 = new minHeap_node();
					temp1->vertex = temp->vertex->left;
					temp1->key = mbrDist;
					min_heap.push(temp1);
				
			}

			if(temp->vertex->right != NULL){
    			double mbrDist = mbrDistance(query,temp->vertex->right);
				
					minHeap_node *temp1 = new minHeap_node();
					temp1->vertex = temp->vertex->right;
					temp1->key = mbrDist;
					min_heap.push(temp1);
				
			}    			
    	}
    	else if(max_heap->size < k ){
    		max_heap = insert(max_heap,distance(temp->vertex->point,query),temp->vertex->point);
    		min_heap.pop();
   			
   			if(temp->vertex->left != NULL){
    			double mbrDist = mbrDistance(query,temp->vertex->left);
				
					minHeap_node *temp1 = new minHeap_node();
					temp1->vertex = temp->vertex->left;
					temp1->key = mbrDist;
					min_heap.push(temp1);
				
			}

			if(temp->vertex->right != NULL){
    			double mbrDist = mbrDistance(query,temp->vertex->right);
				
					minHeap_node *temp1 = new minHeap_node();
					temp1->vertex = temp->vertex->right;
					temp1->key = mbrDist;
					min_heap.push(temp1);
				
			}    			
    	}
    	else 
    	{
    		if(distance(temp->vertex->point,query) > top(max_heap)->key){
    	    		min_heap.pop();
    	    	}
    	    	else if(distance(temp->vertex->point,query) == top(max_heap)->key && prior(temp->vertex->point,top(max_heap)->point)==2){
    	    		min_heap.pop();    		
    	    	}
    	    	else{
    	    		min_heap.pop();
    	    		pop(&max_heap);
    				max_heap = insert(max_heap,distance(temp->vertex->point,query),temp->vertex->point);
    	    	}
   			
   			if(temp->vertex->left != NULL){
    			double mbrDist = mbrDistance(query,temp->vertex->left);
				if( mbrDist <= top(max_heap)->key ){
					minHeap_node *temp1 = new minHeap_node();
					temp1->vertex = temp->vertex->left;
					temp1->key = mbrDist;
					min_heap.push(temp1);
				}
			}

			if(temp->vertex->right != NULL){
    			double mbrDist = mbrDistance(query,temp->vertex->right);
				if( mbrDist <= top(max_heap)->key ){
					minHeap_node *temp1 = new minHeap_node();
					temp1->vertex = temp->vertex->right;
					temp1->key = mbrDist;
					min_heap.push(temp1);
				}
			}

   		}
    		


    }

    cout<<"--Heap--"<<endl;
    while(max_heap){
        display(top(max_heap));
        pop(&max_heap);
    }

}

const vector<string> explode1(const string& s)
{
    string str(s);
    string buf; // Have a buffer string
    stringstream ss(str); // Insert the string into a stream

    vector<string> tokens; // Create vector to hold our words

    while (ss >> buf)
        tokens.push_back(buf);
    return tokens;
}

int main(int argc, char const *argv[]){
	// cout<<"Enter n:";
	// cin>>n;
	// cout<<"Enter k:";
	// cin>>k;
	// n=2;
	k=20;
	std::clock_t start1;
    string line;
    string line1;

	int examples;
	cout << argv[1]<<"\n";
	ifstream myfile(argv[1]);
	int query_k;

    if(myfile.is_open()){
        getline(myfile,line);
        std::vector<std::string> splits;
        splits={explode1(line)};
        // cout<<splits[1];
        n=atoi(splits[0].c_str());
        // cout << n <<"n from data\n";
        examples=atoi(splits[1].c_str());
        // cout<<examples<<"total number of examples\n";
    }
        // cout<<n << "\n";
        // cout<<examples<< "\n";
        double **set = new double*[100000];
        for (int i = 0; i < 100000; i++) {
	      set[i] = new double[20];
	    }

        int j=0;
        if(myfile.is_open()){
        // cout<<line[0];
        while(getline(myfile, line)){
            std::vector<std::string> splits;
            splits={explode1(line)};
            for(int i=0;i<n;i++){
                set[j][i]=atof(splits[i].c_str());
            }
            j+=1;

        }
    }
	double query[20] = {0.12502049619,0.00219191247221,0.158140001549,0.940883915857,0.392763605926,0.591349628717,0.0121416626448,0.889649558569,0.541974006709,0.96820015965,0.180777312793,0.328007163638,0.93470559616,0.334347106442,0.408667246085,0.969400423001,0.408434913785,0.606674982286,0.624876079674,0.760959178059};	
	node* tree_head = build_kdtree(set,0,1000);
	updateMinMax(tree_head);
	// printArray(tree_head->point);
	// printTree(tree_head,0);
	cout<<"start";
	start1=clock();
	// ifstream query_file("query_file.txt");
	// getline(query_file,line1);

 //        double query_f[100][20] ;
 //        // for (int i = 0; i < 100; i++) {
	//       // double query_f[i] = new double[20];
	//     // }
    ifstream query_file("query_file_2.txt");
    // getline(query_file,line1);
        if(query_file.is_open()){
        getline(query_file,line);
        std::vector<std::string> splits;
        splits={explode1(line)};
        // cout<<splits[1];
        n=atoi(splits[0].c_str());
        // cout << n << "n from query\n";
        query_k=atoi(splits[1].c_str());
    	// cout << query_k << "num of query points\n";
    }

        double query_f[query_k][n] ;
        j=0;
        if(query_file.is_open()){
        // cout<<line[0];
        while(getline(query_file, line1)){
            std::vector<std::string> splits;
            splits={explode1(line1)};
            for(int i=0;i<n;i++){
                query_f[j][i]=atof(splits[i].c_str());
            }
            j+=1;

        }
    }


	for(j=0;j<query_k;j++){
			maxHeap_node *max_heap = NULL;
			PriorityQueue min_heap;
	findingKNN(tree_head,max_heap,min_heap,query);
}																			
	cout<<"time is " << (clock()-start1)/(double) CLOCKS_PER_SEC<<"\n";
	return 0;
	}
	
