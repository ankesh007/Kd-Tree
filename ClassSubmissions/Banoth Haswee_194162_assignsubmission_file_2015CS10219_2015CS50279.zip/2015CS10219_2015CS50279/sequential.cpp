/* Online algorithm for building max heap. */
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <istream>
#include <sstream>
#include <math.h>
#include <fstream>
#include <vector>
#include <cstdio>
#include <ctime>
using namespace std;

int n ;

struct  node{
    double key;
    int height;
    int size;
    node *left;
    node *right;
    double point[20];
};
 
double distance(double p1[], double p2[]){
	double ans=0.0;
	for (int i = 0; i < n; ++i)
	{
		ans = ans + (p1[i]-p2[i])*(p1[i]-p2[i]);
	}
	return sqrt(ans);
}


void copyArrayElements(double to[],double from[]){
	for (int i = 0; i < n; ++i)
	{
		to[i] = from[i];
	}
}

void swap(double *a, double *b)
{
    double t = *a; *a = *b; *b = t;
}

void swapCordi(double to[],double from[]){
	double temp[20];
	copyArrayElements(temp,from);
	copyArrayElements(from,to);
	copyArrayElements(to,temp);
}
 

int max(int a, int b){
    return (a>b)?a:b;
}
 
node* createNode(double val,double point[])
{
    node *temp = new node();
    temp->key=val;
    temp->size=1;
    temp->height=0;
    temp->left=NULL;
    temp->right=NULL;
    copyArrayElements(temp->point,point);
    return temp;
}
 
int Size(node *t)
{
    if(t==NULL)
        return 0;
    else
        return t->size;
}
 
int prior(double point1[],double point2[]){

    for(int i=0;i<n;i++){
        if(point1[i]<point2[i]){
            return 1;
        }
        else if(point1[i]>point2[i]){
            return 2;
        }
    }

}

int Height(node *t)
{
    if(t==NULL)
        return -1;
    else
        return t->height;
}
 
void updateHeightSize(node *t)
{
    t->height = max(Height(t->left),
                        Height(t->right))+1;
    t->size = Size(t->left) + Size(t->right)+1;
}
 
node* insert(node *n, double key,double point[])
{
    if(n==NULL){
    	// cout<<"bitch";
        n = createNode(key,point);
    	// cout<<"bitch";

    	// cout<<n->key<<","<<n->point[0]<<endl;        
        return n;
    }
    if(n->left==NULL ||
           Size(n->left)< int(pow(2, Height(n->left)+1))-1 ||
           Size(n->right)==Size(n->left)) 
        n->left = insert(n->left, key,point);
    else
        n->right = insert(n->right,key,point);
 
    if((n->left!=NULL && n->left->key >= n->key) ||
            (n->right!=NULL && n->right->key >= n->key)){
        if(n->left==NULL){
            if(n->key==n->right->key){
                if(prior(n->point,n->right->point)==1){

                    swap(n->key, n->right->key);
                    swapCordi(n->point,n->right->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->right->key);
                    swapCordi(n->point,n->right->point);                    

            }

        }
        else if(n->right==NULL){
            if(n->key==n->left->key){
                if(prior(n->point,n->left->point)==1){
                    swap(n->key, n->left->key);
                    swapCordi(n->point,n->left->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->left->key);
                    swapCordi(n->point,n->left->point);                    
                
            }
            }
        else{
            if(n->left->key > n->right->key){
            if(n->key==n->left->key){
                if(prior(n->point,n->left->point)==1){
                    swap(n->key, n->left->key);
                    swapCordi(n->point,n->left->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->left->key);
                    swapCordi(n->point,n->left->point);                    
                
            }                }
            // if(n->left->key == n->right->key){
            // 		if(n->left)
            // }
            else{
            if(n->key==n->right->key){
                if(prior(n->point,n->right->point)==1){
                    swap(n->key, n->right->key);
                    swapCordi(n->point,n->right->point);                    
                }
                else{
                    //do nothing
                }
            }
            else{
                    swap(n->key, n->right->key);
                    swapCordi(n->point,n->right->point);                    

            }                }
        }
    }
 
    updateHeightSize(n);
    return n;
}
 
node* top(node *root){
    return root;
}
 
void heapify(node *n)
{
    if(!n)
        return;
    while((n->left!=NULL && n->left->key>n->key) ||
              (n->right!=NULL && n->right->key>n->key)){
        if(n->left==NULL){
            swap(n->key, n->right->key);
            swapCordi(n->point,n->right->point);
            n = n->right;
        }
        else if(n->right==NULL){
            swap(n->key, n->left->key);
            swapCordi(n->point,n->left->point);
            n = n->left;
        }
        else{
            if(n->left->key > n->right->key){
                swap(n->key, n->left->key);
            	swapCordi(n->point,n->left->point);
                n = n->left;
            }
            else{
                swap(n->key, n->right->key);
            	swapCordi(n->point,n->right->point);
                n = n->right;
            }
        }
    }
}
 
node* remove(node *n, node *root)
{
    if(n==NULL)
        return NULL;
    if(n->left==NULL && n->right==NULL){
        swap(root->key, n->key);
        swapCordi(root->point,n->point);
        delete n;
        return NULL;
    }
    else if(Size(n->left) > Size(n->right))
        n->left = remove(n->left, root);
    else
        n->right = remove(n->right, root);
 
    updateHeightSize(n);
}
 
void pop(node **heap)
{
    *heap = remove(*heap, *heap);
    heapify(*heap);
}
 
void display(node *x)
{
    // cout<<x->key;
    for (int i = 0; i < n; ++i)
    {
    	cout<<x->point[i]<<",";
    }
    cout<<endl;
}
 
void printArray(double point[]){
	for (int i = 0; i < n; ++i)
    {
    	cout<<point[i]<<",";
    }
    cout<<endl;
}

const vector<string> explode1(const string& s)
{
    string str(s);
    string buf; // Have a buffer string
    stringstream ss(str); // Insert the string into a stream

    vector<string> tokens; // Create vector to hold our words

    while (ss >> buf)
        tokens.push_back(buf);
    return tokens;
}
int main(int argc, char const *argv[])
{
    node *heap=NULL;
    // n=3;
    string line;
    std::clock_t start;
    int x;
    int k=100;
    int query_k=0;
    // double query[20] = {0.12502049619,0.00219191247221,0.158140001549,0.940883915857,0.392763605926,0.591349628717,0.0121416626448,0.889649558569,0.541974006709,0.96820015965,0.180777312793,0.328007163638,0.93470559616,0.334347106442,0.408667246085,0.969400423001,0.408434913785,0.606674982286,0.624876079674,0.760959178059};   
    // double query[20] = {0,0,0};
    int examples;
    
// cout<<tokens[1];
    ifstream myfile(argv[1]);

    if(myfile.is_open()){
        getline(myfile,line);
        std::vector<std::string> splits;
        splits={explode1(line)};
        // cout<<splits[1];
        n=atoi(splits[0].c_str());
        examples=atoi(splits[1].c_str());}
        // cout<<n << "\n";
        // cout<<examples<< "\n";
        static double set[100000][20];
        int j=0;
        if(myfile.is_open()){
        // cout<<line[0];
        while(getline(myfile, line)){
            std::vector<std::string> splits;
            splits={explode1(line)};
            for(int i=0;i<n;i++){
                set[j][i]=atof(splits[i].c_str());
            }
            j+=1;

        }
    }
    start=clock();
    string line1;
    ifstream query_file("query_file_2.txt");
    // getline(query_file,line1);
        if(query_file.is_open()){
        getline(query_file,line);
        std::vector<std::string> splits;
        splits={explode1(line)};
        // cout<<splits[1];
        n=atoi(splits[0].c_str());
        query_k=atoi(splits[1].c_str());}

        double query_f[query_k][n] ;
        // for (int i = 0; i < 100; i++) {
          // double query_f[i] = new double[20];
        // }

        j=0;
        if(query_file.is_open()){
        // cout<<line[0];
        while(getline(query_file, line1)){
            std::vector<std::string> splits;
            splits={explode1(line1)};
            for(int i=0;i<n;i++){
                query_f[j][i]=atof(splits[i].c_str());
            }
            j+=1;

        }
    }

   	// double set[11][20] = {{0,0,1},{0,1,0},{1,0,0},{1,21,3},{11,2,3},{1,21,31},{1,2,13},{1,2,13},{1,12,31},{1,21,3},{1,2,31}};
    // examples = 100000;
    for(j=0;j<query_k;j++){
    for (int i = 0; i <examples; ++i)
    {
    	// cout<<distance(set[i],query)<<"->";
    	// printArray(set[i]);
    	if(i<k) heap = insert(heap, distance(set[i],query_f[j]),set[i]);
    	else{
    		if(top(heap)->key > distance(set[i],query_f[j])){
    			pop(&heap);
    			heap = insert(heap, distance(set[i],query_f[j]),set[i]);
    		}
    		if(top(heap)->key == distance(set[i],query_f[j])){    			
    			for (int l = 0; l < n; ++l)
    			{
    				if(top(heap)->point[l] < set[i][l]){
    					
    					pop(&heap);
    					heap = insert(heap, distance(set[i],query_f[j]),set[i]);
    					break;
    				}

    			}
    			
    			
    		}
    	}

    }
       // cout<<"--Heap--"<<endl;
       int i=0;
    while(heap){
        if(i==0){
        display(top(heap));
    }
        pop(&heap);
        i+=1;
    }
    }

    cout<<"time is " << (clock()-start)/(double) CLOCKS_PER_SEC;

    cout<<endl;
    return 0;
}