#!/bin/bash
g++ -std=c++11 knn_best.cpp; ./a.out $1
