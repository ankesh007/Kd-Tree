#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <random>
//#include </Users/udayin/Desktop/stdc++.h>
#include <fstream>
#include <queue>
#include <math.h>
#include <ctime>
using namespace std;

class Node 
{
public:
  vector<double> point ;
  Node *left;
  Node *right;
  Node *parent;
  int dim;
  Node(vector<double> p, int dime)
  {
    for (int i = 0;i<p.size();i++)
    {
      point.push_back(p[i]);
    }
    left = NULL;
    right = NULL;
    parent=NULL;
    dim = dime;
  }
  
}; 

class kdtree
{
public:
  Node *Root;
  kdtree(vector< vector<double> > points)
  {
    Root = insert(points);
  }
  struct less_than_key
  {
    int d;
    less_than_key(int k){d = k;}
    inline bool operator() (const vector<double> &v1, const vector<double> &v2)
    {
        return (v1[d] < v2[d]);
    }
  };

  Node* inserthelper(vector< vector<double> > points, int depth)
  {
    //cout<<"helper "<<points.size()<<" d "<<depth<<"   size "<<points.size()<<endl;
    
    int d = depth%points[0].size();
    if (points.size()==0)
    {
      return NULL;
    }
    if (points.size()==1)
    {
      int d = depth%points[0].size();
      Node* n = new Node(points[0], d);
      //cout<<"points " <<n->point[0]<<endl;
      return n; 
    }

    else 
    {
      int d = depth%points[0].size();
      
      sort(points.begin(),points.end(),less_than_key(d));

      double median;
      if (points.size()%2==0)
      {
        median=(points[points.size()/2][d]+points[(points.size()/2)-1][d])/2;
      }
      else 
      {
         median=points[points.size()/2][d];
      }
      vector< vector<double> > leftpoints;
      vector< vector<double> > rightpoints;
      for (int i=0;i<points.size()/2;i++)
      {
        leftpoints.push_back(points[i]);
      }  
      for (int i=points.size()/2;i<points.size();i++)
      {
        rightpoints.push_back(points[i]);
      }  
      vector<double> new_point;
      for (int i = 0;i<points[0].size();i++)
      {
        if (i == d)
        {
          new_point.push_back(median);
        }
        else
        {
          new_point.push_back(0.);
        }
      }
      Node* n = new Node(new_point, d); 
      //cout <<" d "<<depth<< " node "<< n->point[0]<<endl;
      n->left = inserthelper(leftpoints,depth+1);
      n->right = inserthelper(rightpoints,depth+1);
      n->left->parent= n;
      n->right->parent=n;
      return n;
    }
  }

  Node* insert(vector< vector<double> > points)
  {
    //cout<<"insert "<<points.size()<<endl;
    return inserthelper(points,0);
  }

};


double euclideanDistance(vector<double> point1,vector<double> point2){
  double distance=0;
  for (int i=0;i<point1.size();i++){
    distance+=pow(point1[i]-point2[i],2);
  }
  return sqrt(distance);
}

struct Point
{
  vector<double> point;
  double distance;

  Point(vector<double> pointe, vector<double> query_point)
  {
    point = pointe;
    distance = euclideanDistance(point, query_point);
  }
};

class Comparedistance
{
  public:
  bool operator()(Point &t1, Point &t2)
  {
    if (t1.distance < t2.distance){
      return true;
    } else if (t1.distance==t2.distance){
      bool truth=true;
      for (int i=0;i<t1.point.size();i++){
        if (t1.point[i]>t2.point[i]){
          truth=false;
          break;
        } else if (t1.point[i]<t2.point[i]){
          break;
        }
       }
      return truth;
    } 
    return false;
  }
};

double fRand(double fMin, double fMax)
{
    double f = (double)rand() / RAND_MAX;
    return fMin + f * (fMax - fMin);
}




// priority_queue<Point, vector<Point>, Comparedistance> k_nearest_neighbors(Node* n, priority_queue<Point, vector<Point>, Comparedistance>& top_k){
//     while (n!=NULL){
//       left_child_visited = parent->left->visited;
//       right_child_visited = parent->right->visited;
      
//       if (left_child_visited==1 && right_child_visited==1){
//         // we go up since they are visited
//         n->visited = 1;
//         n = n->parent;
//       } else if (left_child_visited==1 && right_child_visited==0){
//         traverse_helper(right_child_visited, top_k);
//         // we traverse the right child
//       } else if (left_child_visited==0 && right_child_visited==1){
//         traverse_helper(left_child_visited, top_k);
//         // we travers the left child
//       }
//     }
//     return top_k;
//   }

// void traverse_helper(Node* n, priority_queue<Point, vector<Point>, Comparedistance>& top_k)
// {

// }

// void k_nearest_neighbors(Node* n, priority_queue<Point, vector<Point>, Comparedistance> &top_k, vector<double> point, int k)
// {
//   if(n->left == NULL && n->right == NULL)
//   {
//     //cout<<"add element"<<endl;
//     //cout<<n->point.size()<<" Is"<<endl;

//     Point temp(n->point, point);
//     if(top_k.size()<k){
//       top_k.push(temp);
//       //cout<<temp.point.size()<<endl;
//       //cout<<"pushed"<<endl;
//     }
//     else if(top_k.top().distance > temp.distance){
//       top_k.pop();
//       top_k.push(temp);
//     }
//     return;
//   }
//   int dim = n->dim;
//   int val1 = n->point[dim];
//   int val2 = point[dim];
//   int rect_dist;
//   if(top_k.size()==k){
//     //cout<<"full"<<endl;
//     if(val1<val2)
//       rect_dist = val2-val1;
//     else
//       rect_dist = val1-val2;
//     if(rect_dist>top_k.top().distance)
//       return;
//   }
//   //cout<<"recursive_call"<<endl;
//   if(val2<val1){
//     if(n->left!=NULL)
//       k_nearest_neighbors(n->left, top_k, point, k);
//     if(n->right!=NULL)
//       k_nearest_neighbors(n->right, top_k, point, k);
//   }
//   else{
//     if(n->right!=NULL)
//       k_nearest_neighbors(n->right, top_k, point, k);
//     if(n->left!=NULL)
//       k_nearest_neighbors(n->left, top_k, point, k);
//   }
  
// }


void k_nearest_neighbors(Node* n, priority_queue<Point, vector<Point>, Comparedistance> &top_k, vector<double> point, int k)
{
  int dim = n->dim;
  // cout<<"dimension is "<<dim<<endl;
  double val1 = n->point[dim];
  double val2 = point[dim];
  double rect_dist;
  // cout<<"started"<<endl;
  if(n->left == NULL && n->right == NULL)
  {
    // cout<<"add element"<<endl;
    // cout<<n->point.size()<<" Is"<<endl;

    Point temp(n->point, point);
    if(top_k.size()<k){
      top_k.push(temp);
      // cout<<temp.point.size()<<endl;
      // cout<<"pushed"<<endl;
    }
    else if(top_k.top().distance > temp.distance){
      top_k.pop();
      top_k.push(temp);
    }
    
  }

  else if(val2<val1){
    k_nearest_neighbors(n->left, top_k, point, k);
    rect_dist = val1-val2;
    if(top_k.size()<k || rect_dist<=top_k.top().distance){
      k_nearest_neighbors(n->right, top_k, point, k);
    }

  }
  else{
    k_nearest_neighbors(n->right, top_k, point, k);
    rect_dist = val2-val1;
    if(top_k.size()<k || rect_dist<=top_k.top().distance){
      k_nearest_neighbors(n->left, top_k, point, k);
    }

  }
 

return;
  
}


void sequential_scan(Node* n,vector<double> query_point,priority_queue<Point, vector<Point>, Comparedistance> &top_k, int queue_size)
{ 
  Node* left_child = n->left;
  Node* right_child = n->right;

  if (!(left_child!=NULL || right_child!=NULL)){
    // It is a leaf,push it to priority queue
    Point *p = new Point(n->point,query_point);
    if (top_k.size()<queue_size){
      top_k.push(*p);
    } else if (top_k.top().distance>p->distance){
      top_k.pop();
      top_k.push(*p);
    } 
  }
  if (left_child!=NULL){
    sequential_scan(left_child,query_point,top_k,queue_size);
  }
  if (right_child!=NULL){
    sequential_scan(right_child,query_point,top_k,queue_size);
  }
}

void readinput(char* a, vector<vector<double> > &input,int &dimension, int &n)
{
  char* dataset_file = a;
  ifstream myfile (dataset_file);
  myfile>>dimension;
  myfile>>n;

  for (int i = 0;i<n;i++)
  {
    vector <double> point;
    for (int j = 0;j<dimension;j++)
    {
      double d;
      myfile>>d;
      point.push_back(d);
    }
    input.push_back(point);
  } 
}

void writeresult(vector<vector <double> > result)
{
  ofstream myfile;
  myfile.open ("results.txt");
  for (int i = 0;i<result.size();i++)
  {
    for (int j= 0;j<result[0].size()-1;j++)
    {
      myfile<<result[i][j]<<" ";
    }
    myfile<<result[i][result[0].size()-1]<<"\n";
  }
  myfile.close();
}



int main(int argc, char* argv[]){
  int dimension,n;
  vector<vector<double> > input;
  char* dataset_file = argv[1];
  readinput(dataset_file,input,dimension,n);
 
  kdtree* kdt = new kdtree(input);
  cout << 0 << endl;
  char* query_file = new char[100];
  int k;
  cin >> query_file >> k;
  clock_t begin = clock();
  int m=k;
  //int qdimension,qn;
  vector<vector<double> > query_vector;
  //string str = "query_dim20.txt";
  //dimension=20;
  //qn=20;
  //int m = 20;
  //char *cstr = new char[str.length() + 1];
  //strcpy(cstr, str.c_str());
  //cout<<"qnhere"<<qn<<endl;
  readinput(query_file,query_vector,dimension,k);
  //readinput(str,query_vector,qdimension,qn);
  vector<vector<double> > output;
  
  double dist_second = 0;
  double dist_last = 0;
  for (int i=0;i<query_vector.size();i++){
      //cout<<"query"<<i<<endl;
      
      priority_queue<Point, vector<Point>, Comparedistance> top_k;
      vector<double> query=query_vector[i];
      vector<vector<double> >  helper ;
      k_nearest_neighbors(kdt->Root,top_k,query,m);
      int iter = 0;
      while (top_k.size()!=0){
        iter++;

        vector<double> outer;
        for (int i=0;i<dimension;i++){
         outer.push_back(top_k.top().point[i]);
        }
        if(iter==1){
          double di = euclideanDistance(outer, query);
          dist_second+=di;
          //cerr<<"2nd "<<dist_second<<endl;
        }
        if(iter==m-1){
          double di = euclideanDistance(outer, query);
          dist_last+=di;
          //cerr<<"last "<<dist_last<<endl;
        }
        helper.insert(helper.begin(),outer);
        top_k.pop();
      } 
      output.insert(output.end(), helper.begin(), helper.end());


  }
  writeresult(output);
  cerr<<double(dist_second/m)<<endl;
  cerr<<double(dist_last/m)<<endl;
  cout<<1<<endl;
  clock_t end = clock();
  double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
  cerr<<"query time: "<<elapsed_secs<<endl;
  return 0;
}