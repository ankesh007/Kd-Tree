!/bin/bash
g++ -O3 -std=c++11 -o res best_first_search.cpp;
./res $1