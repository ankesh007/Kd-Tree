#include <vector>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <queue>
#include <sstream>
#include <fstream>
#include <stack>
#include <limits>
#include <ctime>
using namespace std;
class Rectangle
{
public:
	vector<double> min;
	vector<double> max;
	Rectangle(){
		// min.resize(0);
		// max.resize(0);
	}
	Rectangle(vector<vector < double> >:: iterator &beginning, vector<vector < double> >:: iterator &ending){
		min.resize(beginning->size());
		max.resize(beginning->size());
		// cerr<<min.size()<<endl;
		int i=0;
		for(vector<double>::iterator it=beginning->begin(); it !=beginning->end(); it++){
			min[i] = *it;
			max[i] = *it;
			i++;
		}
		for(vector<vector<double> > ::iterator x=beginning; x!= ending; x++){
			i=0;
			for(vector<double>:: iterator it= x->begin(); it!= x->end();it++){
				if (*it < min[i]){
					min[i]= *it;
				}
				if(*it > max[i]){
					max[i]=*it;
				}
				i++;
			}
		}
	}
};
inline double distanceBetweenPoints(const vector<double>& first,const vector<double> & second){
	double distance=0.0;
	for(unsigned i=0;i < first.size(); i++){
		distance+=pow(first[i]-second[i],2);
	}
	return distance;
}
class cmp {
    int param;
public:
    cmp(int p){
    	param=p;
    }
    bool operator()(const vector<double > &first , const vector<double > & second) {
        // logic uses param
        return first[param] < second[param];
    }
};
class Node{
public:
	vector<double> points;
	Node * left=NULL;
	Node * right=NULL;
	int height;
	Rectangle *r;
	Node(){
		points.resize(0);
		this->height=-1;
	}
	Node(vector< vector<double> >:: iterator beginning, vector< vector < double> > :: iterator ending,int sizeOfVector,int height){
		points.resize(beginning->size());
		// cout<< beginning->size()<<" Points size, "<<height<<"height\n";
		r=new Rectangle(beginning,ending);
		sort(beginning,ending,cmp(height%beginning->size()));
		points = *(beginning + sizeOfVector/2);
		for(int i=0;i < points.size();i++){
			// cout<<points[i]<<' ';
		}
		// cout<<endl;
		//conditions here
		this->height =  height;
		vector< vector<double> >:: iterator startingForleft,startingForRight, endingForRight, endingForLeft;
		startingForleft = beginning;
		startingForRight = beginning + sizeOfVector/2 + 1;
		endingForLeft = beginning+ sizeOfVector/2 ;
		endingForRight = ending;
		// Node temp;
		if (startingForleft != endingForLeft){
			left = new Node(startingForleft,endingForLeft,sizeOfVector/2,height+1);
			// left = &temp;
		}
		else{
			left= NULL;
		}
		//conditions here
		startingForRight=beginning+sizeOfVector/2+1;
		endingForLeft=ending;
		if (startingForRight != endingForRight){
			right =new Node (startingForRight,endingForRight,sizeOfVector-1- sizeOfVector/2,height+1 );
			// right= &temp;
		}
		else{
			right = NULL;
		}
	}
	double minDistance(const vector<double> & point){
		double distance=0.0;
		if (point.size() != this->points.size()){
			// cerr<<"Min distance lanjaa\n";
		}
		if (point.size() != this->r->max.size()){
			// cerr<<"Min oHFEHEWFHWH distance lanjaa\n";			
		}
		for (unsigned i=0;i<point.size();i++){
			if (this->r->min[i] <= point[i] && this->r->max[i] >= point[i]){

			}
			else{
				if (this->r->min[i] > point[i]){
					distance += pow(this->r->min[i] - point[i] ,2);
				}
				else{
					distance += pow(point[i] - this->r->max[i],2);
				}
			}
		}
		return distance;
	}
	// right true left false 
	bool decisionTree(const vector<double> &queryPoint){
		return points[height] < queryPoint[height];
	}
};
class Point{
public:
	Node * x;
	double distance;
	Point(Node* x_,const vector<double> & queryPoint){
		this->x = x_;
		distance = distanceBetweenPoints(x->points,queryPoint);
	}
	Point(Node *x,double distance){
		this->x=x;
		this->distance = distance;
	}
};
class comparator{
	public:
	bool operator()(const Point &p1,const Point &p2){
		if (p1.distance != p2.distance){
			return p1.distance < p2.distance;
		}
		else{
			int i=0;
			int size=p1.x->points.size();
			for(i=0;i<size;i++){
				if(p1.x->points[i] != p1.x->points[i]){
					return p1.x->points[i] < p1.x->points[i];
				}
				else{
					continue;
				}
			}
			return true;
		}
	}
};
class kPriorityQueue{
public:
	int size;
	priority_queue<Point, vector<Point>, comparator> qElement;
	kPriorityQueue(int k){
		this->size = k;
		// cerr<<"Constructor called";
	}
	double topDistance(){
		// Point p=qElement.top();
		// cerr<<"Compeleted";
		if (qElement.empty()){
			// cerr<<"Wowww\n";
			return numeric_limits<double>::max();
		}
		return qElement.top().distance;
	}
	void insert(Node *x, const vector<double>& queryPoint){
		if (qElement.size() < size){
			qElement.push(Point(x,queryPoint));
		}
		if (qElement.size() > size){
			// cerr<<"Emi jaruguthundey lanja";
		}
		else {
			double temp= distanceBetweenPoints(x->points,queryPoint);
			if( temp < this->topDistance()){
				qElement.pop();
				qElement.push(Point(x,temp));
			}
		}
	}
	bool empty(){
		return qElement.empty();
	}
	Point top(){
		return qElement.top();
	}
	void pop(){
		qElement.pop();
	}
};
//recursive Definition
void kNearestNeighbors(Node * x, kPriorityQueue &kpq,const vector<double>& queryPoint){
	if (x ==  NULL){
		return;
	}
	// cerr<<"Osheeyyy";
	if ( kpq.topDistance() < x->minDistance(queryPoint) ){
		// cerr<<"Rakudadhey lanja\n"
		return;
	}
	kpq.insert(x,queryPoint);
	if(x->decisionTree(queryPoint) ){
		kNearestNeighbors(x->right,kpq,queryPoint);
		kNearestNeighbors(x->left,kpq,queryPoint);
	}
	else{
		kNearestNeighbors(x->left,kpq,queryPoint);	
		kNearestNeighbors(x->right,kpq,queryPoint);
	}
}
void traverseGraph(Node *x){
	if (x == NULL){
		return;
	}
	for(int i=0;i<x->points.size();i++){
		// cout<<x->points[i]<<' ';
	}
	// cout<<endl;
	traverseGraph(x->left);
	traverseGraph(x->right);
}
void publicDef(Node *x,const vector<double>& queryPoint,int k){
	kPriorityQueue kpq(k);
	// cout<<"Compeleted";
	kNearestNeighbors(x,kpq,queryPoint);
	if(kpq.qElement.size() != k){
		// cerr<<"Lanjaa emi peekuthunnav\n";
	}
	int dimensions=queryPoint.size();
	ofstream out("results.txt",std::ios_base::app);
	// cerr<<kpq.qElement.size()<<endl;
	stack<Point> result;
	while(! kpq.empty()){
		result.push(kpq.top());
		kpq.pop();
	}
	Node *toWrite;
	while(! result.empty()){
		toWrite= result.top().x;
		result.pop();
		for(int i=0;i<dimensions-1;i++){
			out<<toWrite->points[i]<<' ';
		}
		out<<toWrite->points[dimensions-1]<<'\n';
	}
	out.close();
}
inline double distance(vector<double>::iterator p, const vector<double>& queryPoint){
	double distanceTotal=0.0;
	for(int i=0;i< queryPoint.size();i++){
		distanceTotal+=pow( *p - queryPoint[i],2);
		p++;
	}
	return distanceTotal;
}
class comparatorforSeq{
public:
	vector<double> queryPoint;
	int size;
	comparatorforSeq(vector<double> q){
		queryPoint = q;
		size= q.size();
		// cerr<<"Initialised perfectly\n";
	}
	bool operator() (vector<double>::iterator first,vector<double>::iterator second){
		return distance(first,queryPoint) < distance(second,queryPoint);
	}
};
void sequentialScan(vector<vector<double> > &points, vector<double> &queryPoint,int k){
	priority_queue<vector<double>::iterator ,vector<vector<double>::iterator >, comparatorforSeq > kpq(queryPoint);
	int rowSize= points.size();
	vector<vector< double> >::iterator beginningIterator= points.begin();
	for(int i=0;i<rowSize;i++){
		if (kpq.size() < k ){
			kpq.push(beginningIterator->begin());
		}
		else{
			if (distance(beginningIterator->begin(),queryPoint) < distance(kpq.top(),queryPoint)){
				kpq.pop();
				kpq.push(beginningIterator->begin());
			}
		}
		beginningIterator++;
	}
}
int main(int argc, char const *argv[]){
	ifstream ip(argv[1]);
	if(!ip.is_open()) std::cout << "ERROR: File Open" << '\n';
	string num,xtemp,ytemp;
	int dim,numpoints;
	int line=0;
	getline(ip,num,'\n');
	stringstream s;
	s << num;
	s>>dim;
	s>>numpoints;
	// cout<<numpoints<<endl;
	// cout<<dim<<endl;
	vector<vector<double> > pts( numpoints, vector<double>(dim));
	while(ip.good()){
		getline(ip,num,'\n');
		stringstream s(num);
		for(int i=0;i<dim;i++){
			s>>pts[line][i];
		}
		line++;
	}
	ip.close();
	Node root=Node(pts.begin(),pts.end(),pts.size(),0);
	//Output 0 when done on cout
	// Take input from cin of querypoints file name
	//Sequential Code Calling
	//Call Recursive code like this
	// Test for 1a, 1b
	// cerr<<"Input QueryFileName\n";
	cout<<0<<endl;
	string queryFileName;
	
	cin>> queryFileName;
	int k;
	cin>>k;
	//Read vector<double> points From file
	//Just a Loop
	ip.open(queryFileName);
	int dimensions,noOfPoints;
	ip>> dimensions>>noOfPoints;
	// cerr<<"dimensions "<<dimensions<<endl;
	// cerr<<"noOfPoints "<<noOfPoints<<endl;
	// kPriorityQueue kpq(dimensions);
	vector<double> querypoints(dimensions);
	for(int i=0;i<noOfPoints;i++){
		for(int j=0;j<dimensions;j++){
			ip>>querypoints[j];
			// cerr<<querypoints[j]<<' ';
		}
		// cerr<<"reading Compeleted\n";
		publicDef(&root,querypoints,k);
		//cerr<<"One call Compeleted";
		//kpq=kPriorityQueue(dimensions);
	}
	cout<<1<<endl;
	return 0;
}