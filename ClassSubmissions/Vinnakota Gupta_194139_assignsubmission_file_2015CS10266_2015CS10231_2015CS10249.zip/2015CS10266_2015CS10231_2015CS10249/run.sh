g++ KDTree.cpp -std=c++11 -o KDTree
./KDTree $1