import sys

class Node:
	def __init__(self, point=None):
		self._left = None
		self._right = None
		self._point = point
		self._maxb = point
		self._minb = point


class kdTree:
	def __init__(self):
		self.root = None

	def insert(self,point):
		if self.root is None:
			self.root = Node(point)
		else:
			self._insert(point,self.root,0)

	def _insert(self,point,node,depth):
		if node._point[depth] < point[depth] :
			if node._left is None:
				node._left = Node(point)
			else:
				self._insert(point,node._left, (depth+1)%len(point))
		else:
			if node._right is None:
				node._right = Node(point)
			else:
				self._insert(point,node._right, (depth+1)%len(point))

def inorder(node):
	if node is None:
		print("*")
		return
	print(node._point)
	inorder(node._left)
	inorder(node._right)

tree = kdTree()
arr = [[0,0],[1,0],[0,1],[1,1]]
for i in arr:
	tree.insert(i)
inorder(tree.root)
