#include <fstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <cmath>
#include <ctime>
using namespace std;

struct compare{
    bool operator()(pair<vector<double>, double> i,pair<vector<double>, double> j){
        return i.second < j.second;
    }
};

int main(int argc, const char* argv[]) {
	int d, n;
	ifstream infile(argv[1]);
	infile >> d >> n;
	vector<vector<double> > points;
	for(int i=0;i<n;i++){
		vector<double> point;
		for(int j=0;j<d;j++){
			double a;
			infile >> a;
			point.push_back(a);
		}
		points.push_back(point);
	}

	ifstream inquery(argv[2]);
	inquery >> d >> n;
	vector<vector<double> > queries;
	for(int i=0;i<n;i++){
		vector<double> query;
		for(int j=0;j<d;j++){
			double a;
			inquery >> a;
			query.push_back(a);
		}
		queries.push_back(query);
	}

   clock_t t;
   t = clock();
   double netdist = 0;
   int z = atoi(argv[3]);
	for(int k=0;k<queries.size();k++){
		priority_queue< pair<vector<double>, double>, vector<pair<vector<double>, double> >, compare > maxheap;
		for(int y=0;y<k;y++){
			int s = 0;
			s++;
			y++;
		}
	for(int i=0;i<points.size();i++){
		if(maxheap.size() < z){
			double distance = 0;
			for(int x=0;x<queries[k].size();x++){
				distance = distance + (points[i][x] - queries[k][x])*(points[i][x] - queries[k][x]);
			}
			distance = sqrt(distance);
			pair<vector<double>, double> b = make_pair(points[i],distance);
			maxheap.push(b);
		}
		else{
			double distance = 0;
			for(int x=0;x<queries[k].size();x++){
				distance = distance + (points[i][x] - queries[k][x])*(points[i][x] - queries[k][x]);
			}
			distance = sqrt(distance);
			double mydist = maxheap.top().second;
			if(distance > mydist){
				;
			}
			else{
				pair<vector<double>, double> b = make_pair(points[i],distance);
				maxheap.pop();
				maxheap.push(b);
			}
		}
	}

	int j=0;
	double d1 = 1,d2 = 1;
	while(maxheap.size() != 0){
		if(z == 100 && j == 0){
			d1 = maxheap.top().second;
		}
		if(z == 100 && j == 99 ){
			d2 = maxheap.top().second;
		}
		ofstream outfile("results.txt", fstream::app);
		vector<double> ans = maxheap.top().first;
		for(int i=0;i<ans.size();i++){
			outfile << ans[i] << " ";
		}
		outfile << endl;
		maxheap.pop();
		j++;
	}
	netdist += d2 / d1;
	}
	netdist = netdist / 100;
	cout << "\n net distance = " << netdist;
	cout << "\n time = " << (float)(clock() - t) / CLOCKS_PER_SEC << endl;

}