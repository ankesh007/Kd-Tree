import sys
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neighbors import NearestNeighbors
from sklearn.neighbors import KDTree
import numpy as np
import time

def knn(filename, queryfile, k):
	points = []
	with open(filename,'r') as file:
		d,n = (file.readline()).strip().split()
		for i in range(int(n)):
			points.append(list(map(float,file.readline().strip().split())))

	queries = []
	with open(queryfile,'r') as file:
		d,n = (file.readline()).strip().split()
		for i in range(int(n)):
			queries.append(list(map(float,file.readline().strip().split())))
		# print(points)
	# nbrs = NearestNeighbors(n_neighbors=k, algorithm='kd_tree').fit(points)
	# print(nbrs)
	kdt = KDTree(points, metric='euclidean', leaf_size=100)
	print(kdt.get_tree_stats)
	start_time = time.clock()
	x = kdt.query(queries, k=k, return_distance=False)
	print("--- %s seconds ---" % (time.clock() - start_time))
	# for i in x:
	# 	for j in i:
	# 		print(points[j])

knn(sys.argv[1], sys.argv[2], int(sys.argv[3]))