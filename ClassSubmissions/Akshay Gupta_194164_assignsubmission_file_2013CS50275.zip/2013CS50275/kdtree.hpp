typedef vector<double> Point;
typedef vector<Point> PointList;

struct Node {

	bool leaf;
	Node *left;
	Node *right;
	double max_d;
	double min_d;
	int div;
	Point p;

	Node(Point& _p, int _div, Node* _left, Node* _right, bool _leaf, double _min_d, double _max_d) {
		leaf = _leaf;
		left = _left;
		right = _right;
		div = _div;
		p = _p;
		min_d = _min_d;
		max_d = _max_d;
	}

	double point_dist(Point& q) {
		double dist = 0;
		for(int i = 0; i < p.size(); i++)
			dist += ((p[i] - q[i]) * (p[i] - q[i]));
		return dist;
	}

};

struct HeapNode {
	Point *p;
	double key;

	HeapNode(Point *_p, double _key) {
		p = _p;
		key = _key;
	}
};

class Heap {
	vector<HeapNode*> heap;
	int N;

	int parent(int k) {
		return (k - 1)/2;
	}
	void swap(int i, int j) {
	    HeapNode *t = heap[i];
	    heap[i] = heap[j];
	    heap[j] = t;
	}

	void bubble_up(int k) {
		while(k > 0 && heap[parent(k)]->key < heap[k]->key) {
		    swap(k, parent(k));
		    k = parent(k);
		}
	}

	void bubble_down(int k)  {
	    int j;
	    while((2 * k + 1) < N) {
	        j = 2 * k + 1;
	        if(j + 1 < N && heap[j]->key < heap[j+1]->key)
	            j++;
	        if(heap[k]->key >= heap[j]->key)
	            break;
	        swap(k, j);
	        k = j;
	    }
	}

public:

	Heap(){
		N = 0;
	}

	bool empty() {
		return (N == 0);
	}

	int size() {
		return N;
	}

	Point* pop_max() {
	    Point* max = heap[0]->p;
	    swap(0, --N);
	    bubble_down(0);
	    heap.pop_back();
	    return max;
	}

	void insert(Point *p, double key) {
		HeapNode *h = new HeapNode(p, key);
		heap.push_back(h);
		N++;
		bubble_up(N-1);
	}

	double min_key() {
		return heap[0]->key;
	}

	vector<HeapNode*>* get_heap() {
		return &heap;
	}
};

class KDTree {
	int n;
	int d;
	Node *root;
	Point min_end;
	Point max_end;

	double box_dist(Point& q) {
		double dist = 0.;
		for(int div = 0; div < d; div++) {
			if (q[div] < min_end[div])
				dist += (min_end[div] - q[div])*(min_end[div] - q[div]);
			else if (q[div] > max_end[div])
				dist += (q[div] - max_end[div])*(q[div] - max_end[div]);
		}
		return dist;
	}

	Node* _buildTree(PointList::iterator start, PointList::iterator end, int sind, int eind, PointList& plist, int div) {
		sort(start, end, 
			[div](const Point& a, const Point& b) {
				return a[div] < b[div];
			});
		int _n = eind - sind;
		int cur = sind + _n/2;
		bool leaf = false;
		Node* left = nullptr;
		Node* right = nullptr;
		if (_n == 1)
			leaf = true;
		else if (_n == 2) {
			left = _buildTree(start, start + _n/2, sind, cur, plist, (div+1)%d);
		}
		else {
			left = _buildTree(start, start + _n/2, sind, cur, plist, (div+1)%d);
			right = _buildTree(start + _n/2 + 1, end, cur + 1, eind, plist, (div+1)%d);
		}
		Node *node = new Node(plist[cur], div, left, right, leaf, plist[sind][div], plist[eind-1][div]);
		return node;
	}

	void _knnSearch(Point& q, int k, Node* node, Heap& heap) {
		if (node == nullptr)
			return;
		double min_dist;
		if(heap.empty())
			min_dist = numeric_limits<double>::max();
		else
			min_dist = heap.min_key();
		int div = node->div;
		double new_dist = node->point_dist(q);
		double bdist = box_dist(q);
		if(bdist > min_dist && heap.size() >= k) {
			return;
		}
		if (new_dist < min_dist && heap.size() >= k)
			heap.pop_max();
		if (new_dist <= min_dist || heap.size() < k)
			heap.insert(&node->p, new_dist);
		if (q[div] < node->p[div]) {
			double temp = max_end[div];
			max_end[div] = node->p[div];
			_knnSearch(q, k, node->left, heap);
			max_end[div] = temp;
			temp = min_end[div];
			min_end[div] = node->p[div];
			_knnSearch(q, k, node->right, heap);
			min_end[div] = temp;
		}
		else {
			double temp = min_end[div];
			min_end[div] = node->p[div];
			_knnSearch(q, k, node->right, heap);
			min_end[div] = temp;
			temp = max_end[div];
			max_end[div] = node->p[div];
			_knnSearch(q, k, node->left, heap);
			max_end[div] = temp;
		}
	}

	void _knnSeqSearch(Point& q, int k, Node* node, Heap& heap, double min_dist) {
		if (node == nullptr)
			return;
		double new_dist = node->point_dist(q);
		if (new_dist < min_dist && heap.size() >= k)
			heap.pop_max();
		if (new_dist <= min_dist || heap.size() < k)
			heap.insert(&node->p, new_dist);
		min_dist = heap.min_key();
		_knnSeqSearch(q, k, node->left, heap, min_dist);
		min_dist = heap.min_key();
		_knnSeqSearch(q, k, node->right, heap, min_dist);
	}

public:

	KDTree(int _n, int _d) {
		n = _n;
		d = _d;
	}

	void buildTree(PointList& plist) {
		for(int div = 0; div < d; div++) {
			PointList::iterator ip = min_element(plist.begin(), plist.end(), 
			[div](const Point& a, const Point& b) {
				return a[div] < b[div];
			});
			min_end.push_back((*ip)[div]);
			ip = max_element(plist.begin(), plist.end(), 
			[div](const Point& a, const Point& b) {
				return a[div] < b[div];
			});
			max_end.push_back((*ip)[div]);
		}
		root = _buildTree(plist.begin(), plist.end(), 0, n, plist, 0);
	}

	void knnSearch(Point& q, int k, Heap& heap) {
		_knnSearch(q, k, root, heap);
	}

	void knnSeqSearch(Point& q, int k, Heap& heap) {
		_knnSeqSearch(q, k, root, heap, numeric_limits<double>::max());
	}

};