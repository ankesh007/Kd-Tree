#include <iostream>
#include <fstream>
#include <queue>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <limits>
#include <unordered_set>

using namespace std;

#include "kdtree.hpp"

int main(int argc, char* argv[]) {
	char* dataset_file = argv[1];
	string query_file;
	ifstream f(dataset_file);
	int n, d;
	f >> d >> n;
	PointList plist;
	for (int i = 0; i < n; i++) {
		Point p(d);
		for (int j = 0; j < d; j++)
			f >> p[j];
		plist.push_back(p);
	}
	KDTree KT(n, d);
	KT.buildTree(plist);
	cout << 0 << endl;
	int k, n2;
	cin >> query_file >> k;
	f.close();
	ifstream qf(query_file.c_str());
	qf >> d >> n2;
	Point q(d);
	ofstream of("results.txt");
	for (int i = 0; i < n2; i++) {
		for (int j = 0; j < d; j++)
			qf >> q[j];
		Heap heap;
		KT.knnSearch(q, k, heap);
		vector<HeapNode*>* h = heap.get_heap();
		sort((*h).begin(), (*h).end(), [](HeapNode* a, HeapNode* b) {
			if (a->key < b->key)
				return true;
			else if (a->key == b->key)
				return *(a->p) < *(b->p);
			else
				return false;
		});
		for(int j = 0; j < k; j++) {
			copy((*h)[j]->p->begin(), (*h)[j]->p->end(), ostream_iterator<double>(of, " "));
			of << "\n";
		}
	}
	cout << 1 << endl;
	qf.close();
	of.close();
}