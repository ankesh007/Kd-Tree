#include <iostream>
#include <fstream>
#include <queue>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <sstream>
#include <stack>
#include <algorithm>
#include <vector>
#include <limits>
#include <random>
#include <ctime>
#include <unordered_set>

using namespace std;

#include "kdtree.hpp"

void knnSeqSearch(PointList& plist, Point& q, int k, Heap& heap) {
	double min_dist = numeric_limits<double>::max();
	for(int i = 0; i < plist.size(); i++) {
		double new_dist = 0;
		for(int j = 0; j < plist[i].size(); j++)
			new_dist += ((plist[i][j] - q[j]) * (plist[i][j] - q[j]));
		if (new_dist < min_dist && heap.size() == k)
			heap.pop_max();
		if (new_dist <= min_dist || heap.size() < k)
			heap.insert(&plist[i], new_dist);
		min_dist = heap.min_key();
	}
}

int main() {
	vector<int> dims = {2, 3, 5, 10, 20};
	uniform_real_distribution<double> distribution(0.0,1.0);
	default_random_engine generator;
	double start, time;
	int n = 100000, n2 = 100;
	for(int k = 0; k < 5; k++) {
		int d = dims[k];
		PointList plist;
		for(int i = 0; i < n; i++) {
			Point p(d);
			for (int j = 0; j < d; j++) {
				p[j] = distribution(generator);
			}
			plist.push_back(p);
		}
		start = clock();
		KDTree KT(n, d);
		KT.buildTree(plist);
		time = (clock() - start)/CLOCKS_PER_SEC;
		cout << "Dim: " << d << ", Time to build KD Tree: " << time << "s\n";
		PointList qlist;
		for(int i = 0; i < n2; i++) {
			Point q(d);
			for (int j = 0; j < d; j++) {
				q[j] = distribution(generator);
			}
			qlist.push_back(q);
		}
		start = clock();
		for(int i = 0; i < n2; i++) {
			Heap heap;
			KT.knnSearch(qlist[i], 20, heap);
			vector<HeapNode*>* h = heap.get_heap();
			sort((*h).begin(), (*h).end(), [](HeapNode* a, HeapNode* b) {
				if (a->key < b->key)
					return true;
				else if (a->key == b->key)
					return *(a->p) < *(b->p);
				else
					return false;
			});
		}
		time = (clock() - start)/CLOCKS_PER_SEC;
		cout << "Dim: " << d << ", Type: Best First, Average Time: " << time/n2 << "s\n";
		start = clock();
		for(int i = 0; i < n2; i++) {
			Heap heap;
			KT.knnSeqSearch(qlist[i], 20, heap);
			// knnSeqSearch(plist, qlist[i], 20, heap);
			vector<HeapNode*>* h = heap.get_heap();
			sort((*h).begin(), (*h).end(), [](HeapNode* a, HeapNode* b) {
				if (a->key < b->key)
					return true;
				else if (a->key == b->key)
					return *(a->p) < *(b->p);
				else
					return false;
			});
		}
		time = (clock() - start)/CLOCKS_PER_SEC;
		cout << "Dim: " << d << ", Type: Sequential, Average Time: " << time/n2 << "s\n";
		double avg_min = 0., avg_max = 0., avg_ratio = 0.;
		for(int i = 0; i < n2; i++) {
			Heap heap;
			KT.knnSearch(qlist[i], 100, heap);
			vector<HeapNode*>* h = heap.get_heap();
			sort((*h).begin(), (*h).end(), [](HeapNode* a, HeapNode* b) {
				if (a->key < b->key)
					return true;
				else if (a->key == b->key)
					return *(a->p) < *(b->p);
				else
					return false;
			});
			avg_min += sqrt((*h)[1]->key);
			avg_max += sqrt((*h)[99]->key);
		}
		avg_ratio = avg_min / avg_max;
		cout << "Dim: " << d << ", Avg Ratio: " << avg_ratio << "\n";
	}
}