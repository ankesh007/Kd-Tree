import sys
import heapq as h
import numpy as np

k = 2
k_NN = 20

#Class for the KD Tree Node.
class Node:
    def __init__(self, depth, split_value, leaf, left, right, point,MBR):
        self.depth = depth
        self.split_value = split_value
        self.isLeaf = leaf
        self.lChild = left
        self.rChild = right
        self.point = point
        self.MBR = MBR

#Class for rectangle stored in each Node
class MBR:
    def __init__(self,dim_min,dim_max):
        self.dim_min = dim_min
        self.dim_max = dim_max

#L2 distance between points
def distance(point1 , point2):
    dist = 0.0 
    for i in range(len(point1)):
        dist += (point1[i] - point2[i])*(point1[i] - point2[i])
    
    return dist

#Minimum distance from query point to MBR
def distanceMBR(Q , MBR):
    dist = 0.0

    for i in range(len(Q)):
        delta_i = 0
        if Q[i] < MBR.dim_min[i] :
            delta_i = Q[i] - MBR.dim_min[i]
        if Q[i] > MBR.dim_max[i] :
            delta_i = Q[i] - MBR.dim_max[i]
        dist += delta_i*delta_i

    return dist

#Operator for sorting the KDTree Node elements
def compare(item1, item2):
    if (item1 - item2) > 0 :
        return 1
    
    if (item1 - item2) < 0 :
        return -1

    return 0


def new_compare(d1,p1,d2,p2):
    if d1 > d2 :
        return 1
    else :
        if d1 < d2 :
            return -1
        else:
            for i in range(len(p1)) :
                if p1[i] < p2[i] :
                    return -1
                if p1[i] > p2[i] :
                    return 1
            return 0

#Generates the KDTree
def genKDTree(points, dim_min, dim_max, tree_depth = 0):
    if points == []:
        return None
    if len(points) == 1 :
        new_MBR = MBR(points[0],points[0])
        node = Node(tree_depth, 0, True, None, None, points[0],new_MBR)
        return node
    
    split_dim = tree_depth % k
    points.sort(cmp=lambda x, y: compare(x[split_dim], y[split_dim]))
    median_value = points[len(points)/2][split_dim]
    i = 0
    #print(median_value)
    while points[i][split_dim] < median_value :
        i += 1
    
    if i == 0 :
        while points[i][split_dim] <= median_value :
            i += 1

    temp = dim_max[split_dim]
    dim_max[split_dim] = median_value
    left = genKDTree(points[0:i], dim_min,dim_max,tree_depth + 1)
    
    dim_max[split_dim] = temp
    temp = dim_min[split_dim]
    dim_min[split_dim] = median_value
    right = genKDTree(points[i:],dim_min,dim_max, tree_depth + 1)
    
    dim_min[split_dim] = temp
    new_MBR = MBR(dim_min,dim_max)
    node = Node(tree_depth, median_value,False, left,right,None,new_MBR)
    

    return node



#Does k Nearest Neighbour Search using best-first search algorithm
def kNNSearch(Q,root,k_NN):
    answerSet = []
    candidate = []
    if root == None:
        return answerSet

    P = [10]*len(Q)
    h.heapify(answerSet)
    h.heapify(candidate)
    for i in range(k_NN):
        h.heappush(answerSet,(-distance(Q,P),P))
    h.heappush(candidate,(distanceMBR(Q,root.MBR),root))
    
    while bool(len(candidate) == 0) is False :
        #print(len(candidate))
        (dist_MBR ,node_tree) = h.heappop(candidate)
        (dist_point, max_point) = h.heappop(answerSet)

        if dist_MBR > -dist_point :
            h.heappush(answerSet,(dist_point,max_point))
            return answerSet
        else :
            if node_tree.isLeaf :
                dist_new = distance(node_tree.point,Q)
                if dist_new < -dist_point :
                    h.heappush(answerSet,(-dist_new,node_tree.point))
                else :
                    h.heappush(answerSet,(dist_point,max_point))
            else :
                lChild = node_tree.lChild
                rChild = node_tree.rChild

                if ~(lChild is None):
                    h.heappush(candidate,(distanceMBR(Q,lChild.MBR),lChild))
                if ~(rChild is None):
                    h.heappush(candidate,(distanceMBR(Q,rChild.MBR),rChild))
                h.heappush(answerSet,(dist_point,max_point))
    
    return answerSet


def sequentialScan(root,k_NN,Q):
    answerSet = []
    h.heapify(answerSet)

    for i in range(len(points)):
        if i < k_NN :
            h.heappush(answerSet,(-distance(Q,points[i]),points[i]))
        else :
            (d , p) = h.heappop(answerSet)
            d1 = distance(Q,points[i])
            if d1 < -d :
                h.heappush(answerSet,(-d1,points[i]))
            else :
                h.heappush(answerSet,(d,p))

    return answerSet
    

if __name__ == '__main__':

	dataset_file = sys.argv[1]

	# [TODO] Construct kdTree using dataset_file here
	file = open(dataset_file,"r")
	s = file.readline()
	s = s.split(" ")
	k = int(s[0])
	N = int(s[1])
	points = []

	for i in range(N):
		s = file.readline()
		s = s.strip().split(" ")

		arr = list(map(float,s))
		points.append(arr)

	file.close()

	root = genKDTree(points,[0.0]*k , [1.0]*k)


	# Request name/path of query_file from parent by just sending "0" on stdout
	sys.stdout.write('0\n')

	# Wait till the parent responds with name/path of query_file and k | Timer will start now
	query_file = input()
	k_NN = int(input())

	# [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt
	file = open(query_file,"r")
	s = file.readline()
	s = s.split(" ")
	N = int(s[1])
	query_points = []

	for i in range(N):
		s = file.readline()
		s = s.strip().split(" ")

		arr = list(map(float,s))
		query_points.append(arr)

	file.close()

	file = open("results.txt","w")
	s = ""
	for i in range(len(query_points)) :
		t = kNNSearch(query_points[i],root,k_NN)
		t.sort(cmp=lambda (d1,p1), (d2,p2): new_compare(-d1, p1, -d2, p2))
		for i in range(len(t)):
			line = ""
			point = t[i]
			for j in range(len(point)):
				line = line + str(point[j]) + " "
			line = line + "\n"
			s = s + line

	file.write(s)
	file.close()

	# Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	sys.stdout.write('1\n')
