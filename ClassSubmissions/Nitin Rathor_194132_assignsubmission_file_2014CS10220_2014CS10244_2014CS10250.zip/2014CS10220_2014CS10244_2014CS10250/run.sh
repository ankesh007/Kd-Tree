#!/bin/bash
python modify.py $1
g++ -std=c++14 -O3 sample.cpp; ./a.out $1