import sys

with open(sys.argv[1], 'r') as f:
	d, n = map(int, f.readline().split())

with open('sample.cpp', 'r+') as f:
	lines = f.readlines()
	lines[3] = 'const int D = ' + str(d) + ';\n'
	lines[4] = 'const int N = ' + str(n+10) + ';\n'
	f.seek(0)
	f.truncate()
	map(f.write, lines)
