#include <bits/stdc++.h>
using namespace std;

const int D = 2;
const int N = 13;

#define sqr(x) (fabs(x) * fabs(x))
#define INSERT(answer, k, worstPoint, rect) \
				if (answer.size() < k) { \
					answer.push(rect->point); \
				} else if (distP2(n+1, worstPoint) >= distP2(n+1, rect->point)) { \
					answer.push(rect->point); \
					answer.pop(); \
				}

double POINTS[N][D];

struct node
{
	int point;
	double minRec[D], maxRec[D];
	int branch_axis, sz;
	node *lft, *rgt;

	node(int p=0, int axis=0) : point(p), sz(1), branch_axis(axis), lft(NULL), rgt(NULL) {
		memcpy(minRec, POINTS[p], sizeof minRec);
		memcpy(maxRec, POINTS[p], sizeof maxRec);
	};
};


int axis;
inline bool compare(int i, int j) {
	return POINTS[i][axis] < POINTS[j][axis];
};

inline double distR2(int p, node* rect) {
	double ans = 0;
	for (int i=0; i<D; i++) {
		if (POINTS[p][i] < rect->minRec[i])
			ans += sqr(POINTS[p][i] - rect->minRec[i]);
		else if (POINTS[p][i] > rect->maxRec[i])
			ans += sqr(POINTS[p][i] - rect->maxRec[i]);
	}
	return ans;
}

inline double distP2(int p, int a) {
	double ans = 0;
	for (int i=0; i<D; i++) {
		ans += sqr(POINTS[p][i] - POINTS[a][i]);
	}
	return ans;
}

int nG;
inline bool compPointPQ(int i, int j) {
	double di = distP2(nG+1, i);
	double dj = distP2(nG+1, j);
	if (di != dj)
		return di < dj;
	for (int it=0; it<D; it++) {
		if (POINTS[i][it] != POINTS[j][it])
			return POINTS[i][it] < POINTS[j][it];
	}
	cerr << "WARNING: There are points in the dataset which are not distinct!\n";
	return 0;
}

inline bool compNodePQ(node* i, node* j) {
	return distR2(nG+1, i) > distR2(nG+1, j);
}

class KDTree
{
	int n, d;

	void relax(node *par, node* child) {
		par->sz += child->sz;
		for (int i=0; i<d; i++) {
			par->minRec[i] = min(par->minRec[i], child->minRec[i]);
			par->maxRec[i] = max(par->maxRec[i], child->maxRec[i]);
		}
	}

	node* construct(vector<int> &pnts) {
		sort(pnts.begin(), pnts.end(), compare);
		int mid = pnts.size() / 2;
		node *rt = new node(pnts[mid]);
		if (pnts.size() == 1) {
			return rt;
		}
		// construct right subtree
		if (pnts.size() > 2) {
			vector<int> rightPnts(pnts.begin() + mid+1, pnts.end());
			axis = (axis + 1) % d;
			rt->rgt = construct(rightPnts);
			relax(rt, rt->rgt);
			axis = (axis + d-1) % d;
		}
		// construct left subtree
		pnts.resize(mid);
		axis = (axis + 1) % d;
		rt->lft = construct(pnts);
		relax(rt, rt->lft);
		axis = (axis + d-1) % d;

		return rt;
	};

	void dfs(priority_queue<int, vector<int>, function<bool(int,int)>> &answer, int k, node* rect) {
		INSERT(answer, k, answer.top(), rect);
		if (rect->lft)
			dfs(answer, k, rect->lft);
		if (rect->rgt)
			dfs(answer, k, rect->rgt);
	}

public:
	node* root;
	KDTree();
	KDTree(char* dataset_file) {
		ifstream fin(dataset_file);
		fin >> d >> n;
		nG = n;

		// Read all POINTS
		vector<int> pnts;
		for (int i=1; i<=n; i++) {
			pnts.push_back(i);
			for (int j=0; j<d; j++) {
				fin >> POINTS[i][j];
			}
		}

		// construct KDTree
		axis = 0;
		root = construct(pnts);

		fin.close();
		cerr << "-----------construction of KDTree done-----------" << endl;
	};

	void kNN_Query(char* query_file, int k) {
		FILE *fp0 = fopen(query_file, "r");
		int d1, n1;
		fscanf(fp0, "%d%d", &d1, &n1);
		assert(d == d1);

		FILE* fp = fopen("results.txt", "w");
		for (int i=0; i<n1; i++) {
			for (int j=0; j<d; j++) {
				fscanf(fp0, "%lf", &POINTS[n+1][j]);
			}
			priority_queue<int, vector<int>, function<bool(int,int)>> answer(compPointPQ);
			priority_queue<node*, vector<node*>, function<bool(node*,node*)>> MBR(compNodePQ);
			MBR.push(root);

			// start the best-first algo
			while (!MBR.empty()) {
				node* bestRec = MBR.top();
				MBR.pop();
				int worstPoint = (answer.empty() ? 0 : answer.top());
				if (answer.size() == k && distP2(n+1, worstPoint) < distR2(n+1, bestRec)) {
					break;
				}
				// insert point in answer if necessary
				INSERT(answer, k, worstPoint, bestRec);

				// push the children nodes of current node in the MBR
				// if the size of node is too small then directly push the points in answer
				if (bestRec->lft) {
					if (bestRec->lft->sz > 31)
						MBR.push(bestRec->lft);
					else
						dfs(answer, k, bestRec->lft);
				}
				if (bestRec->rgt) {
					if (bestRec->rgt->sz > 31)
						MBR.push(bestRec->rgt);
					else
						dfs(answer, k, bestRec->rgt);
				}
			}

			// print the query points in results.txt
			assert(answer.size() == k);
			vector<int> finalAnswer;
			while (!answer.empty()) {
				finalAnswer.push_back(answer.top());
				answer.pop();
			}
			for (int p=k-1; p>=0; p--) {
				for (int i=0; i<d; i++)
					fprintf(fp, "%.10lf ", POINTS[finalAnswer[p]][i]);
				fprintf(fp, "\n");;
			}
		}
		fclose(fp0);
		fclose(fp);
	}

	void printTree(node* rt, int tab=0) {
		for (int i=0; i<tab; i++) {
			cerr << "  ";
		}
		for (int i=0; i<d; i++) {
			cerr << POINTS[rt->point][i] << " ";
		} cerr << endl;
		if (rt->lft) printTree(rt->lft, tab+1);
		if (rt->rgt) printTree(rt->rgt, tab+1);
	}
};

void sequentialScan(char* query_file, int k) {
	ifstream fin(query_file);
	int d, n1;
	fin >> d >> n1;

	ofstream fout("results1.txt");
	double ratio = 0;
	for (int i=0; i<n1; i++) {
		for (int j=0; j<d; j++) {
			fin >> POINTS[nG+1][j];
		}
		priority_queue<int, vector<int>, function<bool(int,int)>> answer(compPointPQ);
		for (int j=1; j<=k; j++) {
			answer.push(j);
		}
		for (int j=k+1; j<=nG; j++) {
			answer.push(j);
			answer.pop();
		}
		// print the query points in results1.txt
		assert(answer.size() == k);
		vector<int> finalAnswer;
		while (!answer.empty()) {
			finalAnswer.push_back(answer.top());
			answer.pop();
		}
		for (int p=k-1; p>=0; p--) {
			for (int i=0; i<d; i++)
				fout << fixed << setprecision(10) << POINTS[finalAnswer[p]][i] << " ";
			fout << "\n";
		}
		if (k >= 100) {
			ratio += sqrt(distP2(nG+1, finalAnswer[k-2])) /
					 sqrt(distP2(nG+1, finalAnswer[k-100]));
		}
	}
	if (k >= 100) cerr << "\nAvg. ratio (d2 / d100)\t=\t" << ratio / n1 << "\n\n";
	fin.close();
	fout.close();
}


int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];
	KDTree myTree(dataset_file);
	// myTree.printTree(myTree.root);

	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k
	// Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;

	// Query using KDTree
	clock_t start = clock();
	myTree.kNN_Query(query_file, k);
	clock_t end = clock();
	cerr << "time taken for queries using KDTree:\t\t" <<
		fixed << setprecision(10) << 1000. * (end - start) / CLOCKS_PER_SEC << "ms\n";

	// Query using sequential scan
	/*start = clock();
	sequentialScan(query_file, k);
	end = clock();
	cerr << "time taken for queries using sequentialScan:\t" <<
		fixed << setprecision(10) << 1000. * (end - start) / CLOCKS_PER_SEC << "ms\n";*/


	// Convey to parent that results.txt is ready by sending "1" on stdout
	// Timer will stop now and this process will be killed
	cout << 1 << endl;

	return 0;
}


