#include <iostream>
//#include <stdlib>
#include <vector>
#include <fstream>
#include <string>
#include <algorithm>
#include <queue>
#include <cmath>
#include <ctime>
#include <sstream>
#define COUNT 10

//#include<bits/stdc++.h>
using namespace std;

struct point
{
	vector <double> dim;
	point() {}
	point(vector<double> &v) :dim(v) {}
};

struct node
{
	vector <vector <double> > dbase;
	vector <double> bound_low;
	vector <double> bound_high;
	point* data;
	node *left, *right;
	int axis;
	double split_value;
	//node(point p ,vector<vector<point> > &c, int ax, int slt,node l=NULL ,node r=NULL):data(p),dbase(c),axis(ax),split_value(slt),left(l),right(r) {}
};

struct node* newNode(vector <vector <double> > &vv)
{
	struct node* temp = new node;
	temp->dbase = vv;

	int d = vv[0].size() - 1;
	int n = vv.size();
	vector<double> l(d + 1, 0);
	vector<double> h(d + 1, 0);
	for (int i = 1;i <= d;i++)
	{
		double cur_low = vv[0][i];
		double cur_high = vv[0][i];

		for (int j = 0;j < n;j++)
		{
			if (cur_low > vv[j][i])cur_low = vv[j][i];
			if (cur_high < vv[j][i])cur_high = vv[j][i];
		}
		l[i] = cur_low;
		h[i] = cur_high;
	}
	temp->bound_low = l;
	temp->bound_high = h;
	temp->left = NULL;
	temp->right = NULL;
	return temp;
}

struct pq_node
{
	double dist;
	point* p;

	pq_node() {}
	pq_node(double d, point* q)
	{
		dist = d;
		p = q;
	}

	double get_d()
	{
		return dist;
	}
};

struct pq_comp
{
	bool operator()(const pq_node &p, const pq_node &q)
	{
		if (p.dist < q.dist)return true;
		if (p.dist == q.dist)
		{
			for (int i = 1;i < p.p->dim.size() - 1;i++)
			{
				if (p.p->dim[i] < q.p->dim[i])return true;
				if (p.p->dim[i] > q.p->dim[i])return false;

			}
		}
		return false;
	}
};


double dist(point* a, point* b)
{
	double ans = 0;
	int d = a->dim.size() - 1;
	for (int i = 1;i <= d;i++)
	{
		ans = ans + pow((a->dim[i] - b->dim[i]),2.0);
	}
	ans = sqrt(ans);
	return ans;
}



void sequencial_scan(vector<vector<double> > &v ,point* q ,priority_queue<pq_node, vector<pq_node>, pq_comp> &pq , int k )
{
	int dim = q->dim.size() - 1;

	double cur_best = pq.top().dist;
	

	for(int i=k;i<v.size();i++)
	{
		point* temp=new point(v[i]);
		double cur = dist(q,temp);
	
		if(cur <= cur_best)
		{
			pq_node as;
			as.dist = cur;
			as.p = temp;
			
			pq.push(as);
			pq.pop();
		}
	}

}

int main(int argc, char* argv[])
{
	int dimension=20;		;
	vector<vector<double > > v(100000, vector<double>(dimension+1, 0));
	ifstream myReadFile;
	myReadFile.open("dataset_100000.txt");
	int i = 0;
	int j = 0;
	if (myReadFile.is_open())
	{
		int flag1=0;
		string ss;
		while (!myReadFile.eof())
		{

			if (j == 0)v[i][j] = i;
			getline(myReadFile, ss);
			stringstream s(ss);
			string token;
			if(flag1==0)
			{
				flag1=1;
				continue;
			}
			while (!s.eof())
			{
				j++;
				string temp;
				s >> temp;
				v[i][j] = atof(temp.c_str());
				if (j == dimension)break;
			}
			j = 0;
			i++;
			if (i == 100000)break;
		}
	}
	
	std::ifstream infile("query_100.txt");
	std::string line;
	double start_s = clock();
	int kj = 1;

	ofstream myfile;
	myfile.open("seq_results.txt");
	int flag2=0;
	while (std::getline(infile, line))
	{
		std::istringstream iss(line);
		double n;
		if(flag2==0)
		{
			flag2=1;
			continue;
		}
		std::vector<double> qu;
		qu.push_back(0);
		while (iss >> n)
		{
			qu.push_back(n);
		}
		point* p = new point(qu);
		
		int kk = 20;

		priority_queue<pq_node, vector<pq_node>, pq_comp> pq;

		for (int i = 0;i < kk;i++)
		{
			pq_node qq;
			qq.p = new point(v[i]);
			qq.dist = dist(qq.p, p);
			pq.push(qq);
		}
		
		sequencial_scan(v, p, pq, kk );

		for (int i = 0;i < kk;i++)
		{
			point* c = pq.top().p;
			myfile<< dist(c,p) << " ";
			for (int j = 0;j < dimension + 1;j++)
			{
				if(j!=dimension)myfile << c->dim[j] << " ";
				else
					myfile <<c->dim[j]<< endl;
			}
			pq.pop();
		}
		
	}

	double stop_s = clock();
	cout<<"time: "<<  (stop_s-start_s)/CLOCKS_PER_SEC    <<endl;
	

	
}
