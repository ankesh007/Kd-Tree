#include <iostream>
//#include <stdlib>
#include <vector>
#include <fstream>
#include <string>
#include <algorithm>
#include <queue>
#include <cmath>
#include <ctime>
#include <sstream>
#define COUNT 10

//#include<bits/stdc++.h>
using namespace std;

struct point
{
	vector <double> dim;
	point() {}
	point(vector<double> &v) :dim(v) {}
};

struct node
{
	vector <vector <double> > dbase;
	vector <double> bound_low;
	vector <double> bound_high;
	point* data;
	node *left, *right;
	int axis;
	double split_value;
	//node(point p ,vector<vector<point> > &c, int ax, int slt,node l=NULL ,node r=NULL):data(p),dbase(c),axis(ax),split_value(slt),left(l),right(r) {}
};

struct node* newNode(vector <vector <double> > &vv)
{
	struct node* temp = new node;
	temp->dbase = vv;

	int d = vv[0].size() - 1;
	int n = vv.size();
	vector<double> l(d + 1, 0);
	vector<double> h(d + 1, 0);
	for (int i = 1;i <= d;i++)
	{
		double cur_low = vv[0][i];
		double cur_high = vv[0][i];

		for (int j = 0;j < n;j++)
		{
			if (cur_low > vv[j][i])cur_low = vv[j][i];
			if (cur_high < vv[j][i])cur_high = vv[j][i];
		}
		l[i] = cur_low;
		h[i] = cur_high;
	}
	temp->bound_low = l;
	temp->bound_high = h;
	temp->left = NULL;
	temp->right = NULL;
	return temp;
}

struct pq_node
{
	double dist;
	point* p;

	pq_node() {}
	pq_node(double d, point* q)
	{
		dist = d;
		p = q;
	}

	double get_d()
	{
		return dist;
	}
};

struct pq_comp
{
	bool operator()(const pq_node &p, const pq_node &q)
	{
		if (p.dist < q.dist)return true;
		if (p.dist == q.dist)
		{
			for (int i = 1;i < p.p->dim.size() - 1;i++)
			{
				if (p.p->dim[i] < q.p->dim[i])return true;
				if (p.p->dim[i] > q.p->dim[i])return false;

			}
		}
		return false;
	}
};

node* build_kdtree(node* root, int dim)
{

	int siz = root->dbase.size();
	int half_size = siz / 2;
	int d = root->dbase[0].size() - 1;

	if (siz == 1)
	{
		root->left = NULL;
		root->right = NULL;
		root->axis = dim;
		root->data = new point(root->dbase[0]);
		root->bound_high = root->dbase[0];
		root->bound_low = root->dbase[0];
		return root;
	}

	if (siz == 2)
	{
		root->right = NULL;
		root->axis = dim;
		sort(root->dbase.begin(), root->dbase.end(), [&dim](const std::vector<double>& u, const std::vector<double>& v) {return u[dim]<v[dim]; });
		root->data = new point(root->dbase[1]);
		node* curr = new node;
		curr->data = new point(root->dbase[0]);
		curr->bound_low = root->dbase[0];
		curr->bound_high = root->dbase[0];
		curr->right = NULL;
		curr->left = NULL;
		if (dim == d)dim = 1;
		else dim++;
		curr->axis = dim;
		root->left = curr;
		return root;
	}


	sort(root->dbase.begin(), root->dbase.end(), [&dim](const std::vector<double>& u, const std::vector<double>& v) {return u[dim]<v[dim]; });
	std::vector<vector<double> > split_lo(root->dbase.begin(), root->dbase.begin() + half_size);
	std::vector<vector<double> > split_hi(root->dbase.begin() + half_size + 1, root->dbase.end());


	root->data = new point(root->dbase[half_size]);
	root->axis = dim;
	root->split_value = root->dbase[half_size][dim];

	if (dim == d)dim = 1;
	else
		dim++;

	node* cur_left = newNode(split_lo);
	node* cur_right = newNode(split_hi);
	cur_right->axis = dim;
	cur_left->axis = dim;

	root->left = build_kdtree(cur_left, dim);
	root->right = build_kdtree(cur_right, dim);

	return root;

}

double dist(point* a, point* b)
{
	double ans = 0;
	int d = a->dim.size() - 1;
	for (int i = 1;i <= d;i++)
	{
		ans = ans + (a->dim[i] - b->dim[i])*(a->dim[i] - b->dim[i]);
	}
	ans = sqrt(ans);
	return ans;
}

double dist_bb(point* a, node* b)
{
	double ans = 0;
	int d = a->dim.size() - 1;

	for (int i = 1;i <= d;i++)
	{
		if ((a->dim[i]) < (b->bound_low[i]))
		{
			ans += ((a->dim[i]) - (b->bound_low[i]))*((a->dim[i]) - (b->bound_low[i]));
			continue;
		}
		if (a->dim[i] > b->bound_high[i])
		{
			ans += (a->dim[i] - b->bound_high[i])*(a->dim[i] - b->bound_high[i]);
		}

	}
	ans = sqrt(ans);
	return ans;
}


void knn2(point* q, node* root, int cd, priority_queue<pq_node, vector<pq_node>, pq_comp> &pq, int k, bool back)
{
	if (root == NULL)
		return;
	/*
	priority_queue<pq_node, vector<pq_node>, pq_comp> cc = pq;
	
	cout << "=======================================================" << endl;

	cout << "root...." << root->data->dim[0] << endl;
	cout << "dim..." << cd << endl;
	cout << "Size...." << pq.size() << endl;
	
	for (int h = 0;h < pq.size();h++)
	{
		point* c = cc.top().p;
		cout << cc.top().dist << "..   " << c->dim[0] << "  " << c->dim[1] << "  " << c->dim[2] << endl;
		cc.pop();

	}
	*/
	
	int dim = q->dim.size() - 1;

	if (!back)
	{
		if (q->dim[cd] < root->data->dim[cd])
		{
			if(cd == dim)cd = 0;
			knn2(q, root->left, cd + 1, pq, k, false);
			double cur_best = pq.top().dist;
			double cur = dist(q, root->data);
			if (cur <= cur_best && root->data->dim[0] >= k)
			{
				pq_node as;
				as.dist = cur;
				as.p = root->data;
				
				pq.push(as);
				pq.pop();
			}

			knn2(q, root->right, cd + 1, pq, k, true);
		}
		else
		{
			if (cd == dim)cd = 0;
			knn2(q, root->right, cd + 1, pq, k, false);

			double cur_best = pq.top().dist;
			double cur = dist(q, root->data);
			if (cur <= cur_best && root->data->dim[0] >= k)
			{
				pq_node as;
				as.dist = cur;
				as.p = root->data;
				
				pq.push(as);
				pq.pop();
				
			}

			knn2(q, root->left, cd + 1, pq, k, true);
		}
		return;
	}


		double cur_best = pq.top().dist;

		if (dist_bb(q, root) > cur_best)
			return;

		double cur = dist(q, root->data);

		if (cur <= cur_best && root->data->dim[0] >= k)
		{
			pq_node as;
			as.dist = cur;
			as.p = root->data;
			
			pq.push(as);
			pq.pop();
		}

		if (q->dim[cd] < root->data->dim[cd])
		{
			if (cd == dim)cd = 0;
			knn2(q, root->left, cd + 1, pq, k,true);
			knn2(q, root->right, cd + 1, pq, k,true);
		}
		else
		{
			if (cd == dim)cd = 0;
			knn2(q, root->right, cd + 1, pq, k,true);
			knn2(q, root->left, cd + 1, pq, k,true);
		}
	

}



void print2DUtil(node *root, int space)
{
	// Base case
	if (root == NULL)
		return;

	// Increase distance between levels
	space += COUNT;

	// Process right child first
	print2DUtil(root->right, space);

	// Print current node after space
	// count
	printf("\n");
	for (int i = COUNT; i < space; i++)
		cout << " ";
	cout << root->data->dim[0];

	// Process left child
	print2DUtil(root->left, space);
}

void print2D(node *root)
{
	// Pass initial space count as 0
	print2DUtil(root, 0);
}

int main(int argc, char* argv[])
{

	char* dataset_file = argv[1];

	vector<vector<double > > v;
	ifstream myReadFile(dataset_file);
	//myReadFile.open(dataset_file);
	int i = 0;
	int j = 0;
	/*if(myReadFile.is_open())
	{
		string ss;
		while (!myReadFile.eof())
		{
			if (j == 0)v[i][j] = i;
			getline(myReadFile, ss);
			stringstream s(ss);
			string token;
			while (!s.eof())
			{
				j++;
				string temp;
				s >> temp;
				v[i][j] = atof(temp.c_str());
				if (j == 20)break;
			}
			j = 0;
			i++;
			//if (i == 100000)break;
		}
	}*/
	int flag=0;
	int dim,len;
	int index=0;
	string line2;
	while (std::getline(myReadFile, line2))
	{

		std::istringstream iss(line2);
		double n;
		if(flag==0)
		{
			iss>>dim;
			iss>>len;
			flag=1;
			continue;
		}
		std::vector<double> qu;
		qu.push_back(index);
		int j_temp=0;
		while (iss >> n)
		{
			qu.push_back(n);
			j_temp++;
			if(j_temp==dim)break;
			
		}
		v.push_back(qu);
		index++;
		//if(index==len)break;
	}
	
	
	node *root = newNode(v);
	root = build_kdtree(root, 1);

	cout << 0 << endl;


	char* query_file = new char[100];
	int k;
	cin >> query_file;
	cin>>k;
	std::ifstream infile(query_file);
	std::string line;
	int start_s = clock();
	int kj = 1;

	ofstream myfile;
	myfile.open("results.txt");
	
	int flag2=0;
	int dimm;
	int query_len;
	int index2=0;
    double ans2=0;
    double ans100=0;
	while (std::getline(infile, line))
	{
		std::istringstream iss(line);
		if(flag2==0)
		{
			iss>>dimm;
			iss>>query_len;
			flag2=1;
			continue;
		}

		double n;
		std::vector<double> qu;
		qu.push_back(0);
		int j=0;
		while (iss >> n)
		{
			qu.push_back(n);
			j++;
			if(j==dim)break;
		}
		point* p = new point(qu);

		priority_queue<pq_node, vector<pq_node>, pq_comp> pq;

		for (int i = 0;i < k;i++)
		{
			pq_node qq;
			qq.p = new point(v[i]);
			qq.dist = dist(qq.p, p);
			pq.push(qq);
		}
		
		knn2(p, root, 1, pq, k, false);
		//knn(p,root,1,pq,k);
        point* n2;
        point* n100;
        int ind = 1 ;
		for (int i = 0;i < k;i++)
		{   
            if(ind==1)
			    ans100  = ans100+ dist(pq.top().p , p);
            if(ind==99)
                ans2=ans2+dist(pq.top().p,p);
			//myfile << dist(c,p)<<" ";
			ind++;
			pq.pop();
		}
		//if(index2==query_len)break;
	}
    myfile<<ans2/ans100<<endl;
    

	cout << 1 << endl;
}
