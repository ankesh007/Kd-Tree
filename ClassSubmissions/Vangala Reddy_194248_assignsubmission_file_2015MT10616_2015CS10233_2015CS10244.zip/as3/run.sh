#!/bin/bash
g++ sample.cpp -std=c++11; ./a.out $1
#python sample.py $1