#!/bin/bash
g++ sample.cpp; ./a.out $1
# python sample.py $1