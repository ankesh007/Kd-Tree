#include <bits/stdc++.h>
using namespace std;

int d,n,dq,k,num_query;		//d= dimension n= num of points  dq = dimension of query = d (must)
int maxd=0;					//maximum depth
int leaf_call = 0;
double * query;

class node{
	public:
	double* point;
	node* left;
	node* right;

	node(double * point){
		this->point = point;
		this->left = NULL;
		this->right = NULL;
	}
};

class pq_comparator{
	double* query;
	int d;
	public:
		int operator()( double* point1,  double* point2) {
			double dist1 = 0,dist2 = 0;
			for(int i=0;i<d;i++){
				dist1 += (point1[i] - query[i]) * (point1[i] - query[i]);
				dist2 += (point2[i] - query[i]) * (point2[i] - query[i]);
			}
			if(dist1 == dist2){
				for(int i=0;i<d;i++){
					if(point1[i] < point2[i])
						return true;
					else if(point2[i] < point1[i])
						return false;
					else
						continue;
				}
				return false;	
			} else
				return dist1 < dist2;
		}

		pq_comparator(double * query,int d)
		{
			this->query = query;
			this->d = d;
		}
};


class sort_comparator{
	int axis;

	public:
		int operator() (double * point1, double * point2){
			int i=0;
			while(i<d){
				if(point1[i+axis] < point2[i+axis])
					return true;
				else if(point1[i+axis] > point2[i+axis])
					return false;
				else
					i++;
			}
			return true;
		}


		sort_comparator(int axis){
			this->axis = axis;
		}
};

//applying only on root node and not on children
void kNN_no_child(node* root, int depth, priority_queue<double*,vector<double*>,pq_comparator> &pq, 
			      double &max_distance){
	leaf_call++;
	double* point = root->point;
	// cout<<point[0]<<" "<<point[1]<<" "<<max_distance<<endl;

	pq.push(point);
	if(pq.size() > k)
		pq.pop();

	double* top = pq.top();
	double temp_dist = 0;
	for(int i=0;i<d;i++)	
		temp_dist += (top[i] - query[i]) * (top[i] - query[i]);

	max_distance = temp_dist;
}

//max_distance is square of distance
void kNN_main(node* root, int depth, priority_queue<double*,vector<double*>,pq_comparator> &pq, 
				double &max_distance){
	// cout<<"here\n";
	int axis = depth % d;
	if(root == NULL){
	}
	else if(query[axis] < root->point[axis]){
		kNN_main(root->left,depth+1,pq,max_distance);
		if(root->point[axis] - query[axis] <= sqrt(max_distance)){
			kNN_main(root->right,depth+1,pq,max_distance);
			kNN_no_child(root,depth,pq,max_distance);
		}
		else { 
			if(pq.size() < k){
				kNN_main(root->right,depth+1,pq,max_distance);
				kNN_no_child(root,depth,pq,max_distance);
			}
		}
	} 
	else {
		kNN_main(root->right,depth+1,pq,max_distance);
		if(query[axis] - root->point[axis] <= sqrt(max_distance)){
			kNN_main(root->left,depth+1,pq,max_distance);
			kNN_no_child(root,depth,pq,max_distance);
		} 
		else{
			if(pq.size() < k){
				kNN_main(root->left,depth+1,pq,max_distance);
				kNN_no_child(root,depth,pq,max_distance);
			}
		}
	}
}

void kNN(node* root){
	pq_comparator pq_cmp(query,d);
	priority_queue <double* , vector<double*>, decltype(pq_cmp) > pq(pq_cmp);
	
	double max_distance = 2*d;
	kNN_main(root,0,pq,max_distance);

	double ** points = new double*[k];
	int i=0;
	// cout<<"size: "<<pq.size()<<endl;
	while(!pq.empty()){
		points[i++] = pq.top();
		pq.pop();
	}
	// cout<<i<<endl;
	ofstream ofile("results.txt",std::ios_base::app);
	for(int j=i-1;j>=0;j--){
		for(int dim=0;dim<d;dim++){
			ofile<<points[j][dim]<<" ";
		}
		ofile<<"\n";
	}

	// delete [] points;

	// for(int j=i-1;j>=0;j--){
	// 	double dist = 0;
	// 	for(int dim=0;dim<d;dim++){
	// 		dist += (query[dim] - points[j][dim])*(query[dim] - points[j][dim]);
	// 	}
	// 	ofile<<sqrt(dist)<<"\n";
	// }

	ofile.close();
}
 
node* build_tree(double **data,int l,int r,int depth){
	if(l > r)
		return NULL;
	else{
		maxd = max(maxd,depth);
		int axis = depth % d;
		sort(data + l,data + r,sort_comparator(axis));
		int median = (l + r)/2;
		node* root = new node(data[median]);
		root->left = build_tree(data,l,median-1,depth+1);
		root->right = build_tree(data,median+1,r,depth+1);
		return root;
	}
}

double** get_data(char* data_file){
	ifstream ifile;
	ifile.open(data_file);
	ifile>>d>>n;
	double **data = new double* [n];
	for(int i=0;i<n;i++){
		data[i] = new double[d];
		for(int j=0;j<d;j++){
			ifile>>data[i][j];
		}
	}
	ifile.close();
	return data;
}

int main(int argc, char * argv[]){
	char* data_file = argv[1];
	double **data = get_data(data_file);
	node* root = build_tree(data,0,n-1,0);

	cout<<0<<endl;
	// cout<<maxd<<endl;

	char* query_file = new char[100];
	// int k;
	cin >> query_file >> k;

	ifstream ifile;
	ifile.open(query_file);
	ifile>>dq>>num_query;

	ofstream ofile("results.txt");	//to create empty file
	ofile.close();

	query = new double[dq];
	for(int j=0;j<num_query;j++){
		// cout<<"query: "<<j<<endl;
		for(int i=0;i<dq;i++){
			ifile>>query[i];
		}
		kNN(root);
	}
	// cout<<leaf_call<<endl;
	cout<<1<<endl;
}