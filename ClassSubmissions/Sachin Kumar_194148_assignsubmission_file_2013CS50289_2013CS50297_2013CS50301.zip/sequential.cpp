#include <bits/stdc++.h>
using namespace std;

int d,n,dq,k,num_query;		//d= dimension n= num of points  dq = dimension of query = d (must)
int maxd=0;			//maximum depth
int leaf_call = 0;
double * query;


class pq_comparator{
	double* query;
	int d;
	public:
		int operator()( double* point1,  double* point2) {
			double dist1 = 0,dist2 = 0;
			for(int i=0;i<d;i++){
				dist1 += (point1[i] - query[i]) * (point1[i] - query[i]);
				dist2 += (point2[i] - query[i]) * (point2[i] - query[i]);
			}
			if(dist1 == dist2){
				for(int i=0;i<d;i++){
					if(point1[i] < point2[i])
						return true;
					else if(point2[i] < point1[i])
						return false;
					else
						continue;
				}
				return false;	
			} else
				return dist1 < dist2;
		}

		pq_comparator(double * query,int d)
		{
			this->query = query;
			this->d = d;
		}
};


double** get_data(char* data_file){
	ifstream ifile;
	ifile.open(data_file);
	ifile>>d>>n;
	double **data = new double* [n];
	for(int i=0;i<n;i++){
		data[i] = new double[d];
		for(int j=0;j<d;j++){
			ifile>>data[i][j];
		}
	}
	ifile.close();
	return data;
}

int main(int argc,char* argv[]){
	char* data_file = argv[1];
	double **data = get_data(data_file);
	cout<<"k: ";
	cin>>k;

	char* query_file = argv[2];
	ifstream ifile;
	ifile.open(query_file);
	ifile>>dq>>num_query;

	query = new double[dq];
	ofstream ofile("time_seq.csv",std::ios_base::app);
	ofstream ofile2("results_seq.txt",std::ios_base::app);

	for(int j=0;j<num_query;j++){
		for(int h=0;h<dq;h++){
			ifile>>query[h];
		}

		pq_comparator pq_cmp(query,d);
		priority_queue <double* , vector<double*>, decltype(pq_cmp) > pq(pq_cmp);
		auto start = std::chrono::system_clock::now();
		for(int i=0;i<n;i++){
			pq.push(data[i]);
			if(pq.size() > k)
				pq.pop();
		}
		auto end = std::chrono::system_clock::now();	
		std::chrono::duration<double> elapsed = end-start;
		// cout<<elapsed.count()<<endl;
		ofile<<elapsed.count()<<",";

		double ** points = new double*[k];
		int i=0;
		while(!pq.empty()){
			points[i++] = pq.top();
			pq.pop();
		}

		for(int g=i-1;g>=0;g--){
			for(int dim=0;dim<d;dim++){
				ofile2<<points[g][dim]<<" ";
			}
			ofile2<<"\n";
		}
	}
	ofile<<"\n";
	ofile.close();
	ofile2.close();	
}


