#!/bin/bash
g++ -std=c++11 -O3 main.cpp && ./a $1