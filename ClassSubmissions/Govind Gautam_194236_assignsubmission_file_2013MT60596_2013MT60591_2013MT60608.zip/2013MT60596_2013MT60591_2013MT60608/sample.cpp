#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <sstream>
#include <vector>
#include <bitset>
#include <limits>
#include <algorithm>
#include <cmath>
#include <ctime>
using namespace std;

// TO DO
// implement ki agar ek point hi hai knn vala toh ignore that and find among rest of neighbours - done most probably in knn function - confirm ki yahi karna tha na
// check inclusive vala fundae
// lexicographic sorting of points - do it while adding points to heap as well - done (check if it can be done without editing initial comparator)
// sequential vala - debugging

void pvv(vector<vector<double> > data);

vector<vector<double> > read_file(char* file_name){
	ifstream infile(file_name);
	string line;
	getline(infile,line);
	// cerr<<line<<endl;
    istringstream f(line);
	int D, N; 
    string s;
    getline(f,s,' '); D=stoi(s);
    getline(f,s,' '); N=stoi(s);    
    // cerr<<N<<" "<<D<<" "<<endl;
    vector<vector<double> > points;
    int i=0; int j=0;
    vector<double> newpt(D,0.0);
    while (i<N){
    	getline(infile,line);
	    istringstream f(line);
	    j=0;
	    while (j<D){
	    	getline(f,s,' '); newpt[j]=atof(s.c_str());
	    	// cerr<<atof(s.c_str())<<endl;
	    	j++;
	    }
	    points.push_back(newpt);
    	// cerr<<line<<endl;
    	i++;
    }
    return points;
    // pvv(points);
}

vector<vector<double> > queries(char* file_name){
	ifstream infile(file_name);
	string line;
	getline(infile,line);
	// cerr<<line<<endl;
    istringstream f(line);
	int d; 
    string s;
    getline(f,s,' '); d=stoi(s);
    // cerr<<" "<<d<<" "<<endl;
    vector<vector<double> > points;
	int j=0;
    vector<double> newpt(d,0.0);
    while (getline(infile,line)){
	    istringstream f(line);
	    j=0;
	    while (j<d){
	    	getline(f,s,' '); newpt[j]=atof(s.c_str());
	    	// cerr<<atof(s.c_str())<<endl;
	    	j++;
	    }
	    points.push_back(newpt);
    	// cerr<<line<<endl;
    }
    // cerr<<points.size()<<endl;
    return points;
    // pvv(points);

}


void pvv(vector<vector<double> > data){
	cerr<<"printing data vector of vector"<<"\n";
	int i=0;int j=0; int N=data.size();int D=data[0].size();
	while (i<N){
		j=0;
		while(j<D){
			cerr<<data[i][j]<<" ";
			j++;
		}
		i++;
		cerr<<"\n";
	}
}

void pv(vector<double> d){
	// cerr<<"printing double vector"<<endl;
	for (int i=0;i<d.size();i++){
		cerr<<d[i]<<" ";
	}
	cerr<<"\n";
}

bool sort_col(const vector<int>& v1,const vector<int>& v2, int dim){
	return v1[dim]<v2[dim];
}

vector<vector<double >>* pre_sort(vector<vector<double >> data, int D){
	vector<vector<double >>* sort_data=new vector<vector<double >>[D];
	for (int i=0;i<D;i++){
		sort(data.begin(),data.end(),[&i](const std::vector< double >& a, const std::vector< double >& b){ return a[i] < b[i]; });
		sort_data[i]=data;
		// pvv(sort_data[i]);
	}
	return sort_data;
}

//use of bitset to keep track of relevant points is complicated - both space it takes potentially - 12.5 mb for 1lac bits....
//as well as the need to dynamically allocate bitset according to no of data points
struct node{
	double split;
	// bitset* presence;
	double* range_min;
	double* range_max;
	int level;
	node* left;
	node* right;
	node* parent;
};

struct point{
	vector<double> pt;
	double ds;
};

struct ds_node{
	node* r;
	double ds;
};
// from stackoverflow - https://stackoverflow.com/questions/2574060/c-min-heap-with-user-defined-type
// for min heap
// struct doc {
//     double rank;
//     explicit doc(double r) : rank(r) {}
// };

// struct doc_rank_greater_than {
//     bool operator()(doc const& a, doc const& b) const {
//         return a.rank > b.rank;
//     }
// };

struct comp_point{
	bool operator()(const point& a,const point& b) const{
	if (a.ds==b.ds){
		for (int i=0;i<a.pt.size();i++){
			if (a.pt[i]==b.pt[i]) continue;
			else return (a.pt[i]<b.pt[i]);
		}
	}
	return a.ds<b.ds;
	}
};

// struct comp_point2{
// 	bool operator()(const point& a,const point& b) const{
// 		return a.ds<b.ds;
// 	}
// };
struct comp_point1{
	bool operator()(const point& a,const point& b) const{
	return a.ds>b.ds;
	}
};

struct comp_ds_node{
	bool operator()(const ds_node& a, const ds_node& b) const{
		return (a.ds>b.ds);
	}	
};

//for each dimension keep 2 D dimensional double ki arrays - minimum in that and maximum in that
//then for median - O(n) mein check which points are relevant
//then either use O(nlogn) sorting or O(n) median finding algo
//this is for bulk insert only
class kdtree{
private:
	vector<vector<double>> data;
	node* root;
	int D;
	int N;

public:
	//sorted data is troublesome
	kdtree(vector<vector<double>> s_data){
		data=s_data;
		root=new node;
		N=data.size();
		D=data[0].size();
		root->level=0;
		root->parent=NULL;
		root->left=NULL;
		root->right=NULL;
		//initializ range_min array - fill with minus inf
		root->range_min=new double[D];
		for (int i=0;i<D;i++){
			root->range_min[i]=-0.5;
		}
		//initializ range_max array - fill with plus inf
		root->range_max=new double[D];
		for (int i=0;i<D;i++){
			root->range_max[i]=numeric_limits<double>::max();
		}
		// presence=1;
		double median=find_median(root,root->level);
		// cerr<<"median is "<<median<<'\n';
		if (median!=-0.9){
			root->split=median;
			// bitset* left=find_less(data,median,presence);
			// auto right=~left;
			bulk_insert_left(root,median);
			// bulk_insert_right(root,median);			
		}
	}

	void pa(double* d){
		cerr<<"printing double array"<<endl;
		for (int i=0;i<D;i++){
			cerr<<d[i]<<" ";
		}
		cerr<<endl;
	}

	// double find_median(vector<vector<double>> data,bitset* p,int l){
	double find_median(node* r,int l){
		//first take the relevant points
		vector<double> relpts;
		vector<vector<double>> comp_pts;
		// cerr<<"printing range_min"<<endl;
		// pa(r->range_min);
		// cerr<<"printing range_max"<<endl;
		// pa(r->range_max);
		bool inrange=true;
		for (int i=0;i<N;i++){
			inrange=true;
			for (int j=0;j<D;j++){
				if (data[i][j]<r->range_min[j] or data[i][j]>=r->range_max[j]) {
					inrange=false; break;
				}
			}
			if (inrange) {
				relpts.push_back(data[i][l]);
				comp_pts.push_back(data[i]);
			}
		}
		// pv(relpts);
		//now find the median
		if (relpts.size()==1) {
			r->split=-0.9;
			for (int i=0;i<D;i++){
				r->range_min[i]=comp_pts[0][i];
				r->range_max[i]=comp_pts[0][i];
			}
			// cerr<<"Printing the only vertex"<<endl;
			// pa(r->range_min);
			return -0.9;
		}
		else if (relpts.size()==0) {
			cerr<<"Relevant points are not there"<<" CHECK THE ERROR"<<endl;
			return -0.9;
		}
		nth_element(relpts.begin(),relpts.begin()+relpts.size()/2,relpts.end());
		return relpts[relpts.size()/2];
	}

	// bitset* find_less(vector<vector<double>> data, double m, bitset* p){
	// 	return p;
	// }

	// void bulk_insert_left(vector<vector<double>> data, node* r, bitset* p){
	void bulk_insert_left(node* r, double median){
		//this is important - otherwise error ata hai - to use new
		node* left_child=new node;
		left_child->parent=r;
		r->left=left_child;
		left_child->left=NULL;
		left_child->right=NULL;
		left_child->level=r->level+1;

		//cant point it to r->range_min - kyunki changes karne hain
		left_child->range_min=new double[D];
		for (int i=0;i<D;i++) left_child->range_min[i]=r->range_min[i];
		left_child->range_max=new double[D];
		for (int i=0;i<D;i++) left_child->range_max[i]=r->range_max[i];
		// check it with max of median and r->range_max[r->level%D]
		left_child->range_max[r->level%D]=median;

		node* right_child=new node;
		right_child->parent=r;
		r->right=right_child;
		right_child->left=NULL;
		right_child->right=NULL;
		right_child->level=r->level+1;

		right_child->range_min=new double[D];
		for (int i=0;i<D;i++) right_child->range_min[i]=r->range_min[i];
		right_child->range_max=new double[D];
		for (int i=0;i<D;i++) right_child->range_max[i]=r->range_max[i];
		// check it with min of median and r->range_min[r->level%D]
		right_child->range_min[r->level%D]=median;

		double mid=find_median(left_child,left_child->level%D);
		// cerr<<"median is "<<mid<<'\n';
		if (mid!=-0.9) {
			left_child->split=mid;
			bulk_insert_left(left_child,mid);
		}
		mid=find_median(right_child,right_child->level%D);
		// cerr<<"median is "<<mid<<'\n';
		if (mid!=-0.9){
			right_child->split=mid;
			bulk_insert_left(right_child,mid);
		}


	}

	// // void bulk_insert_right(vector<vector<double>> data, node* r, bitset* p){
	// void bulk_insert_right(node* r, double median){
		
	// }

	double dist(node* r, vector<double> pt){
		double d=0.0;
		for (int i=0;i<pt.size();i++){
			if (pt[i]<r->range_min[i]) d+=pow((r->range_min[i]-pt[i]),2);
			else if (pt[i]>r->range_max[i]) d+=pow((pt[i]-r->range_max[i]),2);
		}
		return d;
	}

	double dp2p(vector<double> pt1, vector<double> pt2){
		double ans=0;
		for (int i=0;i<pt1.size();i++){
			ans+=pow(pt1[i]-pt2[i],2);
		}
		return ans;
	}

	double dummy(vector<double> k){
		return k[0];
	}

	void knn(int k, vector<double> pt){
		ds_node first;
		first.r=new node;
		first.r=root;
		first.ds=dist(first.r,pt);
		vector<ds_node> mbr_min_heap;
		mbr_min_heap.push_back(first);
		make_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());
		int i=0;
		vector<point> ans_max_heap;
		// assuming no of vertices are greater than knn ka k
		while(i<k){
			first=mbr_min_heap.front();
			  // std::pop_heap (v.begin(),v.end()); v.pop_back();
			pop_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());
			mbr_min_heap.pop_back();
			if (first.r->split!=-0.9){
				ds_node one;
				one.r=first.r->left;
				one.ds=dist(one.r,pt);
				mbr_min_heap.push_back(one);
				push_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());
				one.r=first.r->right;
				one.ds=dist(one.r,pt);
				mbr_min_heap.push_back(one);
				push_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());	
			}
			else{
				i++;
				// extract and push the point back
				point new_neighbour;
				for (int i=0;i<D;i++){
					new_neighbour.pt.push_back(first.r->range_min[i]);
				}
				new_neighbour.ds=dp2p(new_neighbour.pt,pt);
				// if (new_neighbour.ds==0) i--;
				// else ans_max_heap.push_back(new_neighbour);
				ans_max_heap.push_back(new_neighbour);
			}
		}
		make_heap(ans_max_heap.begin(),ans_max_heap.end(),comp_point());

		first=mbr_min_heap.front();
		pop_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());
		mbr_min_heap.pop_back();
		point farthest=ans_max_heap.front();
		while(first.ds<farthest.ds){
			if (first.r->split!=-0.9){
				ds_node one;
				one.r=first.r->left;
				one.ds=dist(one.r,pt);
				mbr_min_heap.push_back(one);
				push_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());
				one.r=first.r->right;
				one.ds=dist(one.r,pt);
				mbr_min_heap.push_back(one);
				push_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());	
			}
			else{
				// check if this is a better neighbour- will be true because of while loop
				// extract and push the point back 
				point new_neighbour;
				pop_heap(ans_max_heap.begin(),ans_max_heap.end(),comp_point());
				ans_max_heap.pop_back();
				for (int i=0;i<D;i++){
					new_neighbour.pt.push_back(first.r->range_min[i]);
				}
				new_neighbour.ds=dp2p(new_neighbour.pt,pt);
				// if (new_neighbour.ds>0) {
				// 	ans_max_heap.push_back(new_neighbour);
				// 	push_heap(ans_max_heap.begin(), ans_max_heap.end(), comp_point());
				// }
				ans_max_heap.push_back(new_neighbour);
				push_heap(ans_max_heap.begin(), ans_max_heap.end(), comp_point());

			}
			first=mbr_min_heap.front();
			pop_heap(mbr_min_heap.begin(),mbr_min_heap.end(), comp_ds_node());
			mbr_min_heap.pop_back();
			point farthest=ans_max_heap.front();			
		}
		sort_heap(ans_max_heap.begin(),ans_max_heap.end(),comp_point());
		ofstream results_file;
		results_file.open("results.txt",fstream::app);
		for (int j=0;j<k;j++){
			// cerr<<"dist is "<<ans_max_heap[j].ds<<"\n";
			// pv(ans_max_heap[j].pt);
			for (int zs=0;zs<D;zs++){
				results_file<<ans_max_heap[j].pt[zs]<<" ";
			}
			results_file<<"\n";
		}
		results_file.close();
		// cerr<<ans_max_heap[1].ds<<" "<<ans_max_heap[k-1].ds<<"\n";
	}

	void queries_knn(char* file_name, int k){
		vector<vector<double> > query_vec=queries(file_name);
		// pvv(query_vec);
		// cerr<<query_vec.size()<<endl;
		// clock_t begin = clock();
		remove("results.txt");
		for (int i=0;i<query_vec.size();i++){
			// cerr<<"\n\n\n";
			knn(k,query_vec[i]);
			// vector<point> t = knn(k,query_vec[i]);
			// for (int j=0;j<t.size();j++){
			// 	cerr<<t[j].ds<<"\n";
			// 	pv(t[j].pt);
			// }
		}
		// clock_t end = clock();
		// double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
		// cerr<<"total seconds taken "<<elapsed_secs<<" with "<<elapsed_secs/query_vec.size()<<" seconds per "<<k<<"-NN"<<endl;
	}

};

double dp2p(vector<double> a,vector<double> b){
	double ans=0;
	for (int i=0;i<a.size();i++){
		ans+=pow(a[i]-b[i],2);
	}
	return ans;
}

void sequential_knn(vector<vector<double>> data,char* query_file, int k, int D){
	vector<vector<double> > query_vec=read_file(query_file);
	clock_t begin = clock();
	double temp=0;
	double avera=0;
	for (int i=0;i<query_vec.size();i++){
		vector<point> ans;
		int j=0;
		int seq=0;
		while(j<k){
			temp=dp2p(data[seq],query_vec[i]);
			// if (temp>0){
			// 	point new_neighbour;
			// 	for (int x=0;x<D;x++){
			// 		new_neighbour.pt.push_back(data[seq][x]);
			// 	}
			// 	new_neighbour.ds=temp;
			// 	j++;
			// 	ans.push_back(new_neighbour);
			// }
			point new_neighbour;
			for (int x=0;x<D;x++){
				new_neighbour.pt.push_back(data[seq][x]);
			}
			new_neighbour.ds=temp;
			j++;
			ans.push_back(new_neighbour);
			seq++;
		}
		make_heap(ans.begin(),ans.end(),comp_point());
		for (int x=seq;x<data.size();x++){
			temp=dp2p(data[x],query_vec[i]);
			// if (temp<ans[0].ds and temp>0){
			if (temp<ans[0].ds){
				// pop_heap and then insert
				pop_heap(ans.begin(),ans.end(),comp_point());
				ans.pop_back();
				point new_neighbour;
				for (int y=0;y<D;y++){
					new_neighbour.pt.push_back(data[x][y]);
				}
				new_neighbour.ds=temp;
				ans.push_back(new_neighbour);
				push_heap(ans.begin(),ans.end(),comp_point());
			}
		}
		sort_heap(ans.begin(),ans.end(),comp_point());
		ofstream results_file;
		results_file.open("results.txt",fstream::app);
		for (int j=0;j<k;j++){
			// cerr<<"dist is "<<ans[j].ds<<"\n";
			// pv(ans_max_heap[j].pt);
			for (int zs=0;zs<D-1;zs++){
				results_file<<ans[j].pt[zs]<<" ";
			}
			results_file<<"ans[j].pt[D-1]\n";
		}
		results_file.close();
		cerr<<"distances are : "<<ans[1].ds<<" "<<ans[k-1].ds<<" "<<ans[1].ds/ans[k-1].ds<<"\n";
		avera+=ans[1].ds/ans[k-1].ds;

	}
	cerr<<"average ratio is : "<<avera/query_vec.size()<<"\n";
	clock_t end = clock();
	double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
	cerr<<"total seconds taken "<<elapsed_secs<<" with "<<elapsed_secs/query_vec.size()<<" seconds per "<<k<<"-NN"<<"\n";

}


int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];	
	// [TODO] Construct kdTree using dataset_file here
	vector<vector<double> > data=read_file(dataset_file);
	int D=data[0].size();
	int N=data.size();
	kdtree check(data);
	// vector<vector<double >>* sort_data=new vector<vector<double >>[data[0].size()];
	// sort_data=pre_sort(data, data[0].size());




	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;
	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	cerr << dataset_file << " " << query_file << " " << k << endl;
	check.queries_knn(query_file,k);
	// sequential_knn(data,query_file,k,D);

	// why THE FUCK does this throw an error
	// vector<vector<double> > query_vec=queries(file_name);
	// pvv(query_vec);
	// cerr<<query_vec.size()<<endl;

	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
}
