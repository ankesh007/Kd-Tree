#!/bin/bash
g++ -std=c++14 -O3 sample.cpp; ./a.out $1