#!/bin/bash
g++ -O3 -Ofast kdtree.cpp; ./a.out $1
