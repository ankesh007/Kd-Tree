#include <bits/stdc++.h>

using namespace std;

int setDim;
int Dimensions;
double bestDist = 0.0;

vector< vector<double> > pointSet;


bool cmp(const vector<double> &a,const vector<double> &b)
{
	return a[setDim] < b[setDim];
}


class node
{
public:
node(int leftIdx, int rightIdx);
vector<double> divider;         // The median point chosen to divide the MBR
int dimension_index;         // The index of the division for this box
vector<double> mbrIntercepts;         // The min-max for each dimension successively for this MBR
int leftIndex;
int rightIndex;
node *left;
node *right;
};

node::node(int leftIdx, int rightIdx)
{
	divider.resize(Dimensions,0.0);
	dimension_index = 0;
	mbrIntercepts.resize(2*Dimensions,0.0);
	leftIndex = leftIdx;
	rightIndex = rightIdx;
	left = NULL;
	right = NULL;
}

// struct node* createNode(int leftIndex, int rightIndex)
// {
//   struct node* node = (struct node*)malloc(sizeof(struct node));
//   node->leftIndex = leftIndex;
//   node->rightIndex = rightIndex;
//   node->left = NULL;
//   node->right = NULL;
//   return(node);
// }



class kdtree
{
public:
kdtree();
void findMedian(int leftIndex, int rightIndex, int dimension_index);
void buildtree(int dimensions);
vector<double> getMbr(node *head);
void printTree(node *head, string code);
void dummy();
void _buildtree(node *head);
node *root;
double dist(const vector<double>& v1, const vector<double>& v2);
vector<vector<double> > knn(vector<double>& query, int k);
double distMBR(const vector<double>& mbrIntercepts, const vector<double>& query);
vector<vector<double> > bruteForce(vector<vector<double> >& points, const vector<double>& query, int k);
};

kdtree::kdtree()
{
	root = new node(0, pointSet.size());
}

void kdtree::findMedian(int leftIndex, int rightIndex, int dimension_index)
{
	setDim = dimension_index;
	std::sort(pointSet.begin()+leftIndex, pointSet.begin()+rightIndex, cmp);
}

void kdtree::buildtree(int dimensions)
{
	Dimensions = dimensions;
	vector<double> rootMbrIntercepts(2*Dimensions, 0.0);
	for(int i=0; i<2*Dimensions; i++)
		rootMbrIntercepts[i] = pointSet[0][i/2];
	for(int i=0; i<pointSet.size(); i++)
	{
		vector<double> thisPoint = pointSet[i];
		for(int j=0; j<thisPoint.size(); j++)
		{
			rootMbrIntercepts[j*2] = rootMbrIntercepts[j*2]>thisPoint[j] ? thisPoint[j] : rootMbrIntercepts[j*2];
			rootMbrIntercepts[j*2+1] = rootMbrIntercepts[j*2+1]<thisPoint[j] ? thisPoint[j] : rootMbrIntercepts[j*2+1];
		}
	}

	root = new node(0, pointSet.size());
	root->mbrIntercepts = rootMbrIntercepts;
	root->dimension_index = 0;

	if(root->rightIndex - root->leftIndex == 1)
	{
		root->divider = pointSet[root->leftIndex];
		return; // Base Case. Think!
	}

	findMedian(0, pointSet.size(), 0);
	int median_index = (pointSet.size()-1)/2;
	//Binary Search
	int dividerIndexValue = pointSet[median_index][0];
	while(pointSet[median_index][0]==dividerIndexValue)
	{
		median_index--;
		if(median_index == -1) {
			median_index = 0;
			break;
		}
	}
	root->divider = pointSet[median_index];

	string code = "";
	if(median_index != 0)
	{
		root->left = new node(0, median_index);
		root->left->mbrIntercepts = rootMbrIntercepts;
		root->left->mbrIntercepts[1] = root->divider[0];
		root->left->dimension_index = 1;
		// _buildtree(root->left, code+string("L"));
		_buildtree(root->left);
	}
	if(median_index+1 != pointSet.size())
	{
		root->right = new node(median_index+1, pointSet.size());
		root->right->mbrIntercepts = rootMbrIntercepts;
		root->right->mbrIntercepts[0] = root->divider[0];
		root->right->dimension_index = 1;
		// _buildtree(root->right, code+string("R"));
		_buildtree(root->right);
	}
}

// void kdtree::_buildtree(node *head, string code)
void kdtree::_buildtree(node *head)
{
	if(head->rightIndex - head->leftIndex == 0)
	{
		head = NULL;
		return;
	}
	if(head->rightIndex - head->leftIndex == 1)
	{
		head->divider = pointSet[head->leftIndex];
		return;
	}
	findMedian(head->leftIndex, head->rightIndex, head->dimension_index);
	int median_index = (head->leftIndex + head->rightIndex-1)/2;
	//Binary Search
	int dividerIndexValue = pointSet[median_index][head->dimension_index];
	while(pointSet[median_index][head->dimension_index]==dividerIndexValue)
	{
		median_index--;
		if(median_index == -1) {
			median_index = 0;
			break;
		}
	}
	head->divider = pointSet[median_index];
	if(head->leftIndex != median_index)
	{
		head->left = new node(head->leftIndex, median_index);
		head->left->mbrIntercepts = head->mbrIntercepts;
		head->left->mbrIntercepts[2*head->dimension_index+1] = head->divider[head->dimension_index];
		head->left->dimension_index = (head->dimension_index + 1)%(Dimensions);
		// _buildtree(head->left, code+string("L"));
		_buildtree(head->left);
	}
	if(median_index+1!=head->rightIndex)
	{
		head->right = new node(median_index+1, head->rightIndex);
		head->right->mbrIntercepts = head->mbrIntercepts;
		head->right->mbrIntercepts[2*head->dimension_index] = head->divider[head->dimension_index];
		head->right->dimension_index = (head->dimension_index + 1)%(Dimensions);
		// _buildtree(head->right, code+string("R"));
		_buildtree(head->right);
	}
}

vector<double> kdtree::getMbr(node *head)
{
	return head->mbrIntercepts;
}

void kdtree::printTree(node *head, string code)
{
	cerr<<code<<endl;
	vector<double> thisPoint = head->divider;
	for(int i=0; i<thisPoint.size(); i++)
		cerr<<thisPoint[i]<<"--";
	cerr<<endl;
	if(head->left!=NULL)
		printTree(head->left, code+string("L"));
	if(head->right!=NULL)
		printTree(head->right, code+string("R"));
}

void kdtree::dummy()
{
	cerr<<"Works!"<<endl;
}

//k-NN algorithm using k-d tree
class MBR
{
public:
MBR(node* node1, double dist);
node* Node;
double distance;
};

MBR::MBR(node* node1, double dist){
	Node = node1;
	distance = dist;
}

//returns true if v2 is lexicographically smaller than v1 (in min dimension)
bool compareLexic(vector<double>& v1, vector<double>& v2){
	bool result = false;
	for (size_t i = 0; i < Dimensions; i++) {
		if(v1[i*2] > v2[i*2]) {
			result = true;
			break;
		}
		else if(v1[i*2] < v2[i*2])
			break;
	}
	return result;
}

struct CompCandidate {
	bool operator()(const MBR a, const MBR b)
	{
		return (a.distance != b.distance) ? (a.distance > b.distance) : (compareLexic(a.Node->mbrIntercepts,b.Node->mbrIntercepts)); //TODO: see if this function is accesible here
	}
};


class AnswerSet {
public:

vector<double>* point;
double distance;
AnswerSet(vector<double>* point1, double dist1){
point = point1;
distance = dist1;
}
};

// AnswerSet::AnswerSet(vector<double>& point1, double dist1){
//     point = point1;
//     distance = dist1;
// }

struct CompAnswer {
	bool operator()(const AnswerSet a, const AnswerSet b)
	{
		return a.distance < b.distance;
	}
};

// Max heap of size k
// Change as needed
class HeapK {

public:
int k_;    //size of heap
std::priority_queue<AnswerSet, vector<AnswerSet>, CompAnswer> q_;
//Constructor
HeapK(int k) : k_(k) {
}

int size(){
	return q_.size();
}

bool compareL(const vector<double>& v1, const vector<double>& v2){
	bool result = true;
	for(int i = 0; i < v1.size(); i++) {
		if(v1[i] < v2[i])
			break;
		if(v1[i] > v2[i]) {
			result = false;
			break;
		}
	}
	return result;
}

void insert(AnswerSet as) {
	if (q_.size() < k_) q_.push(as);
	else if (as.distance < q_.top().distance) { q_.pop(); q_.push(as); }
	else if(as.distance == q_.top().distance && (!compareL(*(q_.top().point), *(as.point)))) {q_.pop(); q_.push(as); }
}


std::vector<vector<double> > finalize() {
	std::vector<vector<double> > result(q_.size());
	while (q_.size()) {
		result[q_.size() - 1] = *(q_.top().point);
		q_.pop();
	}
	return result;
}
};

double kdtree::distMBR(const vector<double>& mbrIntercepts, const vector<double>& query){
	double dist = 0.0;
	// vector<double>& mbrIntercepts = mbr.Node->mbrIntercepts;
	for(int i = 0; i < query.size(); i++) {
		if(query[i] < mbrIntercepts[i*2])
			dist += (mbrIntercepts[i*2] - query[i])*(mbrIntercepts[i*2] - query[i]);
		else if(query[i] > mbrIntercepts[i*2+1])
			dist += (query[i] - mbrIntercepts[i*2+1])*(query[i] - mbrIntercepts[i*2+1]);
	}
	return dist;
}



double kdtree::dist(const vector<double>& v1, const vector<double>& v2){
	double dist = 0.0;
	for(int i = 0; i < v1.size(); i++) {
		dist += (v1[i]-v2[i])*(v1[i]-v2[i]);
	}
	return dist;
}

vector<vector<double> > kdtree::knn(vector<double>& query, int k)
{
	//Max heap
	HeapK answerSet(k);

	//Min heap
	priority_queue<MBR, vector<MBR>, CompCandidate> candidate;

	//query point is the function argument - query
	// queryPoint = query;

	//push root to min heap
	candidate.push(*(new MBR(root,0.0)));

	while(!candidate.empty()) {
		//pop top element from candidate
		MBR best = candidate.top();
		candidate.pop();
		//TODO: cache this top distance
		// if(answerSet.size() == k && distMBR(best.Node->mbrIntercepts,query) > dist(answerSet.q_.top().point, query))
		if(answerSet.size() == k && distMBR(best.Node->mbrIntercepts,query) > bestDist)
			break;
		// if(answerSet.size() < k || ( dist(best.Node->divider,query) < dist(answerSet.q_.top().point, query)) )
		if(answerSet.size() < k || ( dist(best.Node->divider,query) < bestDist) ){
			answerSet.insert(*(new AnswerSet(&best.Node->divider,dist(best.Node->divider,query))));
            bestDist = dist(*answerSet.q_.top().point, query);
        }
		if( ((best.Node->left != NULL) && answerSet.size() < k )|| ( (best.Node->left != NULL) && ( distMBR(best.Node->left->mbrIntercepts, query) < bestDist ) ) )
			candidate.push(*(new MBR(best.Node->left, distMBR(best.Node->left->mbrIntercepts, query))));
		if( ((best.Node->right != NULL) && answerSet.size() < k ) || ( (best.Node->right != NULL) && ( distMBR(best.Node->right->mbrIntercepts, query) < bestDist) ) )
			candidate.push(*(new MBR(best.Node->right, distMBR(best.Node->right->mbrIntercepts, query))));

	}

	return answerSet.finalize();
}

vector<vector<double> > kdtree::bruteForce(vector<vector<double> >& points, const vector<double>& query, int k){
	HeapK answers(k);
	for(int i = 0; i < points.size(); i++) {
		answers.insert(*(new AnswerSet(&points[i],dist(points[i],query))));
	}
	return answers.finalize();
}

int main(int argc, char const *argv[])
{
	if(argc != 2) {
		cerr<<"Usage : ./a.out <dataset_file>"<<endl;
		return 1;
	}

	kdtree *tree = new kdtree();
	string line;
	ifstream myfile (argv[1]);
	if (myfile.is_open())
	{
        getline (myfile,line);
        istringstream iss(line);
        // cerr << line << endl;
		int dim, N;
		iss >> dim >> N;
        // cerr << dim << " " << N << endl;
		// int ctr = 40;
		// while ( getline (myfile,line) && ctr>0)
		for(int i = 0; i < N; i++)
		{
            getline (myfile,line);
            vector<double> thisvec;
			istringstream iss( line );

			double elem;
			while( iss >> elem ) {
				thisvec.push_back(elem);
			}
			pointSet.push_back(thisvec);
			// ctr--;
		}
		myfile.close();
	}
	else cerr << "Unable to open file";

    // cerr<<pointSet.size()<<endl;

	//Testing code
	// pointSet.clear();
	// pointSet.resize(0);
	// vector<double> point1(2,0.0);
	// vector<double> point2(2,0.0);
	// point2[1] = 1.0;
	// vector<double> point3(2,0.0);
	// point3[0] = 1.0;
	// pointSet.push_back(point2);
	// pointSet.push_back(point3);

	//

	tree->buildtree(pointSet[0].size());
	// tree->printTree(tree->root, "r_");
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;

	// int k = 1;
	// vector<double>& query = pointSet[0];
	vector<vector<double> > queries;
	ifstream myfile2 (query_file);
	if (myfile2.is_open())
	{
        getline (myfile2,line);
		istringstream iss(line);
		int dim, N;
		iss >> dim >> N;
		for(int i = 0; i < N; i++)
		{
			vector<double> thisvec;
            getline (myfile2,line);
			istringstream iss( line );
			double elem;
			while( iss >> elem ) {
				thisvec.push_back(elem);
			}
			queries.push_back(thisvec);
		}
		myfile2.close();
	}
	else cerr << "Unable to open file";

    ofstream myfileOut ("results.txt");
    // double dist2 = 0.0;
    // double dist100 = 0.0;
	for(int i = 0; i < queries.size(); i++) {
		vector<double>& query = queries[i];
		vector<vector<double> > ans = tree->knn(query, k);
        // dist2 += tree->dist(ans[1], query);
        // dist100 += tree->dist(ans[99], query);
        for (size_t i = 0; i < ans.size(); i++) {
        	for (size_t j = 0; j < ans[i].size(); j++) {
				myfileOut << ans[i][j] << " ";
			}
			myfileOut << endl;
		}



		// cerr<<"sequential"<<endl;
		// vector<vector<double> > ans = tree->bruteForce(pointSet, query, k);
        //
        // for (size_t i = 0; i < ans.size(); i++) {
        //
        // 	for (size_t j = 0; j < ans[i].size(); j++) {
		// 		myfileOut << ans[i][j] << " ";
		// 	}
		// 	myfileOut << endl;
		// }
	}
    // cerr << sqrt(dist2)/sqrt(dist100) << endl;
    myfileOut.close();

	cout << 1 << endl;
	return 0;
}
