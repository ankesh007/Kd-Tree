#include <iostream>
#include <stdlib.h>
#include <vector>
#include <queue>
#include <ctime>
#include <cmath>
#include <fstream>
#include<bits/stdc++.h>

using namespace std;
using std::vector;

#define maxheap priority_queue <pair<double,vector<double> > , vector<pair<double, vector<double> > >, maxcomparedist>

struct maxcomparedist{
	bool operator()(const pair<double,vector<double> > &a ,const pair<double,vector<double> > &b){
		vector<double> va = a.second;
		vector<double> vb = b.second;
		if (a.first != b.first){
			return a.first < b.first;
		}
		for (int i = 0 ; i <va.size(); i++){
			if (va[i] != vb[i]){
				return va[i] < vb[i];
			}
		}
		return false;
	}
};

double L2distance(vector<double> &a , vector<double> &b){
	double ans = 0;
	for (int i = 0 ; i < a.size(); i++){
		ans += (a[i]-b[i])*(a[i]-b[i]);
	}
	return sqrt(ans);
}

int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];

	// [TODO] Construct kdTree using dataset_file here

	int number_points, dimension, knn;

	vector<vector<double> > input;
	ifstream infile;
	infile.open(dataset_file);

	infile >> dimension >> number_points;

	//cout<<" D : "<<dimension<<"  , N : "<<number_points<<endl;
	while(!infile.eof()){
		vector<double> point;
		for(int i=0;i<dimension;i++){
			double x;
			infile>>x;
			point.push_back(x);
		}
		input.push_back(point);
	}
	infile.close();


//	KD_Node* root = construct_tree(input, 0, input.size()-1, 0, input[0].size());

	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	//cerr << dataset_file << " " << query_file << " " << k << endl;

	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

	int qD,qK;

	vector<vector<double> > query;
	//ifstream queryfile;
	infile.open(query_file);
	infile >> qD >> qK;
	while(!infile.eof()){
		vector<double> point;
		for(int i=0;i<qD;i++){
			double x;
			infile>>x;
			point.push_back(x);
		}
		query.push_back(point);
	}

	infile.close();
	ofstream output;
	output.open("seq_results.txt");

	double l2d = 0.0;
	int queryL= query.size();
	int inputL=input.size();
	for(int m=0;m<qK;m++){
		maxheap answerSet;
		for(int j=0;j<inputL;j++){
			l2d = L2distance(query[m],input[j]);
			if(answerSet.size() < k){
				answerSet.push(make_pair(l2d,input[j]) );
			}
			else if(answerSet.size() == k){
				pair<double,vector<double> > answerSetTop = answerSet.top();
				if (answerSetTop.first >= l2d){
					answerSet.pop();
					answerSet.push(make_pair(l2d,input[j]));
				}
			}
		}
		vector<vector<double> > result;
		for (int i = 0 ; i < k; i++){
			vector<double> point = answerSet.top().second;
			result.push_back(point);
			/*
			for (int j = 0 ; j < point.size(); j++){
				cout << point[j] << " ";
			}
			*/
			//cout << answerSet.top().first << endl;
			answerSet.pop();		
		}

		//sort(result.begin(),result.end());
		int resL = result[0].size();
		int rS = result.size();
		for(int i=rS-1;i>=0;i--){
			for(int j=0;j<resL;j++){
				if(j < (resL-1)){
					output<<result[i][j]<<" ";
				}
				else{
					output<<result[i][j];
				}
			}
			if(i>0)
				output<<"\n";
		}
		if(m<qK-1)
			output<<"\n";

	}

	output.close();
	
	cout << 1 << endl;
}