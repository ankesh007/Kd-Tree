#include <iostream>
#include <stdlib.h>
#include <vector>
#include <queue>
#include <ctime>
#include <cmath>
#include <fstream>
#include<bits/stdc++.h>

using namespace std;
using std::vector;

#define maxheap priority_queue <pair<double,KD_Node*> , vector<pair<double, KD_Node*> >, maxcomparedist>
#define minheap priority_queue <pair<double,KD_Node*> , vector<pair<double, KD_Node*> >, mincomparedist>


int compare(vector<double> &a, vector<double> &b, int dim);
void swap(vector<vector<double> > &input, int a, int b);
int select(vector<vector<double> > &input, int l , int r, int mid, int dim);
int find_median_five(vector<vector<double> > &input, int l, int r, int dim);
int partition(vector<vector<double> > &input, int l, int r, int pivot, int dim);
int pivot(vector<vector<double> > &input, int l, int r, int dim);
void print(vector<vector<double> > &input);



struct KD_Node{
	vector<double> point;
	KD_Node *left;
	KD_Node *right;
	int dim;
};

int count = 0;

KD_Node* new_KD_Node(vector<double> p, int d){
	KD_Node *node = new KD_Node[sizeof(KD_Node)];
	node->left = NULL;
	node->right = NULL;
	node->point = p;
	node->dim = d;
	return node;
}

struct maxcomparedist{
	bool operator()(const pair<double,KD_Node*> &a ,const pair<double,KD_Node*> &b){
		vector<double> va = a.second->point;
		vector<double> vb = b.second->point;
		if (a.first != b.first){
			return a.first < b.first;
		}
		for (int i = 0 ; i <va.size(); i++){
			if (va[i] != vb[i]){
				return va[i] < vb[i];
			}
		}
		return false;
	}
};

struct mincomparedist{
	bool operator()(const pair<double,KD_Node*> &a ,const pair<double,KD_Node*> &b){
		return a.first > b.first;
	}
};


// TREE IMPLEMENTATION - MEDIAN OF MEDIANS

int compare(vector<double> &a, vector<double> &b, int dim){
	if (a[dim] == b[dim]){
		return 0;
	} else if (a[dim] < b[dim]){
		return -1;
	} else {
		return 1;
	}
}

void swap(vector<vector<double> > &input, int a, int b){
	vector<double> temp = input[a];
	input[a] = input[b];
	input[b] = temp;
}

int select(vector<vector<double> > &input, int l , int r, int mid, int dim){
	if (l == r){
		return l;
	}
	int pivotIndex = pivot(input, l, r, dim);
	pivotIndex = partition(input, l , r, pivotIndex, dim);

	if (mid == pivotIndex){
		return mid;
	} else if(mid < pivotIndex){
		return select(input, l, pivotIndex-1, mid, dim);
	} else {
		return select(input, pivotIndex+1, r,mid, dim);
	}
}

int partition(vector<vector<double> > &input, int l, int r, int pivot, int dim){
	swap(input,pivot, r);
	int storeIndex = l;
	for (int i = l ; i < r; i++){
		if (compare(input[i], input[r], dim) == -1){
			swap(input,storeIndex, i);
			storeIndex++;
		}
		
	}
	swap(input, r, storeIndex);
	return storeIndex;
}

int find_median_five(vector<vector<double> > &input, int l, int r, int dim){
	int temp = l+1;
	while (temp <= r){
		int i = temp;
		while(i > l && (compare(input[i], input[i-1], dim) == -1)){
			swap(input, i, i-1);
			i--;
		}
		temp++;
	}
	return (l+r)/2;
}

int pivot(vector<vector<double> > &input, int l, int r, int dim){
	if (r-l < 5){
		return find_median_five(input, l , r, dim);
	}
	for (int i = l; i <= r; i = i + 5){
		int subRight = i + 4;
		if (subRight > r){
			subRight = r;
		}
		int median_five = find_median_five(input, i, subRight, dim);
		swap(input, median_five, l + (i-l)/5);
	}
	return select(input, l, l + (r-l)/5, l + (r-l)/10, dim);
}

KD_Node* construct_tree(vector<vector<double> > &input, int l, int r, int dim, int highest_dim){
	//cout << l << " " << r << endl;
	if (l == r){
		KD_Node* root =  new_KD_Node(input[l],dim);
		return root;
	}
	if (l == r-1){
		KD_Node* root = new_KD_Node(input[l],dim);
		root->right = new_KD_Node(input[r],(dim+1)%highest_dim);
		return root;
	}
	int medianIndex = select(input, l , r, (l+r)/2, dim);
	//print(input);
	KD_Node* root = new_KD_Node(input[medianIndex], dim); 
	root->left = construct_tree(input, l, medianIndex-1, (dim+1)%highest_dim, highest_dim);
	root->right = construct_tree(input, medianIndex+1, r, (dim+1)%highest_dim, highest_dim);
	return root;
}


// KNN QUERY

double L2distance(KD_Node &a , KD_Node &b){
	double ans = 0;
	for (int i = 0 ; i < a.point.size(); i++){
		ans += (a.point[i]-b.point[i])*(a.point[i]-b.point[i]);
	}
	return sqrt(ans);
}

double MBRdistance(KD_Node &query_point, KD_Node &root_child, int dim, double rootvalue){
	if (query_point.point[dim] >= rootvalue && root_child.point[dim] >= rootvalue){
		return 0;
	}

	if (query_point.point[dim] < rootvalue && root_child.point[dim] < rootvalue){
		return 0;
	}
	return fabs(rootvalue - query_point.point[dim]);
}


void KNNQuery(KD_Node &query_point, minheap &candidateSet, maxheap &answerSet, int k, KD_Node* root){
	answerSet.push(make_pair(L2distance(query_point, *root), root));
	if (root->left != NULL){
		candidateSet.push(make_pair(MBRdistance(query_point,*(root->left),root->dim,root->point[root->dim]), root->left));
	}
	if (root->right != NULL){
		candidateSet.push(make_pair(MBRdistance(query_point,*(root->right),root->dim,root->point[root->dim]), root->right));
	}

	while (candidateSet.size() != 0){
		
		//cout << "answerSet size is "  << answerSet.size() << endl;
		pair<double,KD_Node*> candidatePair = candidateSet.top();
		KD_Node* candidateNode = candidatePair.second;
		candidateSet.pop();

		//cout << "point " << candidateNode->point[0]<< " " << candidateNode->point[1]<<  " " << candidateNode->point[2] << " " << candidatePair.first  <<endl;
		if (answerSet.size() < k){
			//cout << "direct adding " << endl;
			answerSet.push(make_pair(L2distance(query_point,*(candidateNode)),candidateNode));
			if (candidateNode->left != NULL){
				candidateSet.push(make_pair(MBRdistance(query_point,*(candidateNode->left),candidateNode->dim,candidateNode->point[candidateNode->dim]), candidateNode->left));
			}
			if (candidateNode->right != NULL){
				candidateSet.push(make_pair(MBRdistance(query_point,*(candidateNode->right),candidateNode->dim,candidateNode->point[candidateNode->dim]), candidateNode->right));
			}

		} else  if (answerSet.size() == k){
			//cout << "here 3" << endl;
			pair<double,KD_Node*> answerSetTop = answerSet.top();

			if (answerSetTop.first >= L2distance(query_point,*(candidateNode))){
				//cout << " removing " << endl;
				answerSet.pop();
				answerSet.push(make_pair(L2distance(query_point,*(candidateNode)),candidateNode));
			} /*else if (answerSetTop.first == L2distance(query_point,*(candidateNode)) && compare_lexicographic(*(candidateNode),*(answerSetTop.second)) == -1 ){
				answerSet.pop();
				answerSet.push(make_pair(L2distance(query_point,*(candidateNode)),candidateNode));
			}*/


			//cout << " keeping " << endl;
			double minDistance = answerSet.top().first;
			if (candidatePair.first > minDistance){
				continue;
			}
			if (candidateNode->left != NULL && MBRdistance(query_point,*(candidateNode->left),candidateNode->dim,candidateNode->point[candidateNode->dim]) < minDistance){
				candidateSet.push(make_pair(MBRdistance(query_point,*(candidateNode->left),candidateNode->dim,candidateNode->point[candidateNode->dim]), candidateNode->left));
			}
			if (candidateNode->right != NULL && MBRdistance(query_point,*(candidateNode->right),candidateNode->dim,candidateNode->point[candidateNode->dim]) < minDistance){
				candidateSet.push(make_pair(MBRdistance(query_point,*(candidateNode->right),candidateNode->dim,candidateNode->point[candidateNode->dim]), candidateNode->right));
			}
		}
		//cout << "here 1" << endl;
	}

}



int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];

	// [TODO] Construct kdTree using dataset_file here

	int number_points, dimension, knn;

	vector<vector<double> > input;
	ifstream infile;
	infile.open(dataset_file);

	infile >> dimension >> number_points;

	//cout<<" D : "<<dimension<<"  , N : "<<number_points<<endl;
	while(!infile.eof()){
		vector<double> point;
		for(int i=0;i<dimension;i++){
			double x;
			infile>>x;
			point.push_back(x);
		}
		input.push_back(point);
	}
	infile.close();


	KD_Node* root = construct_tree(input, 0, input.size()-1, 0, input[0].size());

	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	//cerr << dataset_file << " " << query_file << " " << k << endl;

	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

	int qD,qK;

	vector<vector<double> > query;
	//ifstream queryfile;
	infile.open(query_file);
	infile >> qD >> qK;
	while(!infile.eof()){
		vector<double> point;
		for(int i=0;i<qD;i++){
			double x;
			infile>>x;
			point.push_back(x);
		}
		query.push_back(point);
	}

	//clock_t et = clock();	

	infile.close();
	ofstream output;
	output.open("results.txt");
	for(int m=0;m<qK;m++)
	{
		minheap candidateSet;
		maxheap answerSet;
		KD_Node* query_point = new_KD_Node(query[m],0);

		KNNQuery(*(query_point), candidateSet, answerSet, k,root);

		vector<vector<double> > result;
		for (int i = 0 ; i < k; i++){
			vector<double> point = answerSet.top().second->point;
			result.push_back(point);
			/*
			for (int j = 0 ; j < point.size(); j++){
				cout << point[j] << " ";
			}
			*/
			//cout << answerSet.top().first << endl;
			answerSet.pop();		
		}

		//sort(result.begin(),result.end());
		int resL = result[0].size();
		int rS = result.size();
		for(int i=rS-1;i>=0;i--){
			for(int j=0;j<resL;j++){
				if(j < (resL-1)){
					output<<result[i][j]<<" ";
				}
				else{
					output<<result[i][j];
				}
			}
			if(i>0)
				output<<"\n";
		}
		if(m<qK-1)
			output<<"\n";

	}

	output.close();


	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;

}