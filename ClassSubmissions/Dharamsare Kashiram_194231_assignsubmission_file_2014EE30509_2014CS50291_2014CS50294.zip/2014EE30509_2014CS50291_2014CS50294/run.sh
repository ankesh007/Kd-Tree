g++ sample.cpp; 
./a.out $1