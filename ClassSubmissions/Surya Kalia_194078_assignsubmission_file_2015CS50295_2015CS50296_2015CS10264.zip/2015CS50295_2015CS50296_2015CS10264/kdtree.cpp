#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <queue>
#include <cstdint>
#include <limits>
#include <algorithm>
#include <bits/stdc++.h>
// #include<ctime>
#include <fstream>
using namespace std;


typedef vector<vector<double> > vvd;
// extern double findMedian(double arr[], int n);
int num_leaves;
int attr_to_sort;

bool sortFunc( const vector<double> &p1, const vector<double> &p2 )
{
    return p1[attr_to_sort] < p2[attr_to_sort];
}

class KdTree
{
    public:
        int attr;
        int d;
        vector<double> medianPoint;

        vvd dataPoints;
        KdTree *parent;
        KdTree *leftChild;
        KdTree *rightChild;
        bool isLeaf;
        double** mbr;
        void buildTree()
        {
            int n = dataPoints.size();
            if(n == 0)
            {
                cout<<"BT!!!!!!!"<<endl<<flush;
            }

            double data[n];

            for(int i = 0;i <d;i++)
            {
                mbr[i][0] = dataPoints[0][i];
                mbr[i][1] = dataPoints[0][i];
            }

            for (int i = 0;i < dataPoints.size();i++)
            {
                for (int j = 0;j < d;j++)
                {
                    if(dataPoints[i][j] > mbr[j][1])
                        mbr[j][1] = dataPoints[i][j];
                    if(dataPoints[i][j] < mbr[j][0])
                        mbr[j][0] = dataPoints[i][j];
                }
            }

            for (int i = 0;i < dataPoints.size();i++)
            {
                data[i] = dataPoints[i][attr];
                // cout <<data[i]<<endl;
            }
            if( n == 1)
            {
                // cout<<"ye leaf hai"<<endl;
                isLeaf = true;
                return;
            }

            vvd left,right;
            attr_to_sort = attr;
            sort(dataPoints.begin(), dataPoints.end(), sortFunc);
            // int siz = dataPoints.size();
            for(int i = 0;i < n;i++)
            {
                if(i < (n / 2))
                    left.push_back(dataPoints[i]);
                else
                    right.push_back(dataPoints[i]);
                                
            }
            medianPoint = dataPoints[n / 2]; 




            // median = findMedian(data , n);
            
            // if(mbr[attr][0] < median || mbr[attr][1]>median)
            // {
            //     for (int i = 0;i < dataPoints.size();i++)
            //     {
            //         if(dataPoints[i][attr] < median)
            //             left.push_back(dataPoints[i]);
            //         else 
            //             right.push_back(dataPoints[i]);
            //     }
            // }
            // else
            // {
            //     // cout<<"ye bhi leaf hai"<<endl;
            //     isLeaf = true;
            //     return;   
            // }
            // cout<<"Left size = "<< left.size()<<endl;
            // cout<<"Right size = "<< right.size()<<endl;
            leftChild = new KdTree((attr + 1) % d, d, this, left);
            rightChild = new KdTree((attr + 1) % d, d, this, right);
            dataPoints.clear();
            // (*leftChild).buildTree();
            // (*rightChild).buildTree();
        }        

        KdTree(int attr, int d, KdTree* parent, vvd dataPoints){
            // cout<<"Yoo1"<<endl;
            this->attr = attr;
            this->d = d;
            this->parent = parent;
            this->dataPoints = dataPoints;
            this->isLeaf = false;
            // cout<<"Data Size = "<<dataPoints.size()<<endl;
            // if(parent)
            //     cout<<"Parents size = "<<parent->dataPoints.size()<<endl;
            
            // cout<<"Yoo2"<<endl;
            mbr = new double*[d];
            for(int i = 0; i < d; ++i)
                mbr[i] = new double[2];
            buildTree();
        }

};

typedef pair<double, KdTree*> dk;
typedef pair<double, vector<double>* > dvd;


class maxComparator
{
public:
    int operator() (const dvd& p1, const dvd& p2)
    {
        if(p1.first != p2.first)
            return p1.first < p2.first;
        else
        {
            for(int i = 0; i < (*(p1.second)).size();i++)
            {    
                if((*(p1.second))[i] != (*(p2.second))[i] )
                    return (*(p1.second))[i] < (*(p2.second))[i];

            }
        }
        return 0;
    }
};

class minComparator
{
public:
    int operator() (const dk& p1, const dk& p2)
    {
        return p1.first > p2.first;
    }
};

priority_queue <dk, vector<dk>, minComparator> minHeap;
priority_queue <dvd, vector<dvd>, maxComparator> maxHeap;


double min_distance(double** mbr, int d, vector<double> *point );
double distance(vector<double> *p1, vector<double> *p2, int d);


double randomDouble()
{
    return static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
}

vvd generateRandomData(int n, int d)
{
    vvd ans;
    for(int i = 0;i < n;i++)
    {
        vector<double> vec(d);
        for (int j = 0;j < d;j++)
            vec[j] = randomDouble();
        ans.push_back(vec);
    }
    return ans;
}

void k_nearest_neigbours(int k, KdTree* tree, vector<double> &point )
{
    clock_t t0 = clock();

    minHeap = priority_queue <dk, vector<dk>, minComparator>();
    maxHeap = priority_queue <dvd, vector<dvd>, maxComparator>();

    // while(!maxHeap.empty())
    // {
    //     maxHeap.pop();
    // }
    // while(!minHeap.empty())
    // {
    //     minHeap.pop();
    // }
    
    // if(tree->dataPoints.size() < k)
    // {
    //     cout << "k is too big"<<endl;
    //     return;
    // }

    clock_t t1 = clock();


    for(int i = 0;i < k;i++)
    {
        dvd pmax;
        // pmax.first = distance(tree->dataPoints[i], point, tree->d);
        pmax.first = double(999);
        pmax.second = &(tree->dataPoints[i]);
        maxHeap.push(pmax);
    }

    clock_t t2 = clock();


    dk pmin;
    pmin.first = min_distance(tree->mbr, tree->d, &point);
    pmin.second = tree;
    minHeap.push(pmin);

    clock_t t3 = clock();

// || 
    int n_loops  = 0;
    while(!minHeap.empty() && minHeap.top().first < maxHeap.top().first )
    {
        // cout << "Going in while loop"<<endl;
        // cout<<"Min Heap top = "<< minHeap.top().first<<" Max heap top = "<<maxHeap.top().first<<endl;
        n_loops++;
        pmin = minHeap.top();
        minHeap.pop();
        if(pmin.second->isLeaf)
        {
            // cout<<"Going in is Leaf"<<endl;
            for(int i = 0; i < pmin.second->dataPoints.size();i++)
            {
                double dis = distance(&(pmin.second->dataPoints[i]), &point, tree->d);
                if(maxHeap.top().first >  dis)
                {
                    // cout<<"Going ib maxHeap.top"<<endl;
                    maxHeap.pop();
                    dvd toPush;
                    toPush.first = dis;
                    toPush.second = &(pmin.second->dataPoints[i]);
                    maxHeap.push(toPush);
                }
            }
            // minHeap.pop();
        }
        else
        {
            dk pleft, pright;
            double temp = min_distance(pmin.second->leftChild->mbr, tree->d, &point);
            if( temp < maxHeap.top().first )
            {
                pleft.first = temp;
                pleft.second = pmin.second->leftChild;
                minHeap.push(pleft);
            }
            temp = min_distance(pmin.second->rightChild->mbr, tree->d, &point);
            if( temp < maxHeap.top().first )
            {
                pright.first = temp;
                pright.second = pmin.second->rightChild;
                minHeap.push(pright);
            }
        }
    }
    // cout<<"No. of loops = "<< n_loops<<endl;

    clock_t t4 = clock();
    // cout<<"Heap Empty time "<<double(t1 - t0) / CLOCKS_PER_SEC<<endl;
    // cout<<"Max heap initialize "<<double(t2 - t1) / CLOCKS_PER_SEC<<endl;
    // cout<<"Min heap initialise"<<double(t3 - t2) / CLOCKS_PER_SEC<<endl;


    // cout<<"Size is "<<maxHeap.size()<<endl;

}

double min_distance(double** mbr, int d, vector<double> *point )
{
    double ans = 0;
    double dub;
    for(int i = 0;i < d;i++)
    {
        if((*point)[i] < mbr[i][0])
        {
            dub = (mbr[i][0] - (*point)[i]);
            ans += dub * dub;
            // ans += pow((mbr[i][0] - (*point)[i]), 2); 
        }
        else if((*point)[i] > mbr[i][1])
        {
            dub = (mbr[i][1] - (*point)[i]);
            ans += dub * dub;
        }
        
    }
    return ans;
}

double distance(vector<double>* p1, vector<double>* p2, int d)
{
        double ans = 0;
        for(int i = 0;i < d;i++)
        {
            double dub = ( (*p1)[i] - (*p2)[i]); 
            ans += dub * dub;
        }
        return ans;
}

vvd readData(const char* filename)
{
    ifstream myfile;
    myfile.open(filename);
    // myfile << (dataPoints[i][j]) << " ";
    int d, n1;
    myfile >> d >>n1;
    
    vvd ans;
    for(int i = 0; i < n1;i++)
    {
        vector<double> vec;
        for(int j = 0; j < d;j++)
        {
            double doub;
            myfile >> doub;
            vec.push_back(doub);
        }
        ans.push_back(vec);
    }
    return ans;
}

void writeData(vvd dataPoints, const char* filename)
{
    ofstream myfile;
    myfile.open(filename);
    int n = dataPoints.size();
    int d = dataPoints[0].size();

    // myfile << "Writing this to a file.\n";
    // vvd dataPoints = generateRandomData(n, d);
    myfile << d<<" "<<n<<endl;
    for(int i = 0; i < n;i++)
    {
        for(int j = 0; j < d;j++)
        {
            myfile << (dataPoints[i][j]) << " ";
        }
        myfile << endl;
    }
    myfile.close();
    
}

void writeResults(vvd dataPoints, const char* filename)
{
    ofstream myfile;
    myfile.open (filename);
    int n = dataPoints.size();
    int d = dataPoints[0].size();

    // myfile << "Writing this to a file.\n";
    // vvd dataPoints = generateRandomData(n, d);
    myfile << d<<" "<<n<<endl;
    for(int i = 0; i < n;i++)
    {
        for(int j = 0; j < d;j++)
        {
            myfile << (dataPoints[i][j]) << " ";
        }
        myfile << endl;
    }
    myfile.close();
    
}


int main(int argc, char* argv[])
{
    srand(time(0));

    // int d0  = 20;
    // int n0 = 100;
    // cout<<"Generating Random Data"<<endl<<flush;
    // vvd dataPoints0 = generateRandomData(n0, d0);
    // string filename0 = "query_20b.txt";

    // writeData(dataPoints0, filename0.c_str());

    // return 0;

    vvd dataPoints = readData(argv[1]);
    int n = dataPoints.size();
    int d = dataPoints[0].size();
    // cout<<n<<" "<<d<<" "<<endl;
    // cout<<"Generated Random Data"<<endl<<flush;
    KdTree *tree = new KdTree(0, d, 0, dataPoints);
    cout<<"0"<<endl;

    string query_file;
    int k;
    cin>>query_file>>k;
    

    // cout<<"K  = "<<k<<endl;
    vvd points;
    // points = generateRandomData(100, 2);

    // string filename = "query_2.txt";

    // writeData(points, filename.c_str());
    points = readData(query_file.c_str());
    // cout<<"Points size = "<<points.size()<<endl;
    int num_queries = points.size();
    // cout<<"Num queries  == "<<num_queries<<endl;
    // int k = 100;
    ofstream myfile;
    myfile.open ("results.txt");
    clock_t begin=clock();

    vector<dvd> answer;
    for(int i=0;i<num_queries;i++)
    {
        k_nearest_neigbours(k, tree, points[i]);

        for(int j = 0;j < k;j++)
        {
            dvd topEle = maxHeap.top();
            maxHeap.pop();
            answer.push_back(topEle);
            
        }
        for (int j = k-1 ; j >=0; j --)
        {
            for(int x1 = 0;x1 < (*(answer[j].second)).size();x1++)
            {
                myfile<<(*(answer[j].second))[x1]<<" ";
            }
            myfile<<endl;
        }
        
        
    }
    clock_t end=clock();
    myfile.close();
    cout<<"1"<<endl;
    
    // cout<<"K nearest neighbours found "<<endl;

    // cout<<"time:"<<double(end-begin)/CLOCKS_PER_SEC<<endl;
}