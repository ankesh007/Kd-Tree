#!/bin/bash

./kdtree $1
