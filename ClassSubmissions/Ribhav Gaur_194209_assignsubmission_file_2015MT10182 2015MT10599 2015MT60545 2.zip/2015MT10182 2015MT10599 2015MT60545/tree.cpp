

#include <iostream>
#include <vector>
#include <cmath>
#include <vector>

using namespace std;

class Kd_Node{
public:
    int level;
    Kd_Node* left;
    Kd_Node* right;
    vector<pair<double,double> > grid;
    vector<double> point;
    bool is_Leaf=false;
    bool exist=true;
//    Kd_Node(vector<pair<double,double> >, int , vector<double>);
    Kd_Node(vector<pair<double,double> > a, int b, vector<double> c)
    {
        point = c;
        grid = a;
        level=b;
        
    }
    
};

class knn_grid{
public:
    Kd_Node* node_pointer;
    double distance_from_grid;
//    knn_grid(Kd_Node* , double);
    knn_grid(Kd_Node* p, double c)
    {
        node_pointer=p;
        distance_from_grid=c;
    }
    
    
};

class max_node{
public:
    vector<double>* point;
    double distance_from_query;
//    max_node(vector<double>, double);
    max_node(vector<double>& a, double b)
    {
        point = &a;
        distance_from_query=b;
        
    }
    
    
};



//Kd_Node::Kd_Node(vector<pair<double,double> > a, int b, vector<double> c)
//{
//    point = c;
//    grid = a;
//    level=b;
//
//}

//knn_grid::knn_grid(Kd_Node* p, double c)
//{
//    node_pointer=p;
//    distance_from_grid=c;
//
//}

//max_node::max_node(vector<double> a, double b)
//{
//    point = a;
//    distance_from_query=b;
//
//}




