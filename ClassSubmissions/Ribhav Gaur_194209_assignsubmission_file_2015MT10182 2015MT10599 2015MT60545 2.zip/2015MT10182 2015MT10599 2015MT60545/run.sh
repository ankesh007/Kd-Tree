#!/bin/bash
g++ final_submit_copy.cpp -Ofast -std=c++11 -g
./a.out $1
