#include <iostream>
#include <vector>
#include <cmath>
#include <vector>
using namespace std;

class Kd_Node{
    public:
        int level;
        Kd_Node* left;
        Kd_Node* right;
        vector<pair<double,double> > grid;
        vector<double> point;
        bool is_Leaf=false;
        bool exist=true;
        Kd_Node(vector<pair<double,double> >, int , vector<double>);
};

class knn_grid{
    public:
        Kd_Node* node_pointer;
        double distance_from_grid;
        knn_grid(Kd_Node* , double);
        
        
};

class max_node{
    public:
        vector<double> point;
        double distance_from_query;
        max_node(vector<double>, double);
        
        
};