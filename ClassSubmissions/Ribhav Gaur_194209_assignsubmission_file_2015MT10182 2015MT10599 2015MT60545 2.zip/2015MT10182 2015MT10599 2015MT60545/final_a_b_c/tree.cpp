

#include <iostream>
#include <vector>
#include <cmath>
#include <vector>
#include "tree.hpp"
using namespace std;


Kd_Node::Kd_Node(vector<pair<double,double> > a, int b, vector<double> c)
{
    point = c;
    grid = a;
    level=b;
    
}

knn_grid::knn_grid(Kd_Node* p, double c)
{
    node_pointer=p;
    distance_from_grid=c;
    
}

max_node::max_node(vector<double> a, double b)
{
    point = a;
    distance_from_query=b;
    
}




