#include <iostream>
#include "tree.hpp"
#include <queue>
#include <ctime>
#include <cmath>
#include <vector>
#include <random>
#include <fstream>
#include <iostream>
#include <queue>
#include <math.h>
#include <ctime>
#include <cmath>
#include <vector>
#include <random>
#include <fstream>
#include<stdio.h>
#include <stdlib.h>
#include <sstream>
#include <regex>

vector<vector<double> > get_data(int dimension,int number_of_points){
    default_random_engine generator;
    uniform_real_distribution<double> distribution(0.0,1.0);
    vector<vector<double> > v;
    ofstream myfile;
    double number;
    myfile.open("dataset_file.txt");
    myfile <<dimension<<" "<<number_of_points<<"\n";
    for(int i=1;i<=number_of_points;i++){
        vector<double> v1;
        for(int j=1;j<=dimension;j++){
            number = distribution(generator);
            myfile <<number<<" ";
            v1.push_back(number);
        }
        // cout<<v1.size()<<endl;
        v.push_back(v1);
        myfile <<"\n";
    }
    myfile.close();
    return v;
}


struct comparator_max {
 bool operator()(double i, double j) {
 return i < j;
 }
};

double distance_from_point (vector<double> a, vector<double> b)
{
    double distance = 0;
    for(int i = 0; i<a.size();i++)
    {
        distance = distance + ((a[i]-b[i])*(a[i]-b[i]));
    }
    return distance;
}

int main(int argc, const char * argv[]) {
    ios_base::sync_with_stdio(false);
cin.tie(NULL);
    int d=20,number_of_points;
     number_of_points=100000;
    // insert code here...
    //cout << "Hello, World!\n";
    vector<vector<double> > data=get_data(d,number_of_points);
    double total_time=0;
    string line;
 vector<vector<double> > v1;
  ifstream myfile1 ("20.txt");
  if (myfile1.is_open())
  {
      
    while ( getline (myfile1,line) )
    {
      //cout << line << '\n';
      string rgx_str=" ";
      regex rgx (rgx_str);
      vector<double> v2;
      sregex_token_iterator iter(line.begin(), line.end(), rgx, -1);
      sregex_token_iterator end;

      while (iter != end)  {
          //std::cout << "S43:" << *iter << std::endl;
        //   elems.push_back(*iter);
        string temp=*iter;
        
          v2.push_back(atof(temp.c_str()));
          //cout<<"we inserretd " <<atof(temp.c_str());
          ++iter;
      }
      v1.push_back(v2);
    }
    myfile1.close();
  }
 
 else 
 cout << "Unable to open file";

 int k = 20;
    for(int y=0; y<v1.size(); y++)
    {
        clock_t begin=clock();
        vector<double> query_point=v1[y];
        priority_queue<double, vector<double>, comparator_max> maxHeap;
        for(int i = 0;i<data.size();i++)
        {
            double distance = distance_from_point(data[i],v1[y]);
            if(maxHeap.size()<k)
            {
                maxHeap.push(distance);
            }
            else
            {
                
                if(maxHeap.top()>distance)
                {
                    maxHeap.pop();
                    maxHeap.push(distance);
                }
            }
        }
        clock_t end=clock();
        double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
        total_time=total_time+elapsed_secs;
        // for(int l = 0; l<maxHeap.size();l++)
        // {
        // cout << maxHeap.top() << endl;
        // maxHeap.pop();
        // }
        // cout << endl;
        // cout << endl;

    }
    total_time = total_time/100;
    cout << total_time << endl;
    
}