#include <iostream>
#include "tree.hpp"
#include <queue>
#include <ctime>
#include <cmath>
#include <vector>
#include <random>
#include <fstream>
#include <iostream>
//#include "tree.hpp"
#include <queue>
#include <math.h>
#include <ctime>
#include <cmath>
#include <vector>
#include <random>
#include <fstream>
#include<stdio.h>
#include <stdlib.h>
#include <sstream>
#include <regex>
using namespace std;
int number_of_leaves=0;

struct comparator_min {
 bool operator()(knn_grid& i, knn_grid& j) {
 return i.distance_from_grid > j.distance_from_grid;
 }
};

struct comparator_max {
 bool operator()(max_node& i, max_node& j) {
 return i.distance_from_query < j.distance_from_query;
 }
};

double distance_from_point (vector<double> a, vector<double> b)
{
    double distance = 0;
    for(int i = 0; i<a.size();i++)
    {
        distance = distance + ((a[i]-b[i])*(a[i]-b[i]));
    }
    return distance;
}

double grid_distance(vector<double> query, vector<pair<double,double> > grid)
{
    double distance = 0;
    for (int i = 0; i<query.size();i++)
    {
        double d = 0;
        if(query[i]<grid[i].first)
        {
            d = (grid[i].first - query[i]);
        }
        else if (query[i]>grid[i].second)
        {
            d = (query[i]-grid[i].second);
        }
        distance = distance + d*d;
    }
    return distance;
}

void bulk_load(vector<vector<double> >& data, Kd_Node& parent, vector<vector<pair<double,int> > >& parent_sorted, int d)
{
    //cout<<"length is " << parent_sorted[0].size() << endl;
    //cout<<" parent level is " << parent.level;
    
    if(parent_sorted[0].size()==0)
    {
        parent.is_Leaf=true;
        parent.exist=false;
        //number_of_leaves++;
        return;
    }
    if(parent_sorted[0].size()==1)
    {
        pair<double, int> b= parent_sorted[0][0];
        parent.point=data[b.second];
        //cout<<" made the point " << data[b.second][(parent.level)%d] << " the point and level is " <<parent.level<<  endl;
        number_of_leaves++;
        parent.is_Leaf=true;
        return;
        
    }
    int level = (parent.level)%d;
    int middle=(parent_sorted[0].size())/2;
    //cout <<"The middle is "<< middle << "The level is " << parent.level << endl;
    pair<double, int> a=parent_sorted[level][middle];
    
    double median=a.first;
    //cout<<"median is " << median;
    int id=a.second;
    parent.point=data[id];
    //number_of_leaves++;
    //cout << "Made the point ";
    // for(int itr = 0;itr < d;itr++)
    // {
    //    // cout << data[id][itr] << " ";
    // }
    //cout << endl;
    vector<vector<pair<double,int> > > left_sorted;
    vector<vector<pair<double,int> > > right_sorted;
    for(int m = 0; m < d ; m++){
        vector<pair<double,int> > e;
        left_sorted.push_back(e);
        right_sorted.push_back(e);
    }

    for(int i=0; i<d; i++)
    {

        if(i!=level)
        {
            for(int k=0; k<parent_sorted[i].size(); k++)
            {
                pair<double,int> b=parent_sorted[i][k];
                if((data[b.second][level]<=median)&&(b.second!=id))
                {
                    left_sorted[i].push_back(b);
                }
                else if (data[b.second][level]>median)
                {
                    right_sorted[i].push_back(b);
                }
                else
                {
                    continue;
                }
                

            }
        }
        else
        {
            for(int g=0; g<parent_sorted[i].size(); g++)
            { 
                pair <double,int> p=parent_sorted[i][g];  // can be made better
                if((p.first<=median)&&(p.second!=id))
                {
                    left_sorted[i].push_back(p);
                }
                else if (p.first>median)
                {
                    right_sorted[i].push_back(p);
                }
                else
                {
                    continue;
                }
            }
        }
    }

      vector<pair<double,double> > grid_left;
      vector<pair<double,double> > grid_right;
    int k=0;
    for(k=0; k<d;k++)
    {
        pair<double, double> temp1=parent.grid[k];
       if(k==level)
       {
           pair<double,double> left;
           pair<double,double> right;
           left.first=temp1.first;
           left.second=median;
           right.first=median;
           right.second=temp1.second;
           grid_left.push_back(left);
           grid_right.push_back(right);
       }
       else
       {
           //pair<double, double> temp1=parent.grid[k];
           grid_left.push_back(temp1);
           grid_right.push_back(temp1);
           

       }
    }
    //cout << "level" << parent.level + 1 << endl;
int new_level = parent.level + 1;    
Kd_Node* Left_Node = new Kd_Node(grid_left,new_level,data[0] );
Kd_Node* Right_Node = new Kd_Node(grid_right,new_level,data[0]);
//cout<<" the new node has the level " << ;
parent.left = Left_Node;
parent.right = Right_Node;
bulk_load(data,*Left_Node, left_sorted, d );
bulk_load(data,*Right_Node, right_sorted, d);
return;

}


vector<vector<double> > get_data(int dimension,int number_of_points){
    default_random_engine generator;
    uniform_real_distribution<double> distribution(0.0,1.0);
    vector<vector<double> > v;
    ofstream myfile;
    double number;
    myfile.open("dataset_file.txt");
    myfile <<dimension<<" "<<number_of_points<<"\n";
    for(int i=1;i<=number_of_points;i++){
        vector<double> v1;
        for(int j=1;j<=dimension;j++){
            number = distribution(generator);
            myfile <<number<<" ";
            v1.push_back(number);
        }
        // cout<<v1.size()<<endl;
        v.push_back(v1);
        myfile <<"\n";
    }
    myfile.close();
    return v;
}






int main(int argc, const char * argv[]) {
    ios_base::sync_with_stdio(false);
cin.tie(NULL);
    int d=2,number_of_points;
     number_of_points=100000;
    // insert code here...
    //cout << "Hello, World!\n";
    vector<vector<double> > data=get_data(d,number_of_points);
    //cout<< " madedata"; 

    //cout<<" contents are " << data[0][0];

   // cout <<" psuhed";
    
    
    
    // for(int i=0; i<data.size(); i++)
    // {
    //     cout << data[i][1] << endl;


    // }
    
    
    vector<vector<pair<double, int> > > sorted_data;
    
    int k=0;
    for(int m = 0; m < d ; m++){
        vector<pair<double,int> > aa;
        sorted_data.push_back(aa);
        //out<< " pushing";
    }
   // cout<<" hello";
    for(k=0; k<data.size(); k++)
    {
        for(int m=0; m<d; m++)
        {
            pair <double,int> a;
            a.first=data[k][m];
            a.second=k;
            sorted_data[m].push_back(a);
           // cout <<"hello";
            //cout<<sorted_data[m].size();
            
        }
    }

    k=0;
    for(k=0; k<d; k++)
    {
        sort(sorted_data[k].begin(),sorted_data[k].end());
        //number_of_leaves++;
        //cout<<"sorted";
    }
    vector<pair<double,double> > grid;
    k=0;
    for(k=0; k<d;k ++)
    {
        pair <double, double> a;
        a.first=sorted_data[k][0].first;
        a.second=sorted_data[k][data.size()-1].first;
        grid.push_back(a);
    }
   Kd_Node* root = new Kd_Node(grid,0,data[0]);
   //cout<< " made level " << root->level;
    //cout <<" lenght is" <<sorted_data[0].size();
    bulk_load(data,*root,sorted_data,d);
    cout <<"0";
    cout <<"\n";
    //cout<<number_of_leaves;
   // cout <<endl;
    //string query_file_path;
    //int k_value_knn;
    //cin>>query_file_path>>k_value_knn; 

//    for(int l=0; l<d; l++)
//    {
//        sort(sorted_data[l].begin(),sorted_data[l].end());
//        for(int q=0; q<sorted_data[l].size(); q++)
//        {
//            cout << sorted_data[l][q].first << "," << sorted_data[l][q].second  << endl;
//        }
//        cout <<"\n";
//    }

double total_time=0;
double average_ratio=0;
 string line;
 vector<vector<double> > v1;
  ifstream myfile1 ("2.txt");
  if (myfile1.is_open())
  {
      
    while ( getline (myfile1,line) )
    {
      //cout << line << '\n';
      string rgx_str=" ";
      regex rgx (rgx_str);
      vector<double> v2;
      sregex_token_iterator iter(line.begin(), line.end(), rgx, -1);
      sregex_token_iterator end;

      while (iter != end)  {
          //std::cout << "S43:" << *iter << std::endl;
        //   elems.push_back(*iter);
        string temp=*iter;
        
          v2.push_back(atof(temp.c_str()));
          //cout<<"we inserretd " <<atof(temp.c_str());
          ++iter;
      }
      v1.push_back(v2);
    }
    myfile1.close();
  }

  else cout << "Unable to open file";
  

for(int y=0; y<v1.size(); y++)
{
    // string line;
	// ifstream infile;
	// infile.open ("query_file.txt");

        // while(!infile.eof) // To get you all the lines.
        // {
        //     vector<double > result;
	    //     getline(infile,line); // Saves the line in STRING.
        //     string delimiter =" ";

        //     stringstream ss(line);
        //     double num1;
        //     while (getline(ss, num1, delimiter)) {
        //         result.push_back(num1);
        //     }
        //     complete_vector.push_back(result);
        // }
        
	// infile.close();
    // default_random_engine generator;
    // uniform_real_distribution<double> distribution(0.0,1.0);
    vector<double> query_point=v1[y];
    // for(int i=1;i<=d;i++){
    //     double num = distribution(generator);
    //     query_point.push_back(num);
    // }
  
    // query_point.push_back(6.27);
    // query_point.push_back(3.55);

    knn_grid* root_grid=new knn_grid(root,grid_distance(query_point,root->grid));
    // knn_grid* node2=new knn_grid(root,11.21);

    // cout<< node->node_pointer->left->level <<"miracle";


    priority_queue<knn_grid, vector<knn_grid>, comparator_min> minHeap;
    if(root->is_Leaf==false)
     minHeap.push(*root_grid);
     else
     return 0;

     
    // minHeap.push(*node2);
    // cout << " pope " << minHeap.top().distance_from_grid;
    // minHeap.pop();
    // cout << " pope " << minHeap.top().distance_from_grid;

    priority_queue<max_node, vector<max_node>, comparator_max> maxHeap;
    //max_node* abc=new max_node(data[0], 12.3);
    //max_node* def=new max_node(data[0], 12.6);
    //maxHeap.push(*abc);
    //maxHeap.push(*def);
     //cout << " pope " << maxHeap.top().distance_from_query;
     //maxHeap.pop();
    
    k=20;
    clock_t begin=clock();
    while(true)
    {
        Kd_Node* temp=minHeap.top().node_pointer;
        if(minHeap.size()==0)
            break;
         
        if(maxHeap.size()<k)
        {    //cout<< " came";
            max_node* abc=new max_node(temp->point, distance_from_point(query_point,temp->point));
            maxHeap.push(*abc);
            minHeap.pop();
             
            if((temp->left->exist)&&(temp->left->is_Leaf))
            {
                double dis=distance_from_point(query_point,temp->left->point);
                if(maxHeap.size()<k)
                {
                    max_node* leaf_insert=new max_node(temp->left->point,dis);
                    maxHeap.push(*leaf_insert);
                }
                else
                {
                    if(maxHeap.top().distance_from_query>dis)
                    {
                    maxHeap.pop();
                    max_node* leaf_insert=new max_node(temp->left->point,dis);
                    maxHeap.push(*leaf_insert);
                    }
                }
            }
            else
            { 
                if(temp->left->exist)
                { 
                    knn_grid* temp2=new knn_grid(temp->left, grid_distance(query_point,temp->left->grid));
                    minHeap.push(*temp2);
                }
            }

            if((temp->right->exist)&&(temp->right->is_Leaf))
            {
                double dis=distance_from_point(query_point,temp->right->point);
                if(maxHeap.size()<k)
                {
                    max_node* leaf_insert=new max_node(temp->right->point,dis);
                    maxHeap.push(*leaf_insert);
                }
                else
                {
                    if(maxHeap.top().distance_from_query>dis)
                    { 
                    maxHeap.pop();
                    max_node* leaf_insert=new max_node(temp->right->point,dis);
                    maxHeap.push(*leaf_insert);
                    }
                }
            }
            else
            {
                if(temp->right->exist)
                {
                    knn_grid* temp2=new knn_grid(temp->right, grid_distance(query_point,temp->right->grid));
                    minHeap.push(*temp2);
                }
            }
        }

        else 
        {
            //Why equal?
            if(minHeap.top().distance_from_grid >=maxHeap.top().distance_from_query)
            {
                break;
            }
            else
            {
                double di=distance_from_point(query_point,temp->point);
                max_node* abc=new max_node(temp->point, di);
                if(di<(maxHeap.top().distance_from_query))
                {
                    maxHeap.pop();
                    maxHeap.push(*abc);
                }
                minHeap.pop();
                if((temp->left->exist)&&(temp->left->is_Leaf))
                {
                    double dis=distance_from_point(query_point,temp->left->point);
                    if(maxHeap.size()<k)
                    {
                        max_node* leaf_insert=new max_node(temp->left->point,dis);
                        maxHeap.push(*leaf_insert);
                    }
                    else
                    {
                        if(maxHeap.top().distance_from_query>dis)
                        { 
                            maxHeap.pop();
                            max_node* leaf_insert=new max_node(temp->left->point,dis);
                            maxHeap.push(*leaf_insert);
                        }
                    }
                }
                else
                { 
                    if(temp->left->exist)
                    { 
                        knn_grid* temp2=new knn_grid(temp->left, grid_distance(query_point,temp->left->grid));
                        minHeap.push(*temp2);
                    }
                }

                if((temp->right->exist)&&(temp->right->is_Leaf))
                {
                    double dis=distance_from_point(query_point,temp->right->point);
                    if(maxHeap.size()<k)
                    {
                        max_node* leaf_insert=new max_node(temp->right->point,dis);
                        maxHeap.push(*leaf_insert);
                    }
                    else
                    {
                        if(maxHeap.top().distance_from_query>dis)
                        { 
                            maxHeap.pop();
                            max_node* leaf_insert=new max_node(temp->right->point,dis);
                            maxHeap.push(*leaf_insert);
                        }
                    }   
                }
                else
                {
                    if(temp->right->exist)
                    {
                        knn_grid* temp2=new knn_grid(temp->right, grid_distance(query_point,temp->right->grid));
                        minHeap.push(*temp2);
                    }
                }
            } 
        }
    }
     
    clock_t end=clock();
    double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
    if(k==100)
    {
        double distance1=maxHeap.top().distance_from_query;
        for(int u=1; u<=98; u++)
        {
            maxHeap.pop();
        }
        double distance2=maxHeap.top().distance_from_query;
        double ratio=distance2/distance1;
        ratio=sqrt(ratio);
        average_ratio=average_ratio+ratio;
    }
    
    
    //cout<<elapsed_secs;
    
    total_time=total_time+elapsed_secs;
}
//cout <<total_time;
cout <<"average time taken is " <<total_time/100; 
if(k==100)
cout << " the ratio is " <<average_ratio/100;
    // cout<< " the fourth nearest point has x coordinate" << maxHeap.top().point[0] <<"and distance is" << maxHeap.top().distance_from_query;
    // maxHeap.pop();
    // cout <<"\n";
    // cout<< " the  third nearest point has x coordinate" << maxHeap.top().point[0] << "and distance is " << maxHeap.top().distance_from_query;
    // maxHeap.pop();
    // cout <<"\n";
    // cout<< " the  second nearest point has x coordinate" << maxHeap.top().point[0] << "and distance is " << maxHeap.top().distance_from_query;
    // maxHeap.pop();
    // cout <<"\n";
    // cout<< " the  nearest point has x coordinate" << maxHeap.top().point[0] << "and distance is " << maxHeap.top().distance_from_query;
return 0;
}
