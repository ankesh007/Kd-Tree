//#include <iostream>
//#include "tree.hpp"
#include <iostream>
#include "tree.cpp"
#include <queue>
#include <math.h>
#include <ctime>
#include <cmath>
#include <cstring>
#include <vector>
#include <random>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <regex>
#include <cmath>
// #include <bits/stdc++.h>
using namespace std;
int number_of_leaves=0;
int distance_time=0;
int d;
int number_of_points;
double precision=0.000000001;
bool lexigo(vector<double> v1, vector<double> v2) //true if v1 is before
{   int d=v1.size();
    for(int i=0; i<d; i++)
    {
        if(v1[i]<v2[i])
            return 1;
        
        if(v1[i]>v2[i])
            return 0;
        
    }
    return 1;
}

struct comparator_min {
    bool operator()(knn_grid& i, knn_grid& j) {
        return i.distance_from_grid > j.distance_from_grid;
    }
};

struct comparator_max {
    bool operator()(max_node& i, max_node& j) {
        if(i.distance_from_query < j.distance_from_query)
            return true;
        else if(i.distance_from_query > j.distance_from_query)
            return false;
        else
        {
            return (lexigo(*(i.point),*(j.point)));
            
        }
    }
};

double distance_from_point (vector<double> a, vector<double> b)
{
    //clock_t begin=clock();
    double distance = 0;
    for(int i = 0; i<a.size();i++)
    {
        distance = distance + ((a[i]-b[i])*(a[i]-b[i]));
    }
    return distance;
    //clock_t end=clock();
    //double elapsed_secs=double(end-begin)/CLOCKS_PER_SEC;
    //distance_time=distance_time+elapsed_secs;
}

double grid_distance(vector<double> query, vector<pair<double,double> > grid)
{
    double distance = 0;
    //clock_t begin=clock();
    for (int i = 0; i<query.size();i++)
    {
        
        if(query[i]<grid[i].first)
        {
            distance = distance +  (grid[i].first - query[i])* (grid[i].first - query[i]);
        }
        else if (query[i]>grid[i].second)
        {
            distance = distance + (query[i]-grid[i].second)*(query[i]-grid[i].second);
        }
    }
    //clock_t end=clock();
    //double elapsed_secs=double(end-begin)/CLOCKS_PER_SEC;
    //distance_time=distance_time+elapsed_secs;
    return distance;
}

void bulk_load(vector<vector<double> >& data, Kd_Node& parent, vector<vector<pair<double,int> > >& parent_sorted, int d)
{
    //cout<<"length is " << parent_sorted[0].size() << endl;
    //cout<<" parent level is " << parent.level;
    
    if(parent_sorted[0].size()==0)
    {
        parent.is_Leaf=true;
        parent.exist=false;
        //number_of_leaves++;
        return;
    }
    if(parent_sorted[0].size()==1)
    {
        pair<double, int> b= parent_sorted[0][0];
        parent.point=data[b.second];
        //cout<<parent.level<<endl;
        //cout<<" made the point " << data[b.second][(parent.level)%d] << " the point and level is " <<parent.level<<  endl;
        number_of_leaves++;
        // cout<<number_of_leaves;
        parent.is_Leaf=true;
        return;
        
    }
    int level = (parent.level)%d;
    int middle=(parent_sorted[0].size())/2;
    //cout <<"The middle is "<< middle << "The level is " << parent.level << endl;
    pair<double, int> a=parent_sorted[level][middle];
    
    double median=a.first;
    //cout<<"median is " << median;
    int id=a.second;
    parent.point=data[id];
    number_of_leaves++;
    //cout << "Made the point ";
    // for(int itr = 0;itr < d;itr++)
    // {
    //    // cout << data[id][itr] << " ";
    // }
    //cout << endl;
    vector<vector<pair<double,int> > > left_sorted;
    vector<vector<pair<double,int> > > right_sorted;
    for(int m = 0; m < d ; m++){
        vector<pair<double,int> > e;
        left_sorted.push_back(e);
        right_sorted.push_back(e);
    }
    
    for(int i=0; i<d; i++)
    {
        
        if(i!=level)
        {
            for(int k=0; k<parent_sorted[i].size(); k++)
            {
                pair<double,int> b=parent_sorted[i][k];
                if((data[b.second][level]<=median)&&(b.second!=id))
                {
                    left_sorted[i].push_back(b);
                }
                else if (data[b.second][level]>median)
                {
                    right_sorted[i].push_back(b);
                }
                else
                {
                    continue;
                }
                
                
            }
        }
        else
        {
            for(int g=0; g<parent_sorted[i].size(); g++)
            {
                pair <double,int> p=parent_sorted[i][g];  // can be made better
                if((p.first<=median)&&(p.second!=id))
                {
                    left_sorted[i].push_back(p);
                }
                else if (p.first>median)
                {
                    right_sorted[i].push_back(p);
                }
                else
                {
                    continue;
                }
            }
        }
    }
    
    vector<pair<double,double> > grid_left;
    vector<pair<double,double> > grid_right;
    int k=0;
    for(k=0; k<d;k++)
    {
        pair<double, double> temp1=parent.grid[k];
        if(k==level)
        {
            pair<double,double> left;
            pair<double,double> right;
            left.first=temp1.first;
            left.second=median;
            right.first=median;
            right.second=temp1.second;
            grid_left.push_back(left);
            grid_right.push_back(right);
        }
        else
        {
            //pair<double, double> temp1=parent.grid[k];
            grid_left.push_back(temp1);
            grid_right.push_back(temp1);
            /// double min_left = left_sorted[k][0].first;
            // double max_left = left_sorted[k][0].first;
            // for(int w = 0;w<left_sorted[k].size();w++)
            // {
            //     if(left_sorted[k][w].first<min_left)
            //     {
            //         min_left = left_sorted[k][w].first;
            //     }
            //     if(left_sorted[k][w].first>max_left)
            //     {
            //         max_left = left_sorted[k][w].first;
            //     }
            //     pair<double,double> left;
            //     left.first = min_left;
            //     left.second = max_left;
            //     grid_left.push_back(left);
            // }
            // double min_right = right_sorted[k][0].first;
            // double max_right = right_sorted[k][0].first;
            //  for(int x = 0;x<right_sorted[k].size();x++)
            // {
            //     if(right_sorted[k][x].first<min_right)
            //     {
            //         min_right = right_sorted[k][x].first;
            //     }
            //     if(right_sorted[k][x].first>max_right)
            //     {
            //         max_right = right_sorted[k][x].first;
            //     }
            //     pair<double,double> right;
            //     right.first = min_right;
            //     right.second = max_right;
            //     grid_right.push_back(right);
            // }
            
            
        }
    }
    //cout << "level" << parent.level + 1 << endl;
    int new_level = parent.level + 1;
    Kd_Node* Left_Node = new Kd_Node(grid_left,new_level,data[0] );
    Kd_Node* Right_Node = new Kd_Node(grid_right,new_level,data[0]);
    //cout<<" the new node has the level " << ;
    parent.left = Left_Node;
    parent.right = Right_Node;
    bulk_load(data,*Left_Node, left_sorted, d );
    bulk_load(data,*Right_Node, right_sorted, d);
    return;
    
}

vector<vector<double> > get_data(string filename){
    vector<vector<double> > v;
    
    
    string s =filename;
    
    
    
    int n = s.length();
    
    
    char dataset_file[n+1];
    
    
    strcpy(dataset_file, s.c_str());
    
    
    
    ifstream myfile(filename);
    string line;
    stringstream ss;
    getline(myfile,line);
    ss.str(line);
    ss >> d;
    ss >> number_of_points;
    //cout << d << " " << number_of_points << endl;
    
    double a;
    for(int i=0;i<number_of_points; i++)
    {
        vector<double> temp_vect;
        getline(myfile,line);
        stringstream ss1;
        ss1.str(line);
        // cout << line << endl;
        for(int j=1; j<=d; j++)
        {
            ss1 >> a ;
            temp_vect.push_back(a);
            // cout << a;
        }
        v.push_back(temp_vect);
        //cout<<i<< endl;
    }
    myfile.close();
    return v;
}




int main(int argc, char* argv[]) {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    string filename(argv[1]);
    int knn;
    vector<vector<double> > data=get_data(filename);
    vector<vector<pair<double, int> > > sorted_data;
    
    int k=0;
    for(int m = 0; m < d ; m++){
        vector<pair<double,int> > aa;
        sorted_data.push_back(aa);
        //out<< " pushing";
    }
    // cout<<" hello";
    for(k=0; k<data.size(); k++)
    {
        for(int m=0; m<d; m++)
        {
            pair <double,int> a;
            a.first=data[k][m];
            a.second=k;
            sorted_data[m].push_back(a);
            
            
        }
    }
    
    k=0;
    for(k=0; k<d; k++)
    {
        sort(sorted_data[k].begin(),sorted_data[k].end());
        //number_of_leaves++;
        //cout<<"sorted";
    }
    vector<pair<double,double> > grid;
    k=0;
    for(k=0; k<d;k ++)
    {
        pair <double, double> a;
        a.first=sorted_data[k][0].first;
        a.second=sorted_data[k][data.size()-1].first;
        grid.push_back(a);
    }
    Kd_Node* root = new Kd_Node(grid,0,data[0]);
    
    bulk_load(data,*root,sorted_data,d);
    cout<<"0"<<endl;
    //cout<< number_of_leaves;
    
    // vector<double> query_point;
    
    char filename11[1000];
    string query_filename;
    //cout << "Enter" << endl;
    std::cin.clear();
    cin >> query_filename >> knn;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    //cin >> knn;
    //cin.ignore(numeric_limits<streamsize>::max(), '\n');
    
    double total_time=0;
    double average_ratio=0;
    string line;
    vector<vector<double> > v1;
    //   ifstream myfile1 (query_filename);
    //   if (myfile1.is_open())
    //   {
    //     getline(myfile1,line);
    //     while ( getline (myfile1,line) )
    //     {
    //       //cout << line << '\n';
    //       string rgx_str=" ";
    //       regex rgx (rgx_str);
    //       vector<double> v2;
    //       sregex_token_iterator iter(line.begin(), line.end(), rgx, -1);
    //       sregex_token_iterator end;
    
    //       while (iter != end)  {
    //           //std::cout << "S43:" << *iter << std::endl;
    //         //   elems.push_back(*iter);
    //         string temp=*iter;
    //         //cout<<"appending"<<atof(temp.c_str())<<"done"<<endl;
    
    //           v2.push_back(atof(temp.c_str()));
    //           //cout<<"we inserretd " <<atof(temp.c_str());
    //           ++iter;
    //       }
    //       v1.push_back(v2);
    //     }
    //     myfile1.close();
    //   }
    
    //   else cout << "Unable to open file";
    
    int num_query;
    
    ifstream myfile(query_filename);
    string line2;
    stringstream ss;
    getline(myfile,line2);
    ss.str(line2);
    ss >> d;
    ss >> num_query;
    //cout << d << " " << number_of_points << endl;
    
    double a;
    for(int i=0;i<num_query; i++)
    {
        vector<double> temp_vect;
        getline(myfile,line2);
        stringstream ss1;
        ss1.str(line2);
        // cout << line << endl;
        for(int j=1; j<=d; j++)
        {
            ss1 >> a ;
            temp_vect.push_back(a);
            // cout << a;
        }
        v1.push_back(temp_vect);
        //cout<<i<< endl;
    }
    myfile.close();
    
    
    
    ofstream myfile2;
    myfile2.open ("results.txt");
    for(int y=0; y<v1.size(); y++){
        
        vector<double> query_point=v1[y];
        knn_grid* root_grid=new knn_grid(root,grid_distance(query_point,root->grid));
        
        
        priority_queue<knn_grid, vector<knn_grid>, comparator_min> minHeap;
        if(root->is_Leaf==false)
            minHeap.push(*root_grid);
        else
            return 0;
        
        
        
        
        priority_queue<max_node, vector<max_node>, comparator_max> maxHeap;
        
        
        k=knn;
        //clock_t begin=clock();
        // int iterations=0;
        
        //clock_t begin2=clock();
        while(true)
        {
            // iterations++;
            if(minHeap.size()==0)
                break;
            Kd_Node* temp=minHeap.top().node_pointer;
            
            
            if(maxHeap.size()<k)
            {
                
                max_node* abc=new max_node(temp->point, distance_from_point(query_point,temp->point));
                maxHeap.push(*abc);
                //cout<<"pushed the " <<abc->point[0]<<"," <<abc->point[1];
                minHeap.pop();
                
                if((temp->left->exist)&&(temp->left->is_Leaf))
                {
                    double dis=distance_from_point(query_point,temp->left->point);
                    if(maxHeap.size()<k)
                    {
                        max_node* leaf_insert=new max_node(temp->left->point,dis);
                        maxHeap.push(*leaf_insert);
                    }
                    else
                    {
                        if(maxHeap.top().distance_from_query>dis)
                        {
                            //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<< endl;
                            maxHeap.pop();
                            
                            max_node* leaf_insert=new max_node(temp->left->point,dis);
                            maxHeap.push(*leaf_insert);
                        }
                        else{
                            if(abs(maxHeap.top().distance_from_query-dis)<precision)
                            {
                                if(!lexigo(*(maxHeap.top().point),temp->left->point))
                                {   //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<< endl;
                                    maxHeap.pop();
                                    max_node* leaf_insert=new max_node(temp->left->point,dis);
                                    maxHeap.push(*leaf_insert);
                                    
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(temp->left->exist)
                    {
                        if(maxHeap.size()<k)
                        {
                            knn_grid* temp2=new knn_grid(temp->left, grid_distance(query_point,temp->left->grid));
                            minHeap.push(*temp2);
                        }
                        else
                        {
                            double dis=grid_distance(query_point,temp->left->grid);
                            if(dis<=maxHeap.top().distance_from_query)
                            {
                                knn_grid* temp2=new knn_grid(temp->left, dis);
                                minHeap.push(*temp2);
                            }
                        }
                    }
                }
                
                if((temp->right->exist)&&(temp->right->is_Leaf))
                {
                    double dis=distance_from_point(query_point,temp->right->point);
                    if(maxHeap.size()<k)
                    {
                        max_node* leaf_insert=new max_node(temp->right->point,dis);
                        maxHeap.push(*leaf_insert);
                    }
                    else
                    {
                        if(maxHeap.top().distance_from_query>dis)
                        {   //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<< endl;
                            maxHeap.pop();
                            max_node* leaf_insert=new max_node(temp->right->point,dis);
                            maxHeap.push(*leaf_insert);
                        }
                        else{
                            if(abs(maxHeap.top().distance_from_query-dis)<precision)
                            {
                                if(!lexigo(*(maxHeap.top().point),temp->right->point))
                                {   //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<< endl;
                                    maxHeap.pop();
                                    max_node* leaf_insert=new max_node(temp->right->point,dis);
                                    maxHeap.push(*leaf_insert);
                                    
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(temp->right->exist)
                    {
                        if(maxHeap.size()<k)
                        { knn_grid* temp2=new knn_grid(temp->right, grid_distance(query_point,temp->right->grid));
                            minHeap.push(*temp2);
                        }
                        
                        else
                        {
                            double dis=grid_distance(query_point,temp->right->grid);
                            if(dis<=maxHeap.top().distance_from_query)
                            {
                                knn_grid* temp2=new knn_grid(temp->right, dis);
                                minHeap.push(*temp2);
                            }
                        }
                    }
                }
            }
            
            else
            {
                //Why equal?
                if(minHeap.top().distance_from_grid >maxHeap.top().distance_from_query)
                {
                    break;
                }
                else
                {
                    double di=distance_from_point(query_point,temp->point);
                    max_node* abc=new max_node(temp->point, di);
                    // bool flag=true;
                    minHeap.pop();
                    if(di<(maxHeap.top().distance_from_query))
                    {  //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<< endl;
                        maxHeap.pop();
                        maxHeap.push(*abc);
                    }
                    else{
                        if(abs(di-(maxHeap.top().distance_from_query))<precision)
                        {
                            if(!lexigo(*(maxHeap.top().point),temp->point))
                            {  //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<< endl;
                                maxHeap.pop();
                                max_node* leaf_insert=new max_node(temp->point,di);
                                maxHeap.push(*leaf_insert);
                                
                            }
                        }
                    }
                    
                    if((temp->left->exist)&&(temp->left->is_Leaf))
                    {
                        double dis=distance_from_point(query_point,temp->left->point);
                        // if(maxHeap.size()<k)
                        // {
                        //     max_node* leaf_insert=new max_node(temp->left->point,dis);
                        //     maxHeap.push(*leaf_insert);
                        // }
                        
                        
                        if(maxHeap.top().distance_from_query>dis)
                        {   //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<< endl;
                            maxHeap.pop();
                            max_node* leaf_insert=new max_node(temp->left->point,dis);
                            maxHeap.push(*leaf_insert);
                            
                        }
                        else{
                            if(abs(maxHeap.top().distance_from_query-dis)<precision)
                            {
                                if(!lexigo(*(maxHeap.top().point),temp->left->point))
                                {  //cout<<"i am popping" <<maxHeap.top().point[0]<<"," <<maxHeap.top().point[1]<<"to push " << endl;
                                    //cout<<"Size of heap is " <<maxHeap.size();
                                    ///cout<<"head of heap is "<<maxHeap.top().point[0] <<"," <<maxHeap.top().point[1];
                                    maxHeap.pop();
                                    //cout<<"Size of heap is " <<maxHeap.size();
                                    //cout<<"head of heap is "<<maxHeap.top().point[0] <<"," <<maxHeap.top().point[1];
                                    max_node* leaf_insert=new max_node(temp->left->point,dis);
                                    maxHeap.push(*leaf_insert);
                                    //cout<<"bla inserted point";
                                    //cout<<leaf_insert->point[0]<<","<<leaf_insert->point[1];
                                    
                                }
                            }
                        }
                        
                        
                    }
                    else
                    {
                        if(temp->left->exist)
                        {
                            // if(maxHeap.size()<k)
                            // { knn_grid* temp2=new knn_grid(temp->left, grid_distance(query_point,temp->left->grid));
                            // minHeap.push(*temp2);
                            // }
                            
                            
                            double dis=grid_distance(query_point,temp->left->grid);
                            if(dis<=maxHeap.top().distance_from_query)
                            {
                                knn_grid* temp2=new knn_grid(temp->left, dis);
                                minHeap.push(*temp2);
                            }
                            
                        }
                    }
                    
                    if((temp->right->exist)&&(temp->right->is_Leaf))
                    {
                        double dis=distance_from_point(query_point,temp->right->point);
                        // if(maxHeap.size()<k)
                        // {
                        //     max_node* leaf_insert=new max_node(temp->right->point,dis);
                        //     maxHeap.push(*leaf_insert);
                        // }
                        
                        
                        if(maxHeap.top().distance_from_query>dis)
                        {
                            maxHeap.pop();
                            max_node* leaf_insert=new max_node(temp->right->point,dis);
                            maxHeap.push(*leaf_insert);
                        }
                        else{
                            if(abs(maxHeap.top().distance_from_query-dis)<precision)
                            {
                                if(!lexigo(*(maxHeap.top().point),temp->right->point))
                                {
                                    maxHeap.pop();
                                    max_node* leaf_insert=new max_node(temp->right->point,dis);
                                    maxHeap.push(*leaf_insert);
                                    
                                }
                            }
                        }
                        
                        
                    }
                    else
                    {
                        if(temp->right->exist)
                        {
                            // knn_grid* temp2=new knn_grid(temp->right, grid_distance(query_point,temp->right->grid));
                            // minHeap.push(*temp2);
                            double dis=grid_distance(query_point,temp->right->grid);
                            if(dis<=maxHeap.top().distance_from_query)
                            {
                                knn_grid* temp2=new knn_grid(temp->right, dis);
                                minHeap.push(*temp2);
                            }
                        }
                    }
                }
            }
        }
        
        //clock_t end=clock();
        // cout<< "Num Iterations" << iterations << endl;
        //double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
       // total_time=total_time+elapsed_secs;
        //cout<<"time taken is "<< elapsed_secs;
        
        //cout<<endl;
        
        
        
        // ofstream myfile2;
        // myfile2.open ("results.txt");
        vector<double> result_vec[knn];
        int cnt=knn-1;
        while(maxHeap.size()>0){
            result_vec[cnt]=*(maxHeap.top().point);
            maxHeap.pop();
            cnt--;
        }
        for(int i=0;i<knn;i++){
            for(int j=0;j<d;j++){
                myfile2 << result_vec[i][j] <<" ";
            }
            if(y!=v1.size()-1 || i!=knn-1){
                myfile2<<"\n";
            }
        }
    }
    myfile2.close();
    
    
    
    //cout<<total_time/100<<endl;
    cout<<1;
    cout<<endl;
    return 0;
}

