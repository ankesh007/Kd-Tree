#include <iostream>
#include <stdlib.h>
#include <fstream>
#include "vector"
#include "algorithm"
#include "string"
#include <iomanip>
#include <limits>
using namespace std;

FILE* outFile;


struct tree{
	vector<float> data;
	vector<float> lower_bound;
	vector<float> upper_bound;
	// vector<vector<float>> points;
	tree* left;
	tree* right;
	int level;
	int leaf;
};

std::vector<int> sort_indices(std::vector<float> &points){
	vector<pair <float,int> > a;
	vector<int> res;
	for(int i=0;i<points.size();i++){
		a.emplace_back(make_pair(points[i],i));
	}
	sort(a.begin(),a.end());
	for(int i=0;i<points.size();i++){
		res.emplace_back(a[i].second);
	}
	return res;
}


float calc_dist(vector<float> &p1,vector<float> &p2){
	int n = p1.size();
	float res = 0;
	for(int i=0;i<n;i++){
		res += pow(p1[i]-p2[i],2);
	}
	res = pow(res,0.5);
	return res;
}

float mbr_dist(tree* kdTree,vector<float> &p1){
	int n = p1.size();
	float res = 0;
	vector<float> d1 = kdTree->lower_bound;
	vector<float> d2 = kdTree->upper_bound;
	for(int i=0;i<n;i++){
		if(p1[i]<min(d1[i],d2[i]))
			res += pow(min(d1[i],d2[i])-p1[i],2);
		else if(p1[i]>max(d1[i],d2[i]))
			res+= pow(p1[i]-max(d1[i],d2[i]),2);
	}
	res = pow(res,0.5);
	return res;
}

tree* make_tree(tree* kdTree , int level , int d,vector<vector<float>> &points){
	level = level % d;
	kdTree->leaf = 0;
	int n = points.size();
	if(n == 0){
		kdTree->leaf = 2;
		return kdTree;
	}
	if(n == 1){
		kdTree->leaf = 1;
		kdTree->data = points[0];
		return kdTree;
	}
	vector<vector<float> > left_points,right_points;
	vector<vector<int> > left_pbd,right_pbd;
	vector<float> dm;
	for(int j=0;j<n;j++){
		dm.emplace_back(points[j][level]);
	}
	vector<int> dummy = sort_indices(dm);
	vector<int> l,r;
	kdTree->left = new tree();
	kdTree->right = new tree();
	for(int i=0;i<n/2;i++){
		l.emplace_back(dummy[i]);
	}
	for(int i=n/2+1;i<n;i++){ 
		r.emplace_back(dummy[i]);
	}
	kdTree->data = points[dummy[n/2]];
	for(int i=0;i<l.size();i++){
		left_points.emplace_back(points[l[i]]);
	}
	for(int i=0;i<r.size();i++){
		right_points.emplace_back(points[r[i]]);
	}
	kdTree->left->level = (level+1) % d;
	kdTree->left->lower_bound = kdTree->lower_bound;
	kdTree->left->upper_bound = kdTree->upper_bound;
	kdTree->left->upper_bound[level] = kdTree->data[level];
	
	kdTree->right->lower_bound = kdTree->lower_bound;
	kdTree->right->upper_bound = kdTree->upper_bound;
	kdTree->right->lower_bound[level] = kdTree->data[level];
	
	if(left_points.size()>1){
		kdTree->left = make_tree(kdTree->left,level+1,d,left_points);
	}
	else{
		kdTree->left->leaf = 1;
		if(left_points.size() == 1)
			kdTree->left->data = left_points[0];
		else kdTree->left->leaf = 2;
	}
	kdTree->right->level = (level+1)%d;
	if(right_points.size()>1){
		kdTree->right = make_tree(kdTree->right,level+1,d,right_points);
	}
	else{
		kdTree->right->leaf = 1;
		if(right_points.size() == 1)
			kdTree->right->data = right_points[0];
		else kdTree->right->leaf = 2;
	}
	return kdTree;
}

struct compare_to:public std::binary_function<pair<float,vector<float>>,pair<float,vector<float>>,bool>{
	bool operator()(const pair<float,vector<float>> &p1,const pair<float,vector<float>> &p2){
		if(p1.first<p2.first)	return true;
		if(p1.first>p2.first)	return false;
		for(int i=0;i<p1.second.size();i++){
			if(p1.second[i]<p2.second[i])
				return true;
			if(p1.second[i]>p2.second[i])
				return false;
		}
		return true;
	}
};

struct greater_than{
	bool operator()(pair<float,tree* > &p1,pair<float,tree* > &p2){
		return (p1.first > p2.first);
	}
};

void knn_query(vector<float> &query,int k, tree* kdTree, int d){
	vector<pair<float ,vector<float> > > res;
	vector<pair<float ,tree* > > candidate;
	candidate.emplace_back(make_pair(0,kdTree));
	while(!candidate.empty()){
		pair<float,tree* > dummy = candidate.front();
		pop_heap(candidate.begin(),candidate.end(),greater_than());
		candidate.pop_back();
		if(dummy.second->leaf == 2)	continue;
		if(res.size()<k){
			res.emplace_back(make_pair(calc_dist(dummy.second->data,query),dummy.second->data));
			push_heap(res.begin(),res.end());
			if(dummy.second->leaf == 1)	continue;
			if(dummy.second->left->leaf != 2){
				candidate.emplace_back(make_pair(mbr_dist(dummy.second->left,query),dummy.second->left));
				push_heap(candidate.begin(),candidate.end(),greater_than());
			}
			if(dummy.second->right->leaf != 2){
				candidate.emplace_back(make_pair(mbr_dist(dummy.second->right,query),dummy.second->right));
				push_heap(candidate.begin(),candidate.end(),greater_than());
			}
		}
		else{
			float dist = calc_dist(dummy.second->data,query);
			if(dist<res.front().first){
				res.emplace_back(make_pair(dist,dummy.second->data));
				push_heap(res.begin(),res.end());
				pop_heap(res.begin(),res.end());
				res.pop_back();
			}
			if(dummy.second->leaf == 1)	continue;
			float dist2 = res.front().first;
			if(dummy.second->left->leaf != 2){
				dist = mbr_dist(dummy.second->left,query);
				if(dist<dist2){
					candidate.emplace_back(make_pair(dist,dummy.second->left));
					push_heap(candidate.begin(),candidate.end(),greater_than());
				}
			}
			if(dummy.second->right->leaf != 2){
				dist = mbr_dist(dummy.second->right,query);
				if(dist<dist2){
					candidate.emplace_back(make_pair(dist,dummy.second->right));
					push_heap(candidate.begin(),candidate.end(),greater_than());
				}
			}//if(candidate.front().first > dist2 )	break;
		}
	}
	
	sort(res.begin(),res.end(),compare_to());
	for(int j=0;j<k;j++){
		for(int l=0;l<d;l++){
			fprintf(outFile, "%f ", res[j].second[l]);
		}
		fprintf(outFile, "\n");
	}
	return ;
}



int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];
	
	ifstream inFile;
	inFile.open(dataset_file);
	if(!inFile){
		cerr << "Unable to open file";
		cout << 1 << endl;
		exit(1);
	}
	int d,n;
	inFile >> d >> n;

	vector<vector<float>> pts;
	for(int i=0;i<n;i++){
		float dummy;
		vector<float> v;
		for(int j=0;j<d;j++){
			inFile >> dummy;
			v.emplace_back(dummy);
		}
		pts.emplace_back(v);
	}
	inFile.close();
	tree* kdTree = new tree();
	kdTree->level = 0;
	// kdTree->points = pts;
	vector<float> infi,neg_infi;
	for(int i=0;i<d;i++){
		infi.emplace_back(numeric_limits<float>::infinity());
		neg_infi.emplace_back(-1*numeric_limits<float>::infinity());
	}
	kdTree->lower_bound = neg_infi;
	kdTree->upper_bound = infi;
	kdTree = make_tree(kdTree,0,d,pts);
	// [TODO] Construct kdTree using dataset_file here

	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	outFile= fopen("results.txt", "w");
	ifstream qfile;
	qfile.open(query_file);
	if(!qfile){
		cerr << "Unable to open query_file";
		cout << 1 << endl;
		exit(1);
	}
	int x,n2;
	qfile >> x >> n2;
	for(int i=0;i<n2;i++){
		float dummy;
		vector<float> query;
		for(int j=0;j<x;j++){
			qfile >> dummy;
			query.emplace_back(dummy);
		}
		vector<pair<float ,tree* > > candidate;
		vector<pair<float,vector<float> > > res;
		candidate.emplace_back(make_pair(0,kdTree));
		make_heap(candidate.begin(),candidate.end(),greater_than());
		make_heap(res.begin(),res.end());
		knn_query(query,k,kdTree,x);
		
	}
	fclose(outFile);
	qfile.close();
	// cerr << dataset_file << " " << query_file << " " << k << endl;

	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt

	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
}