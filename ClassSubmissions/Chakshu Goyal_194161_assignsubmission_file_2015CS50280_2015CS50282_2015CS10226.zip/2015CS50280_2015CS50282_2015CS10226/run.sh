#!/bin/bash
g++ -std=c++11 -O3 sample_heap.cpp ; ./a.out $1