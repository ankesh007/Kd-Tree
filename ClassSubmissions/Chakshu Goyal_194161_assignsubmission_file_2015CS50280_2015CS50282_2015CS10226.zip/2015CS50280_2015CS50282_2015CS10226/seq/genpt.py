import random
#2,3,5,10,15,20

D = 100
N = 100

print( D )#, "" , N)

for i in range(N):
	for j in range(D):
		print(random.uniform(0 , 1) , end = " ")
	print()