#include <iostream>
#include <stdlib.h>
#include <fstream>
#include "vector"
#include "algorithm"
#include "string"
#include <iomanip>
#include <queue>
#include "math.h"
using namespace std;

float calc_dist(vector<float> &p1,vector<float> &p2){
	int n = p1.size();
	float res = 0;
	for(int i=0;i<n;i++){
		res += pow(p1[i]-p2[i],2);
	}
	res = pow(res,0.5);
	return res;
}

vector<pair<float,int>> find_distance(vector<float> &query_point,vector<vector<float>> &all_points){
	int n = all_points.size();
	vector<pair<float,int>> res;
	for(int i=0;i<n;i++){
		res.emplace_back(pair<float,int> (calc_dist(query_point,all_points[i]),i));
	}
	return res;
}

vector<pair<float,vector<float>>> query(vector<float> &query_point, vector<vector<float>> &all_points, int k)
{

	priority_queue<pair<float , vector<float>>> result;

	for(int i=0;i<k;i++)
		result.push(make_pair(calc_dist(query_point,all_points[i]) , all_points[i]));

	//make_heap(result.begin(),result.end());
	
	for(int i=k ; i<all_points.size() ; i++)
	{
		float dist = calc_dist(query_point,all_points[i]);
		if(result.top().first > dist)
		{
			result.pop();
			result.push(make_pair(dist,all_points[i]));
		}
	}

	std::vector<pair<float , vector<float>>> v;
	while (!result.empty())
	{
	    v.push_back(result.top());
	    result.pop();
	}
	return v;
}

struct compare_to:public std::binary_function<pair<float,vector<float>>,pair<float,vector<float>>,bool>{
	bool operator()(const pair<float,vector<float>> &p1,const pair<float,vector<float>> &p2){
		if(p1.first<p2.first)	return true;
		if(p1.first>p2.first)	return false;
		for(int i=0;i<p1.second.size();i++){
			if(p1.second[i]<p2.second[i])
				return true;
			if(p1.second[i]>p2.second[i])
				return false;
		}
		return true;
	}
};

int main(int argc, char* argv[])
{
	char* dataset_file = argv[1];
	
	ifstream inFile;
	inFile.open(dataset_file);
	if(!inFile){
		cerr << "Unable to open dataset_file";
		cout << 1 << endl;
		exit(1);
	}
	int d,n;
	inFile >> d >> n;

	vector<vector<float>> pts;
	for(int i=0 ; i<n ; i++)
	{
		float dummy;
		vector<float> v;
		for(int j=0;j<d;j++){
			inFile >> dummy;
			v.emplace_back(dummy);
		}
		pts.emplace_back(v);
	}
	inFile.close();
	
	cout << 0 << endl;

	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	ifstream qfile;
	qfile.open(query_file);
	if(!qfile){
		cerr << "Unable to open query_file";
		cout << 1 << endl;
		exit(1);
	}
	
	int x,n2;
	qfile >> x >> n2;
	//cout<<n2<<endl;
	FILE* outFile;
	outFile= fopen("results.txt", "w");
	vector<float> q_pts;
	for(int i=0;i<n2;i++)
	{
		float dummy;
		vector<float> v;
		for(int j=0;j<x;j++){
			qfile >> dummy;
			v.emplace_back(dummy);
		}
		
		vector<pair<float,std::vector<float>>> res = query(v , pts , k);
		
		sort(res.begin(),res.end(),compare_to());
		for(int j=0;j<k;j++){
			for(int m=0;m<d;m++){
				fprintf(outFile, "%f ", res[j].second[m]);
				//outFile << setprecision(6)<< res[j].second[m] << " ";
			}
			fprintf(outFile, "\n");
		}
	}

	fclose(outFile);
	cout << 1 << endl;
}