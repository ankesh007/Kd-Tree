#!/bin/bash
g++ -w -std=c++11 -Ofast competition.cpp
./a.out $1