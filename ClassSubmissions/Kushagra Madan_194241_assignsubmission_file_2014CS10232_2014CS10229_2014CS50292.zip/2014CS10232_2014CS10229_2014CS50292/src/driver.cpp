#include <iostream>
#include <stdlib.h>
#include <fstream>
#include "kdtree.h"
using namespace std;

int main(int argc, char* argv[]) {

	char* dataset_file = argv[1];
	vector<vector<float> > points;
	ifstream data;
	data.open(dataset_file);
	assert(data);
	
	int num, dim;
	data >> dim >> num;

	for(int i = 0 ; i<num ; i++){
		vector<float> nextp(dim, -1.0);
		for(int j = 0; j<dim ; j++) data >> nextp[j];
		points.push_back(nextp);
	}
	data.close();
	kdtree * mytree = new kdtree(dim, points);
	// mytree->print();

	// Request name/path of query_file from parent by just sending "0" on stdout
	cout << 0 << endl;
	// Wait till the parent responds with name/path of query_file and k | Timer will start now
	char* query_file = new char[100];
	int k;
	cin >> query_file >> k;
	assert(num>=k);
	cerr << dataset_file << " " << query_file << " " << k << endl;

	// [TODO] Read the query point from query_file, do kNN using the kdTree and output the answer to results.txt
	data.open(query_file);
	int dim1,nq;
	vector<float> query(dim);
	data>>dim1>>nq;
	assert(dim==dim1);
	ofstream result_file;
	result_file.open("results.txt");

	while(nq--) {
		
		for(int i=0; i<dim; i++) {
			data>>query[i];
		}

		priority_queue<kdnode*, vector<kdnode*>, compare_heap> bests;
		mytree->knns(k,query, mytree->root,bests);
		//cerr<< (bests.top())->split_point[0]<<" , "<<(bests.top())->split_point[1] <<endl;
		vector<kdnode*> results(k);
		for(int i = 0; i<k; i++){
			results[i] = bests.top();
			bests.pop();
		}
		
		assert(bests.empty());
		sort(results.begin(), results.end(), mytree->is_closer);	

		for(int i = 0; i<k ; i++) {
			vector<float> tmp = results[i]->split_point;
			for(int j = 0; j<dim-1; j++) {
				result_file<<tmp[j]<<" ";
			}
			result_file<<tmp[dim-1]<<endl;
		}
	}
	data.close();
	result_file.close();
	// Convey to parent that results.txt is ready by sending "1" on stdout | Timer will stop now and this process will be killed
	cout << 1 << endl;
}
