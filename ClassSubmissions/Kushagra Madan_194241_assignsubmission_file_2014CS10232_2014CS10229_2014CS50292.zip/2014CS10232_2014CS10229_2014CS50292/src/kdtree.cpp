#include "kdtree.h"
using namespace std;

float absolute (float a) {
	if(a<0.0) return (-a);
	return a;
}

float l2distance(vector<float> left, vector<float> right){
	int l = left.size();
	assert(l==right.size());
	float d = 0,di;
	while(l--){
		di = left[l]-right[l];
		d += di*di;
	}
	return d;
}

kdnode::kdnode(int dim, int dep, vector<float> split) {
	dimension = dim;
	depth = dep;
	split_point = split;
	dist = FLT_MAX;
	left = right = NULL;
}

kdtree::kdtree(int dim, vector< vector<float> > points) {
	assert(dim>0);
	dimension = dim;
	root = build_from_points(points,0);
}

bool kdtree::is_closer(const kdnode* n1, const kdnode* n2) {
    if (absolute(n1->dist - n2->dist)>DELTA)
        return (n1->dist < n2->dist);
    else{
    	int d = n1->dimension;
        for(int i=0; i<d; i++){
            if(n1->split_point[i] < n2->split_point[i])
                return true;
            else if(n1->split_point[i] > n2->split_point[i])
                return false;
        }
    }
    return true;
}

kdnode* kdtree::build_from_points(vector< vector<float> > points, int depth) {
	if(points.empty()) return NULL;
	int mid = points.size()/2;
	nth_element(points.begin(), points.begin()+mid, points.end(), compare_points(depth%dimension));
	
	kdnode* new_head = new kdnode(dimension, depth, points[mid]);
	if(points.size()==1) return new_head;
	vector< vector<float> > left_half_points(points.begin(), points.begin()+mid);
	vector< vector<float> > right_half_points(points.begin()+mid, points.end());
	
	new_head->left = build_from_points(left_half_points, depth+1);
	new_head->right = build_from_points(right_half_points, depth+1);

	return new_head;
}

void kdtree::nns (vector<float> query, kdnode *current_node, vector<kdnode*> &best_nodes) {
	int dim = current_node->dimension;
	int depth = current_node->depth;
	
	if(!(current_node->left || current_node->right)) { //Leaf
		// cerr<<current_node->split_point[0]<<" , "<<current_node->split_point[1]<<endl;
		if(true || current_node->dist == FLT_MAX) {
			current_node->dist = l2distance(query, current_node->split_point);
		}
		if(current_node->dist < (best_nodes[0])->dist) {
			vector<kdnode*> new_best(1);
			new_best[0] = current_node;
			best_nodes = new_best;
		}
		else if(current_node->dist == (best_nodes[0])->dist){
			best_nodes.push_back(current_node);
		}
	}
	else if (current_node->split_point[depth%dim] >= query[depth%dim]) { // Search Left First
		nns(query, current_node->left, best_nodes);
		float l = current_node->split_point[depth%dim] - query[depth%dim];
		if(l*l <= (best_nodes[0])->dist) { // Equality because mid point builds to right
			nns(query, current_node->right, best_nodes);
		}
	}
	else { // Search Right First
		nns(query, current_node->right, best_nodes);
		float l = - current_node->split_point[depth%dim] + query[depth%dim];
		if(l*l <=  (best_nodes[0])->dist) { // Equality because mid point builds to right
			nns(query, current_node->left, best_nodes);
		}
	}
}

void kdtree::knns (const int k, vector<float> query, kdnode *current_node, priority_queue<kdnode*, vector<kdnode*>, compare_heap> &best_nodes) {
	int dim = current_node->dimension;
	int depth = current_node->depth;
	
	if(!(current_node->left || current_node->right)) { //Leaf
		// cerr<<current_node->split_point[0]<<" , "<<current_node->split_point[1]<<endl;
		if(true || current_node->dist == FLT_MAX) {
			current_node->dist = l2distance(query, current_node->split_point);
		}
		if(best_nodes.size()<k) {
			best_nodes.push(current_node);
		}
		else if(is_closer(current_node, best_nodes.top())) {
			best_nodes.pop();
			best_nodes.push(current_node);
		}
		
	}
	else if (current_node->split_point[depth%dim] >= query[depth%dim]) { // Search Left First
		knns(k,query, current_node->left, best_nodes);
		float l = current_node->split_point[depth%dim] - query[depth%dim];
		if((k>best_nodes.size()) || l*l <= (best_nodes.top())->dist) { // Equality because mid point builds to right
			knns(k,query, current_node->right, best_nodes);
		}
	}
	else { // Search Right First
		knns(k,query, current_node->right, best_nodes);
		float l = - current_node->split_point[depth%dim] + query[depth%dim];
		if((k>best_nodes.size()) || l*l <=  (best_nodes.top())->dist) { // Equality because mid point builds to right
			knns(k,query, current_node->left, best_nodes);
		}
	}
}

void kdtree::sscan(vector<float> query, const int k, priority_queue<kdnode*, vector<kdnode*>, compare_heap> &k_list) {
	queue<kdnode*> bfsq;
	bfsq.push(root);
	while(!bfsq.empty()) {
		kdnode * current = bfsq.front();
		if(current->left) bfsq.push(current->left);
		if(current->right) bfsq.push(current->right);
		if(!((current->left)||(current->right))) { //Leaf
			if(true || current->dist == FLT_MAX) {
				current->dist = l2distance(query, current->split_point);
			}
			if(k_list.size()<k){
				k_list.push(current);
			}
			else if(is_closer(current,k_list.top())) {
				k_list.pop();
				k_list.push(current);
			}
		}
		bfsq.pop();
	}
	assert(k_list.size()==k);
}

void kdtree::print(){
	kdtree t = *this;
	cerr<<"Dimension : "<< t.dimension <<endl;
	queue<kdnode *> bfsq;
	kdnode *dummy = new kdnode();
	dummy->dimension = -1;
	bfsq.push(t.root);
	bfsq.push(NULL);
	kdnode *top;
	while(!bfsq.empty()){
		top = bfsq.front();
		if(!top){
			cerr<<endl<<"_________________"<<endl;
			bfsq.pop();
			if(!bfsq.empty()) bfsq.push(NULL);
			continue;
		}
		else if(top == dummy){
			cerr<<" || ";
			bfsq.pop();
			continue;
		}
		cerr<<"[";
		for(float p : top->split_point){
			cerr<<p<<" ";
		}
		cerr<<"] ";
		if(top->left) bfsq.push(top->left);
		if(top->right) bfsq.push(top->right);
		bfsq.push(dummy);
		bfsq.pop();
	}
}