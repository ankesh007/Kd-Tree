#!/bin/bash
make;
./driver $1