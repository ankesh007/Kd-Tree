#ifndef KDTREE_H
#define KDTREE_H
#include <vector>
#include <algorithm>
#include <queue>
#include <assert.h>
#include <queue>
#include <iostream>
#include <cfloat>
#define DELTA 0.0000001
using namespace std;


float l2distance(vector<float> left, vector<float> right);
float absolute (float a);
struct kdnode {
	kdnode *left, *right;
	int dimension;
	int depth;
	vector<float> split_point;
	float dist = -1;
	kdnode(){
		dist = FLT_MAX;
	}
	kdnode(int dim, int dep, vector<float> split);
};
struct compare_points {
	int dimension;
	compare_points(int d): dimension(d) {}
	bool operator() (const vector< float > &left, const vector< float > &right) {
		return (left[dimension] < right[dimension]);
	}
};

struct compare_heap {
    bool operator() (const kdnode* n1, const kdnode* n2){
        if(absolute(n1->dist - n2->dist)>DELTA)
            return n1->dist < n2->dist;
        else{
            for(int i=0; i<n1->dimension; i++){
                if(n1->split_point[i] < n2->split_point[i])
                    return true;
                else if(n1->split_point[i] > n2->split_point[i])
                    return false;
            }
        }
        return true;
    }
};

class kdtree {
public:
	kdnode *root;
	int dimension = -1;
	
	static bool is_closer(const kdnode* n1, const kdnode* n2);
	kdnode* build_from_points(vector< vector<float> > points, int depth);
	void nns (vector<float> query, kdnode *current_node, vector<kdnode*> &best_nodes);
	void knns (const int k, vector<float> query, kdnode *current_node, priority_queue<kdnode*, vector<kdnode*>, compare_heap> &best_nodes);
	void sscan(vector<float> query, const int k, priority_queue<kdnode*, vector<kdnode*>, compare_heap> &k_list);
	void print();
	kdtree(){}
	kdtree(int dim, vector< vector<float> > points);
	virtual ~kdtree() {}

};

#endif