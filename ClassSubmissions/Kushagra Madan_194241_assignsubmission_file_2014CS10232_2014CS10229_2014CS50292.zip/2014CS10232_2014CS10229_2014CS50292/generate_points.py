import random

dataset_file = open("dataset_file.txt", "w")

dataset_file.write("20 100000\n")

for i in range(0, 100000):
	for j in range(0, 20):
		dataset_file.write(str(random.uniform(0, 1)) + " ")
	dataset_file.write("\n")

dataset_file.close()

query_file = open("query_file.txt", "w")

query_file.write("20 100\n")

for i in range(0, 100):
	for j in range(0, 20):
		query_file.write(str(random.uniform(0, 1)) + " ")
	query_file.write("\n")

query_file.close()